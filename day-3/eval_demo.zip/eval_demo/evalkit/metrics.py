"""Numbers: overlap with a reference, and agreement between a judge and humans."""
import re


def tokens(text):
    return re.findall(r"[a-z0-9+]+", text.lower())


def rouge1_f1(reference, output):
    """Reference-based score: overlap of single words (unigrams), as an F1. 1.0 = same words."""
    ref, out = tokens(reference), tokens(output)
    if not ref or not out:
        return 0.0
    common = 0
    pool = list(ref)
    for w in out:
        if w in pool:
            pool.remove(w)
            common += 1
    if common == 0:
        return 0.0
    p, r = common / len(out), common / len(ref)
    return 2 * p * r / (p + r)


# ---TODO 3 START---
def confusion(human, judge):
    """human, judge: lists of 'PASS'/'FAIL'. Treat PASS as the positive class. Returns dict tp, tn, fp, fn.
    fp = judge said PASS but the human said FAIL  (the dangerous one: a bad answer slips through)."""
    pairs = list(zip(human, judge))
    return {
        "tp": sum(1 for h, j in pairs if h == "PASS" and j == "PASS"),
        "tn": sum(1 for h, j in pairs if h == "FAIL" and j == "FAIL"),
        "fp": sum(1 for h, j in pairs if h == "FAIL" and j == "PASS"),
        "fn": sum(1 for h, j in pairs if h == "PASS" and j == "FAIL"),
    }


def cohens_kappa(a, b):
    """Agreement beyond chance between two lists of labels. 1 = perfect, 0 = no better than chance."""
    n = len(a)
    po = sum(1 for x, y in zip(a, b) if x == y) / n
    pe = sum((a.count(l) / n) * (b.count(l) / n) for l in set(a) | set(b))
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)
# ---TODO 3 END---
