"""LLM-as-judge: a second model call that grades the first one against a written rubric."""
import json
import re

from evalkit import common

# ---TODO 2 START---
JUDGE_SYSTEM = (
    "You are a strict reviewer. You check a release-notes SUMMARY against its source ENTRIES. "
    "PASS only if EVERY claim in the summary is supported by the entries. Paraphrase is fine. "
    "Numbers, platforms, dates and scope words (all, always, every) must match. "
    "FAIL if the summary adds a fact, changes a number, reverses a meaning, or claims more than the entries say. "
    "Do not reward length or polish. If the entries are empty, only 'no customer-facing changes' is supported. "
    'Reply with JSON only, reason FIRST: {"reason": "<one sentence>", "verdict": "PASS" or "FAIL"}'
)


def build_judge_messages(entries, summary):
    listed = "\n".join(f"- {e}" for e in entries) if entries else "(no entries)"
    return [{"role": "system", "content": JUDGE_SYSTEM},
            {"role": "user", "content": f"ENTRIES:\n{listed}\n\nSUMMARY:\n{summary}"}]
# ---TODO 2 END---


def parse_verdict(text):
    """Return (verdict, reason). verdict is 'PASS', 'FAIL' or None when the reply cannot be read."""
    m = re.search(r"\{.*\}", text or "", re.S)
    if m:
        try:
            d = json.loads(m.group(0))
            v = str(d.get("verdict", "")).strip().upper()
            if v in ("PASS", "FAIL"):
                return v, str(d.get("reason", ""))
        except json.JSONDecodeError:
            pass
    m = re.search(r"\b(PASS|FAIL)\b", (text or "").upper())
    return (m.group(1), (text or "")[:120]) if m else (None, (text or "")[:120])


def judge_one(client, deployment, entries, summary):
    msgs = build_judge_messages(entries, summary)
    if not msgs:
        raise SystemExit("TODO 2 is not done yet: build_judge_messages returns nothing. See hints/HINTS.md")
    resp, _ = common.call_model(client, deployment, msgs)
    v, reason = parse_verdict(resp.choices[0].message.content)
    return v, reason, resp.usage.total_tokens
