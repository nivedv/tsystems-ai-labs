# Evaluation Demo — metrics, automation, LLM-as-judge and a regression gate (trainer demo, 25 min)

**System under test:** *Nimbus Notes release-notes summariser* (synthetic). It turns raw changelog entries into a short customer-facing summary. Two prompt versions exist: `v1` (careful) and `v2` (a lazy rewrite that regresses).
Everything here is self-contained: own data, own code, no other course material needed.

## Setup
```
pip install -r requirements.txt
copy .env.example .env         # 4 settings: endpoint, key, API version, chat deployment name
python scripts/check_env.py
```
## Steps
| # | Command | Shows | API calls |
|---|---|---|---|
| 1 | `python scripts/run_once.py --case g01 --repeat 5` | non-determinism: same input, different outputs | 5 |
| 2 | `python scripts/golden_report.py` | golden set size, normal vs edge, coverage of 8 risk categories | 0 |
| 3 | `python scripts/run_eval.py --fixture fixtures/outputs_v1.json` | assertion + reference metrics on RECORDED outputs (deterministic) | 0 |
| 4 | `python scripts/calibrate.py` then `python scripts/run_eval.py --fixture fixtures/outputs_v2_regressed.json --judge` | can we trust the judge? (kappa, false-pass rate) and the judge on a regressed build | 40 + 12 |
| 5 | `python scripts/pipeline.py --fixture fixtures/outputs_v1.json` then `--fixture fixtures/outputs_v2_regressed.json` | the build PASSES, then FAILS on the regression | 0 |

## Folders
`system/` system under test · `evalkit/` checks, metrics, judge · `data/` golden set, calibration set (human labels), thresholds, baseline · `fixtures/` recorded outputs · `scripts/` the commands above · `ci/eval.yml` (copy to `.github/workflows/` in your own repo) the same pipeline for CI · `worksheets/` · `results/` (generated).
