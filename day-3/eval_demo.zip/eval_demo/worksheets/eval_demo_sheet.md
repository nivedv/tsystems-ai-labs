# Evaluation demo sheet (fill live from the printed output)
Step 1: different outputs in 5 runs: ____ of 5.  Did any break a rule?  ____
Step 2: normal ____  edge ____  risk categories covered ____ / 8
Step 3 (v1 fixture): assertion pass rate ____ (normal ____, edge ____)   ROUGE-1 mean ____   case that failed: ____ because ____
        A good answer with a LOW overlap score: case ____ score ____
Step 4: kappa ____  agreement ____  false-pass ____  false-fail ____  repeatability ____   TRUSTED? ____
        Judge on the regressed build: faithful ____ of 12.  Cases the judge caught that assertions did not: ____
Step 5: v1 -> BUILD ______   v2 -> BUILD ______ at step ____
Caution (write it): ____ cases; one case = about ____ points.
