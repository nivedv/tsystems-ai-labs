# Trainer guide — Evaluation Demo (25 min)

**Deck:** "AI Evaluation: Metrics, Automation and LLM-as-Judge", slides 21–22. Verbatim speech is in the speaker notes.

## 1. Why this demo and this data
| Choice | Reason |
|---|---|
| A summariser with checkable rules (word limit, no ticket IDs, no secrets, no swearing) | Cheap assertions can already catch real defects, so learners see the first rung of the evaluation ladder before the expensive one |
| 12 golden cases: 4 normal + 8 edge (empty, internal-only, profanity, secret, long input, negation, non-English, prompt injection) | One case per risk category makes the coverage idea visible. 12 is small on purpose so everyone can read every row |
| Recorded fixtures for v1 and the regressed v2 | A regression can be shown on demand, offline and deterministically. Real models regress rarely and unpredictably |
| 20-item calibration set with two human reviewers and one borderline item (c19) | Calibration needs human labels. The reviewers disagree once: the human ceiling is below 1.0 |
| The judge sees ONLY entries + summary and a written rubric | Faithfulness is judged against the source, not against the judge's own knowledge |

## 2. What is deterministic and what is not
| Item | Value | Status |
|---|---|---|
| v1 fixture: assertion pass rate | 11/12 = 0.917 (normal 1.00, edge 0.875; g09 fails `word_limit`) | deterministic |
| v1 fixture: ROUGE-1 F1 mean | 0.858 | deterministic |
| v2 fixture: assertion pass rate | 3/12 = 0.250 | deterministic |
| v2 fixture: ROUGE-1 F1 mean | 0.484 | deterministic |
| Gate on v1 vs baseline | PASS · on v2: FAIL at step 3 (exit code 1) | deterministic |
| Human-human kappa on the calibration set | 0.90 (reviewers differ only on c19) | deterministic |
| Live outputs (step 1), judge verdicts, judge kappa and false-pass rate (step 4) | — | **NOT yet measured: rehearse and write the real values on the sheet** |
Never quote a judge number you did not see on your screen.

## 3. Before class (30 min)
- [ ] `pip install -r requirements.txt`; `.env` filled; `python scripts/check_env.py` says READY
- [ ] Steps 3 and 5 offline: confirm the numbers in the table above
- [ ] Run steps 1 and 4 once. Note the judge's kappa, false-pass rate and which items it gets wrong. If it passes the trust rule easily, be ready to explain that 20 items is a small sample
- [ ] Delete `results/*.json`
- [ ] Tabs open: `evalkit/checks.py`, `evalkit/judge.py` (the rubric), `scripts/gate.py`, `ci/eval.yml` (copy to `.github/workflows/` in your own repo)

## 4. Run sheet (25 min)
| Min | Step | Say / point at |
|---|---|---|
| 0–4 | 1 `run_once.py` | "Same input, five runs." Read two outputs aloud. Count distinct outputs. Ask: would an exact-match test pass these? Show the checks-passed count per run |
| 4–8 | 2 `golden_report.py` | Eight risk categories, one case each. "Which category would you add for your product?" Remind: 12 cases = one case is 8 points |
| 8–13 | 3 `run_eval.py` (v1) | Read the table. g09 fails `word_limit`: a real defect, found without a model. Then g03: a perfect summary, ROUGE only 0.667. "Overlap punishes paraphrase" |
| 13–19 | 4 `calibrate.py`, then `--judge` | Read the confusion matrix. "False-pass is the dangerous cell." Open two DISAGREE items and read the judge's reason. Show the trust rule and the verdict. Then the judge on v2: which cases does it flag that the assertions did not? |
| 19–25 | 5 `pipeline.py` | v1: BUILD PASSED. v2: BUILD FAILED at step 3, exit code 1. Open `eval.yml`: same command in CI. "The baseline is a decision: who may change it, and why?" |

## 5. Teaching points
1. Assertions first: cheap, exact, run on every commit.
2. A reference score is a weak signal when many answers are right.
3. A judge is an instrument: calibrate it before you trust it, and watch false-pass.
4. A gate needs a baseline, a floor and a noise band, and a golden set that covers the risks.
5. The system must expose input, output, version and cost, or the metric cannot be computed.

## 6. If it fails
| Symptom | Fix |
|---|---|
| `Missing settings` | fill `.env` |
| 404 / DeploymentNotFound | `AZURE_OPENAI_DEPLOYMENT` must be the chat deployment name |
| Judge replies are unreadable | rerun; the script counts unreadable replies as FAIL and says how many |
| 429 | wait 30 s; calibration is 40 calls |
| Gate says "No baseline" | `python scripts/run_eval.py --fixture fixtures/outputs_v1.json --write-baseline` |
| No network | do steps 2, 3, 5 offline and show a saved calibration result |

## 7. Honest limits to state out loud
12 golden cases and 20 calibration items are teaching sizes; real projects need far more. The fixtures are hand-written stand-ins for build output. A calibrated judge is trusted for THIS task and THIS kind of input only. Offline scores do not tell you how users experience the system online.
