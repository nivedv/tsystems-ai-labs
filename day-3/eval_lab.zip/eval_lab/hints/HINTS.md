# Hints — open one level at a time

## TODO 1 — checks (`evalkit/checks.py`)
**L1** Each function returns True (check passed) or False.
**L2** word limit: count words with `words(output)`; compare with `WORD_LIMIT`. keywords: compare in lower case (`.lower()`).
**L3** `return len(words(output)) <= WORD_LIMIT` · `return all(k.lower() in output.lower() for k in case["must_include"])` · `return not any(k.lower() in output.lower() for k in case["must_not_include"])`

## Golden set g05–g12
**L1** Ask: what is the worst thing the summary could do on this input? Empty entries → it must not invent changes. Secret → it must not repeat the key. Injection → it must not obey the instruction inside the entry.
**L2** `must_not_include` holds short strings (e.g. `"sk_live"`). `must_include` holds the facts that must survive (e.g. `"dark mode"`). Keep both short and literal.
**L3** Look at `fixtures/outputs_v1.json` for how v1 answered, then write expectations a *good* answer satisfies.

## TODO 2 — judge prompt (`evalkit/judge.py`)
**L1** The judge sees only the ENTRIES and the SUMMARY. Say what PASS means (every claim supported) and what FAIL means (added fact, changed number, wrong scope).
**L2** Ask for JSON with `reason` FIRST and `verdict` second: `{"reason": "...", "verdict": "PASS" or "FAIL"}`. Tell it not to reward length or polish.
**L3** Return `[{"role":"system","content":JUDGE_SYSTEM},{"role":"user","content":f"ENTRIES:\n{listed}\n\nSUMMARY:\n{summary}"}]`, where `listed` is the entries as a bullet list ("(no entries)" if empty).

## TODO 3 — metrics (`evalkit/metrics.py`)
**L1** Walk the two lists together with `zip`. PASS is the positive class.
**L2** tp: both PASS · tn: both FAIL · fp: judge PASS, human FAIL · fn: judge FAIL, human PASS. Kappa: observed agreement `po`, chance agreement `pe`; `(po-pe)/(1-pe)`. If `pe == 1` return 1.0.
**L3** `pe = sum((a.count(l)/n) * (b.count(l)/n) for l in ("PASS","FAIL"))`

## TODO 4 — gate (`scripts/gate.py`)
**L1** Three outcomes: SKIP (no value), FAIL (below floor, or fell too far), PASS.
**L2** Check `value is None` first. Then `value < rule["min"]`. Then `baseline is not None and baseline - value > rule["max_drop"]`.
**L3** Return `("FAIL", f"{value} is below the floor {rule['min']}")`, `("FAIL", f"fell {baseline-value:.3f} from baseline (allowed {rule['max_drop']})")`, `("SKIP","not computed")`, `("PASS","ok")` respectively.

## Common errors
| Message | Meaning |
|---|---|
| `TODO n is not done yet` | finish that function; the error names it |
| `PROBLEMS` list from golden_report | g05–g12 still need expectations / ref |
| `No baseline` | run B2 |
| exit code 3 | the system output is missing a required field |
| 404 / DeploymentNotFound | wrong deployment name in `.env` |
