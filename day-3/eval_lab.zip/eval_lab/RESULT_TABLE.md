# Result table (name: ________)
| Item | Your value |
|---|---|
| Golden set: normal / edge / categories covered | ___ / ___ / ___ of 8 |
| v1 assertion pass rate (normal / edge) | ___ (___ / ___) |
| Failing case and the rule it broke | ___ |
| ROUGE-1 F1 mean (v1) | ___ |
| A good answer with a low overlap score (case, score) | ___ |
| Judge: agreement / kappa | ___ / ___ |
| Judge: false-pass rate / false-fail rate | ___ / ___ |
| Judge: repeatability | ___ |
| Human–human kappa (the ceiling) | ___ |
| TRUSTED? (rule: kappa ≥ 0.60 and false-pass ≤ 0.20) | yes / no — because ___ |
| Pipeline v1 result | ___ |
| Pipeline v2: failing step, metric, exit code | ___ |
| Judge on v2: cases flagged that assertions missed | ___ |
| Why is a 12-case golden set risky? | ___ |
| Which CI job runs on every PR and why no secrets? | ___ |
| Who may change the baseline and when? (your rule) | ___ |
