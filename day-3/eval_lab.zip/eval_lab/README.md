# Nimbus Notes — evaluation lab (learner repo)

Self-contained starter. System under test: a release-notes summariser (`system/release_notes.py`). You build the evaluation around it.

Start with `LAB_CARD.md`. Hints: `hints/HINTS.md`. Record answers: `RESULT_TABLE.md`. Formative review: `review/BRIEF.md`.
Layout: `evalkit/` (4 TODOs) · `scripts/` · `data/` · `fixtures/` (recorded outputs: v1 good, v2 regressed) · `ci/eval.yml` (copy to `.github/workflows/` in your own repo) · `results/` (generated).
Never commit `.env`.
