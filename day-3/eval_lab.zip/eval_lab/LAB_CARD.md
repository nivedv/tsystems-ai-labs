# Lab — Evaluate it, calibrate the judge, fail the build (75 min + formative review)

**You will:** build the evaluation of a release-notes summariser (*Nimbus Notes*). Part A makes the measurements trustworthy. Part B turns them into a gate that fails the build on a regression.
Stuck for 5 minutes? Open `hints/HINTS.md` (3 levels per TODO). Write results in `RESULT_TABLE.md`.

## Setup (10 min)
```
pip install -r requirements.txt
copy .env.example .env      (fill the 4 settings)
python scripts/check_env.py          -> READY
```

## Part A — Measure (45 min)
**A1 Look (5 min).** `python scripts/golden_report.py` — it reports that g05–g12 have no expectations yet. Read `data/golden_set.json`: each case has entries, `must_include`, `must_not_include`, `ref`.

**A2 Fill the golden set (10 min).** For g05–g12 write what a *correct* summary must contain or avoid (e.g. the secret case: must_not_include the key text). Write a short `ref` summary for each. `python scripts/golden_report.py --check` must say "Golden set looks complete.".

**A3 TODO 1 — three checks (10 min).** In `evalkit/checks.py` finish `check_word_limit`, `check_must_include`, `check_must_not_include`. Then:
`python scripts/run_eval.py --fixture fixtures/outputs_v1.json`
Record assertion pass rate, ROUGE-1 mean, the failing case and why.

**A4 TODO 2 — the judge prompt (10 min).** In `evalkit/judge.py` write `JUDGE_SYSTEM` (what PASS and FAIL mean; reason first, then verdict as JSON) and `build_judge_messages`.

**A5 TODO 3 — calibration maths (5 min).** In `evalkit/metrics.py` write `confusion` and `cohens_kappa`.

**A6 Calibrate (5 min).** `python scripts/calibrate.py` — 20 items with human labels, judge runs twice. Record kappa, false-pass rate, repeatability. **Decide: trusted or not, and why.** If not, improve the rubric in TODO 2 and rerun once.

## Part B — Automate (30 min)
**B1 TODO 4 — the gate (10 min).** In `scripts/gate.py` finish `check_metric`.
**B2 Baseline (3 min).** `python scripts/run_eval.py --fixture fixtures/outputs_v1.json --write-baseline`
**B3 Pipeline (7 min).**
`python scripts/pipeline.py --fixture fixtures/outputs_v1.json` → BUILD PASSED
`python scripts/pipeline.py --fixture fixtures/outputs_v2_regressed.json` → BUILD FAILED, exit code 1
Show the exit code: `echo %errorlevel%` (Windows cmd) or `echo $?`.
**B4 Judge on the regression (5 min, optional if time).** `python scripts/run_eval.py --fixture fixtures/outputs_v2_regressed.json --judge` — which cases does the judge flag?
**B5 CI (5 min).** Read `ci/eval.yml` (copy to `.github/workflows/` in your own repo). Answer in `RESULT_TABLE.md`: which job runs on every pull request and why does it need no secrets? Which job needs secrets and why is it manual?

## Done when
- `golden_report.py --check` says complete · pipeline passes on v1 and fails on v2 · result table filled · trust decision written with numbers.

## Exit codes
0 = pass · 1 = regression (build fails) · 2 = no baseline · 3 = a required field is missing, metric not computable.
