"""Calibrate the judge against human labels. Can we trust it?

  python scripts/calibrate.py               # 20 items x 2 runs = 40 judge calls
  python scripts/calibrate.py --repeats 1
"""
import argparse

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from evalkit import common, judge, metrics

ap = argparse.ArgumentParser()
ap.add_argument("--repeats", type=int, default=2)
a = ap.parse_args()
items = common.read_json("data/calibration_set.json")["items"]
client, dep = common.get_client()
runs = {i["id"]: [] for i in items}
unreadable = 0
try:
    for _ in range(a.repeats):
        for it in items:
            v, reason, _ = judge.judge_one(client, dep, it["entries"], it["summary"])
            if v is None:
                unreadable += 1
            runs[it["id"]].append((v or "FAIL", reason))
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)

human = [i["human"] for i in items]
first = [runs[i["id"]][0][0] for i in items]
cm = metrics.confusion(human, first)
if cm is None:
    raise SystemExit("TODO 3 is not done yet: confusion() returns nothing. See hints/HINTS.md")
n = len(items)
agree = (cm["tp"] + cm["tn"]) / n
kappa = metrics.cohens_kappa(human, first)
if kappa is None:
    raise SystemExit("TODO 3 is not done yet: cohens_kappa() returns nothing. See hints/HINTS.md")
fail_total = cm["tn"] + cm["fp"]
pass_total = cm["tp"] + cm["fn"]
false_pass = cm["fp"] / fail_total if fail_total else 0.0
false_fail = cm["fn"] / pass_total if pass_total else 0.0
consistent = sum(1 for i in items if len({v for v, _ in runs[i['id']]}) == 1) / n
ha = metrics.cohens_kappa([i["label_a"] for i in items], [i["label_b"] for i in items])

print(f"\n{'id':<5}{'human':<7}{'judge':<7}{'':<4}judge reason (run 1)")
for it, j in zip(items, first):
    flag = "" if it["human"] == j else "<-- DISAGREE"
    print(f"{it['id']:<5}{it['human']:<7}{j:<7}{flag:<14}{runs[it['id']][0][1][:70]}")
print(f"\nconfusion (PASS = positive): TP {cm['tp']}  TN {cm['tn']}  FP {cm['fp']}  FN {cm['fn']}")
print(f"agreement with humans : {agree:.2f}")
print(f"Cohen's kappa         : {kappa:.2f}   (two human reviewers agree with each other at kappa {ha:.2f}: the ceiling)")
print(f"FALSE-PASS rate       : {false_pass:.2f}   (bad answers the judge let through: {cm['fp']} of {fail_total})")
print(f"false-fail rate       : {false_fail:.2f}   (good answers the judge blocked: {cm['fn']} of {pass_total})")
print(f"repeatability         : {consistent:.2f}   (items where all {a.repeats} runs gave the same verdict)")
if unreadable:
    print(f"unreadable replies    : {unreadable} (counted as FAIL)")
trust = kappa >= 0.6 and false_pass <= 0.2
print("\nTRUST RULE (a team decision, not a law): kappa >= 0.60 AND false-pass rate <= 0.20")
print("-> " + ("TRUSTED for this task, with these 20 examples. Re-check when the prompt, model or data changes." if trust else "NOT TRUSTED yet. Fix the rubric, add examples, or keep a human on the risky cases."))
print(f"\nCaution: {n} items. One item moves a rate by about {round(100 / n)} points.")
common.write_json("results/calibration.json", {"n": n, "confusion": cm, "agreement": round(agree, 3), "kappa": round(kappa, 3), "false_pass_rate": round(false_pass, 3),
                                                "false_fail_rate": round(false_fail, 3), "repeatability": round(consistent, 3), "human_human_kappa": round(ha, 3), "trusted": trust})
