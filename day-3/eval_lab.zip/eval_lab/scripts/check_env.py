"""Run FIRST. Checks settings and makes ONE tiny model call. Never prints the key."""
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import os

from evalkit import common

common.load_env()
ok = True
for k in common.REQUIRED:
    v = os.environ.get(k)
    if not v:
        print(f"[MISSING] {k}")
        ok = False
    else:
        print(f"[ set   ] {k}" + ("  (value hidden)" if "KEY" in k else f" = {v}"))
try:
    import openai  # noqa: F401
    print("[ ok    ] openai package")
except ImportError:
    print("[MISSING] openai package -> pip install -r requirements.txt")
    ok = False
if ok:
    try:
        client, dep = common.get_client()
        r, s = common.call_model(client, dep, [{"role": "user", "content": "Reply with the single word OK"}])
        print(f"[ ok    ] model call worked in {s:.1f} s: {r.choices[0].message.content.strip()[:20]}")
    except Exception as e:
        common.explain_error(e)
        ok = False
print("\nREADY." if ok else "\nFix the items above, then run again.")
