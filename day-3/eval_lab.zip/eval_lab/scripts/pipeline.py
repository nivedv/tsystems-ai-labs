"""Mini CI pipeline for this laptop. Same idea as the workflow file: steps in order, the first failure stops the build.

  python scripts/pipeline.py --fixture fixtures/outputs_v1.json
  python scripts/pipeline.py --fixture fixtures/outputs_v2_regressed.json     # must FAIL
  python scripts/pipeline.py --fixture fixtures/outputs_v1.json --judge       # adds the judge (needs the API)
"""
import argparse
import subprocess

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

ap = argparse.ArgumentParser()
ap.add_argument("--fixture")
ap.add_argument("--judge", action="store_true")
ap.add_argument("--version", default="v1")
ap.add_argument("--repeats", default="1")
a = ap.parse_args()
py = sys.executable
ev = [py, "scripts/run_eval.py"] + (["--fixture", a.fixture] if a.fixture else ["--version", a.version, "--repeats", a.repeats]) + (["--judge"] if a.judge else [])
steps = [("1 golden set is complete", [py, "scripts/golden_report.py", "--check"]), ("2 run the evaluation", ev), ("3 regression gate", [py, "scripts/gate.py"])]
root = pathlib.Path(__file__).resolve().parent.parent
for name, cmd in steps:
    print(f"\n===== STEP {name} =====")
    r = subprocess.run(cmd, cwd=root)
    if r.returncode != 0:
        print(f"\n##### BUILD FAILED at step {name} (exit code {r.returncode}) #####")
        raise SystemExit(r.returncode)
print("\n##### BUILD PASSED #####")
