"""Is the golden set any good? Counts cases by type and checks that every risk category is covered.

  python scripts/golden_report.py
  python scripts/golden_report.py --check      # exit code 1 when something is missing (used by the pipeline)
"""
import argparse

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from evalkit import common

ap = argparse.ArgumentParser()
ap.add_argument("--check", action="store_true")
a = ap.parse_args()
cases = common.read_json("data/golden_set.json")["cases"]
need = common.read_json("data/coverage.json")["required"]
problems = []
ids = [c["id"] for c in cases]
if len(ids) != len(set(ids)):
    problems.append("duplicate case ids")
for c in cases:
    miss = [k for k in ("id", "type", "tags", "entries", "must_include", "must_not_include", "ref") if k not in c]
    if miss:
        problems.append(f"{c.get('id', '?')}: missing fields {miss}")
    elif not c["ref"].strip():
        problems.append(f"{c['id']}: empty reference")
    elif not c["must_include"] and not c["must_not_include"]:
        problems.append(f"{c['id']}: no expectation at all (must_include and must_not_include are both empty)")
print(f"cases: {len(cases)}   normal: {sum(c['type'] == 'normal' for c in cases)}   edge: {sum(c['type'] == 'edge' for c in cases)}\n")
print(f"{'risk category':<16}{'cases':<8}ids")
for k in need:
    have = [c["id"] for c in cases if k in c.get("tags", [])]
    print(f"{k:<16}{len(have):<8}{', '.join(have) or '--  NOT COVERED'}")
    if not have:
        problems.append(f"no case covers '{k}'")
print(f"\nCaution: {len(cases)} cases. One case moves a pass rate by about {round(100 / max(len(cases), 1))} points.")
if problems:
    print("\nPROBLEMS")
    for p in problems:
        print("  -", p)
    if a.check:
        raise SystemExit(1)
else:
    print("\nGolden set looks complete.")
