"""Run the evaluation: assertions + reference overlap (+ optional LLM judge) over the golden set.

  python scripts/run_eval.py --fixture fixtures/outputs_v1.json              # offline, deterministic
  python scripts/run_eval.py --fixture fixtures/outputs_v1.json --judge      # + judge (API calls)
  python scripts/run_eval.py --version v1 --repeats 3                        # LIVE: the system is called
  python scripts/run_eval.py --version v1 --record fixtures/outputs_mine.json   # LIVE, and keep the outputs
  python scripts/run_eval.py --fixture fixtures/outputs_v1.json --write-baseline
"""
import argparse
import datetime

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from evalkit import checks, common, judge, metrics
from system import release_notes

ap = argparse.ArgumentParser()
ap.add_argument("--fixture")
ap.add_argument("--version", default="v1")
ap.add_argument("--repeats", type=int, default=1)
ap.add_argument("--judge", action="store_true")
ap.add_argument("--record")
ap.add_argument("--write-baseline", action="store_true")
ap.add_argument("--out", default="results/latest.json")
a = ap.parse_args()

cases = common.read_json("data/golden_set.json")["cases"]
runs = []   # (case, record)
skipped = []
client = deployment = None
try:
    if a.fixture:
        recs = {r["case_id"]: r for r in common.read_json(a.fixture)["records"]}
        for c in cases:
            if c["id"] in recs:
                runs.append((c, recs[c["id"]]))
            else:
                skipped.append(c["id"])
    else:
        client, deployment = common.get_client()
        for c in cases:
            for _ in range(a.repeats):
                runs.append((c, release_notes.summarize(c["id"], c["entries"], a.version, client, deployment)))
    if a.judge:
        if client is None:
            client, deployment = common.get_client()
except SystemExit:
    raise
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)

# ENGINEERING THREAD: a metric is only computable if the system exposed what it needs.
for _, r in runs:
    miss = [f for f in release_notes.REQUIRED_FIELDS if f not in r]
    if miss:
        print(f"CANNOT EVALUATE case {r.get('case_id', '?')}: the record has no {miss}. Without them a metric cannot be computed or traced.")
        raise SystemExit(3)
if skipped:
    print(f"(no recorded output for {len(skipped)} case(s), skipped: {', '.join(skipped)})")
if not runs:
    print("Nothing to evaluate.")
    raise SystemExit(3)

rows = []
for c, r in runs:
    res = checks.run_checks(c, r["output"])
    row = {"case_id": c["id"], "type": c["type"], "output": r["output"], "checks": res, "passed": all(res.values()),
           "rouge1_f1": round(metrics.rouge1_f1(c["ref"], r["output"]), 3), "judge": None, "judge_reason": None,
           "prompt_version": r["prompt_version"], "tokens": r["total_tokens"], "latency_s": r["latency_s"]}
    if a.judge:
        try:
            v, reason, _ = judge.judge_one(client, deployment, r["input_entries"], r["output"])
        except Exception as e:
            common.explain_error(e)
            raise SystemExit(1)
        row["judge"], row["judge_reason"] = v, reason
    rows.append(row)

n = len(rows)
m = {"assertion_pass_rate": round(sum(x["passed"] for x in rows) / n, 3),
     "rouge1_f1_mean": round(sum(x["rouge1_f1"] for x in rows) / n, 3),
     "judge_faithfulness": round(sum(x["judge"] == "PASS" for x in rows) / n, 3) if a.judge else None}
by_type = {}
for t in sorted({x["type"] for x in rows}):
    sub = [x for x in rows if x["type"] == t]
    by_type[t] = round(sum(x["passed"] for x in sub) / len(sub), 3)

print(f"\n{'case':<6}{'type':<8}{'checks':<8}{'rouge1':<8}{'judge':<7}failed checks")
for x in rows:
    failed = [k for k, v in x["checks"].items() if not v]
    print(f"{x['case_id']:<6}{x['type']:<8}{'PASS' if x['passed'] else 'FAIL':<8}{x['rouge1_f1']:<8}{str(x['judge'] or '-'):<7}{', '.join(failed)}")
print(f"\nruns evaluated: {n}   prompt version(s): {sorted({x['prompt_version'] for x in rows})}")
print(f"assertion pass rate : {m['assertion_pass_rate']:.3f}   (normal {by_type.get('normal', '-')}, edge {by_type.get('edge', '-')})")
print(f"reference overlap   : {m['rouge1_f1_mean']:.3f}   (mean ROUGE-1 F1: a weak signal, see the paraphrase cases)")
print("LLM-judge faithful  : " + (f"{m['judge_faithfulness']:.3f}" if a.judge else "not run (add --judge)"))
print(f"\nCaution: {n} runs. One case moves a rate by about {round(100 / n)} points. Report the number of runs with every rate.")

common.write_json(a.out, {"meta": {"timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "n_runs": n,
                                    "mode": "fixture" if a.fixture else "live", "source": a.fixture or a.version}, "metrics": m, "by_type": by_type, "cases": rows})
if a.record and not a.fixture:
    common.write_json(a.record, {"note": "RECORDED live outputs", "records": [r for _, r in runs]})
    print(f"(recorded {n} outputs to {a.record})")
if a.write_baseline:
    common.write_json("data/baseline.json", {"note": "Baseline = the metrics we accept as 'good enough to protect'. Changing it is a decision, record why.", "source": a.fixture or a.version,
                                              "metrics": {k: v for k, v in m.items() if v is not None}})
    print("(baseline written to data/baseline.json)")
