"""Why evaluation is different: run the SAME input several times and look at the outputs.

  python scripts/run_once.py --case g01 --repeat 5
  python scripts/run_once.py --case g09 --version v2
"""
import argparse

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from evalkit import checks, common
from system import release_notes

ap = argparse.ArgumentParser()
ap.add_argument("--case", default="g01")
ap.add_argument("--repeat", type=int, default=5)
ap.add_argument("--version", default="v1")
a = ap.parse_args()
case = next(c for c in common.read_json("data/golden_set.json")["cases"] if c["id"] == a.case)
client, dep = common.get_client()
outs = []
try:
    for i in range(a.repeat):
        r = release_notes.summarize(case["id"], case["entries"], a.version, client, dep)
        res = checks.run_checks(case, r["output"])
        outs.append(r["output"])
        print(f"\nrun {i + 1}: {len(checks.words(r['output']))} words, checks passed {sum(res.values())}/{len(res)}\n  {r['output']}")
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)
print(f"\n{len(set(outs))} different outputs in {a.repeat} runs of the SAME input.")
print("An exact-match test would call most of these 'wrong'. They may all be fine. That is why we assert PROPERTIES.")
