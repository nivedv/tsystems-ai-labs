"""The regression gate: compare this run with the baseline. A regression FAILS the build (exit code 1).

  python scripts/gate.py
  python scripts/gate.py --results results/latest.json --baseline data/baseline.json
"""
import argparse

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from evalkit import common

ap = argparse.ArgumentParser()
ap.add_argument("--results", default="results/latest.json")
ap.add_argument("--baseline", default="data/baseline.json")
a = ap.parse_args()


def check_metric(value, baseline, rule):
    # TODO 4: return (status, message) with status "PASS", "FAIL" or "SKIP".
    #   value None -> SKIP.  value < rule["min"] -> FAIL.  baseline - value > rule["max_drop"] -> FAIL.  otherwise PASS.
    return None


if not (common.ROOT / a.baseline).exists():
    print(f"No baseline at {a.baseline}. Create it from a build you trust:  python scripts/run_eval.py --fixture fixtures/outputs_v1.json --write-baseline")
    raise SystemExit(2)
res = common.read_json(a.results)
base = common.read_json(a.baseline)["metrics"]
rules = common.read_json("data/thresholds.json")["metrics"]
print(f"GATE  results: {a.results} ({res['meta']['n_runs']} runs, source {res['meta']['source']})  vs baseline: {a.baseline}\n")
print(f"{'metric':<24}{'value':<9}{'baseline':<10}{'status':<8}why")
failed = False
for name, rule in rules.items():
    v = res["metrics"].get(name)
    st, why = check_metric(v, base.get(name), rule)
    if st is None:
        print("check_metric returned nothing: finish TODO 4")
        raise SystemExit(2)
    failed |= st == "FAIL"
    print(f"{name:<24}{('-' if v is None else format(v, '.3f')):<9}{('-' if base.get(name) is None else format(base[name], '.3f')):<10}{st:<8}{why}")
print()
if failed:
    print("GATE FAILED: a metric regressed. The build stops here.")
    raise SystemExit(1)
print("GATE PASSED.")
