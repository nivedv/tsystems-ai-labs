# Rubric — 100 points (graded on rigour and reproducibility)
| Area | Pts | 4 Excellent | 3 Good | 2 Basic | 1 Weak |
|---|---|---|---|---|---|
| **Golden set coverage** | 15 | ≥10 cases, ≥5 justified risk categories, normal + edge mix | meets minimum, thin justification | meets count, categories unjustified | <10 cases or <5 categories |
| **Assertion checks** | 10 | ≥3 meaningful checks, each tied to a risk | 3 checks, some trivial | 1–2 checks | none run |
| **Metric choice & limits** | 10 | explains why each metric fits and where it misleads (e.g. overlap vs paraphrase) | explains fit, limits partial | lists metrics only | no reasoning |
| **Judge calibration** | 15 | ≥12 items, two labellers, confusion matrix, kappa, false-pass, repeatability, honest trust call | all numbers, weak trust reasoning | numbers without a decision | uncalibrated judge |
| **Gate & regression** | 15 | baseline, floor, max-drop; worse prompt fails the build with exit code 1; thresholds justified | gate works, thresholds unexplained | gate exists, regression not shown | no gate |
| **Reproducibility** | 20 | one command offline from a clean clone; fixtures; pinned deps; no secrets; README expected output matches | works with a small manual step | works only on author's machine | cannot be run |
| **Defence** | 15 | explains every part; names limits; answers both questions with evidence | minor gaps | partly reads code aloud | cannot explain |
Weighting: rigour (coverage, checks, metrics, judge, gate) = 65 · reproducibility = 20 · defence = 15 (scale: score = Σ(level/4 × points)).
**Pass mark 60.** Automatic cap at 50 if any secret is committed.
