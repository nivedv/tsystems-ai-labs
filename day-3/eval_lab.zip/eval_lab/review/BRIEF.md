# Formative Review — Build and defend an evaluation (take-home 60–90 min + 10 min defence)

## The brief (from the product owner)
> Our team ships **MeetingMate**, a tool that turns a meeting transcript into a list of **action items** (who, what, by when). A wrong action item sends people to do the wrong thing. We change the prompt and the model often. **Before the next change, we want an evaluation we can trust and a build that stops when quality drops.** You may reuse the toolkit structure from the lab, but the data and the checks must be yours.

## What you deliver (a folder or repo, one command to reproduce)
1. **System under test**: a small function or script that returns an action-item list from a transcript, with two prompt versions (one good, one deliberately worse). Use the LLM API.
2. **Golden set**: at least **10 cases**, covering at least **5 risk categories** you name and justify (e.g. empty transcript, no decisions made, two people same name, invented deadline, non-English, injection inside the transcript).
3. **Assertion checks**: at least **3** deterministic checks (e.g. valid JSON, every item has an owner, no invented date).
4. **A judge**: a written rubric, calibrated on at least **12 items labelled by two people** (you plus one colleague, or two passes a day apart). Report agreement, kappa, false-pass rate. State whether you trust it and why.
5. **A gate**: baseline, floor and maximum drop per metric; a **demonstrated regression** (the worse prompt fails the build, exit code 1).
6. **Reproducibility**: recorded fixtures so the deterministic part runs offline with one command; a README with setup and expected output; no secrets committed.
7. **Defence note** (1 page): what your evaluation cannot tell you; what you would do with 10× the data; who may change the baseline.

## Rules
Do not reuse the Nimbus Notes data. Write your own cases and labels. You may use any code from the lab; say which. Use of an AI assistant is allowed; you must be able to explain every line in the defence.

## Defence (10 min)
Run the one command. Show the regression failing. Answer two questions chosen from `DEFENCE_QUESTIONS.md`.
