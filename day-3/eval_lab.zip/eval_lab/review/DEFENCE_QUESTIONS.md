# Defence questions (the assessor picks two)
1. Your judge has kappa 0.7 but a false-pass rate of 0.3. Do you ship it as a gate? What do you change?
2. Your pass rate moves from 0.92 to 0.83 on 12 cases. Is that a regression? What do you do next?
3. A new model version scores higher on overlap but your judge scores it lower. Which do you believe and how do you decide?
4. Show me one golden case that would have caught a real bug, and one that adds nothing. Why?
5. Who is allowed to update the baseline? What evidence do they need?
6. Your fixtures are recorded. What does that hide from you, and how often do you run live?
7. The two labellers disagreed on one item. What did you do, and what does it say about the rubric?
8. What would your evaluation miss in production that users would notice?
