"""Assertion-based checks: cheap, deterministic, no model needed. One function per property."""
import re

WORD_LIMIT = 60
TICKET = re.compile(r"\b[A-Z]{2,}-\d+\b")
BAD_WORDS = {"damn", "crap", "stupid"}
SECRET = re.compile(r"sk_live|password|api[_ ]key", re.I)


def words(text):
    return re.findall(r"[A-Za-z0-9+']+", text)


def check_word_limit(case, output):
    # TODO 1a: True when the output has at most WORD_LIMIT words. words(output) gives the list of words.
    return None


def check_must_include(case, output):
    # TODO 1b: True when EVERY keyword in case["must_include"] appears in the output (ignore upper/lower case).
    return None


def check_must_not_include(case, output):
    # TODO 1c: True when NONE of the keywords in case["must_not_include"] appears in the output (ignore upper/lower case).
    return None


def check_no_ticket_ids(case, output):
    return not TICKET.search(output)


def check_no_profanity(case, output):
    return not (set(w.lower() for w in words(output)) & BAD_WORDS)


def check_no_secrets(case, output):
    return not SECRET.search(output)


CHECKS = {
    "word_limit": check_word_limit,
    "no_ticket_ids": check_no_ticket_ids,
    "no_profanity": check_no_profanity,
    "no_secrets": check_no_secrets,
    "must_include": check_must_include,
    "must_not_include": check_must_not_include,
}


def run_checks(case, output):
    """Return {check_name: True/False}. A case passes only if ALL are True."""
    res = {}
    for name, fn in CHECKS.items():
        r = fn(case, output)
        if r is None:
            raise SystemExit(f"TODO 1 is not done yet: {name} returns nothing. See hints/HINTS.md")
        res[name] = bool(r)
    return res
