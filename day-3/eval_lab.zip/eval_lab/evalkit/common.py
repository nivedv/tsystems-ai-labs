"""Shared helpers: settings, the model client, JSON files. The API key is never printed."""
import json
import os
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
REQUIRED = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_API_VERSION", "AZURE_OPENAI_DEPLOYMENT"]


def load_env():
    p = ROOT / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def get_client():
    load_env()
    miss = [k for k in REQUIRED if not os.environ.get(k)]
    if miss:
        print("Missing settings:", ", ".join(miss), "\nCopy .env.example to .env and fill it in (or set them in CI secrets).")
        sys.exit(2)
    from openai import AzureOpenAI
    client = AzureOpenAI(azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"], api_key=os.environ["AZURE_OPENAI_API_KEY"],
                         api_version=os.environ["AZURE_OPENAI_API_VERSION"])
    return client, os.environ["AZURE_OPENAI_DEPLOYMENT"]


def call_model(client, deployment, messages, **extra):
    t0 = time.time()
    resp = client.chat.completions.create(model=deployment, messages=messages, **extra)
    return resp, time.time() - t0


HINTS = {"AuthenticationError": "401: key wrong or not loaded in THIS terminal.", "NotFoundError": "404: the DEPLOYMENT name is wrong.",
         "RateLimitError": "429: wait 30 seconds and retry.", "APIConnectionError": "Network problem: VPN, proxy, or endpoint URL.",
         "BadRequestError": "400: check the API version or a parameter your model does not accept."}


def explain_error(e):
    print(f"\nCALL FAILED: {type(e).__name__}\n{str(e)[:300]}\nHint: {HINTS.get(type(e).__name__, 'Read the message, then check endpoint, key, deployment, API version.')}")


def read_json(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def write_json(rel, obj):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
