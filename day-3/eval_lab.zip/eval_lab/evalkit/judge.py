"""LLM-as-judge: a second model call that grades the first one against a written rubric."""
import json
import re

from evalkit import common

JUDGE_SYSTEM = ""   # TODO 2a: write the rubric: what is PASS, what is FAIL, the JSON reply format (reason first, then verdict)


def build_judge_messages(entries, summary):
    # TODO 2b: return [system message, user message]. The user message shows the ENTRIES and the SUMMARY.
    return None


def parse_verdict(text):
    """Return (verdict, reason). verdict is 'PASS', 'FAIL' or None when the reply cannot be read."""
    m = re.search(r"\{.*\}", text or "", re.S)
    if m:
        try:
            d = json.loads(m.group(0))
            v = str(d.get("verdict", "")).strip().upper()
            if v in ("PASS", "FAIL"):
                return v, str(d.get("reason", ""))
        except json.JSONDecodeError:
            pass
    m = re.search(r"\b(PASS|FAIL)\b", (text or "").upper())
    return (m.group(1), (text or "")[:120]) if m else (None, (text or "")[:120])


def judge_one(client, deployment, entries, summary):
    msgs = build_judge_messages(entries, summary)
    if not msgs:
        raise SystemExit("TODO 2 is not done yet: build_judge_messages returns nothing. See hints/HINTS.md")
    resp, _ = common.call_model(client, deployment, msgs)
    v, reason = parse_verdict(resp.choices[0].message.content)
    return v, reason, resp.usage.total_tokens
