"""Numbers: overlap with a reference, and agreement between a judge and humans."""
import re


def tokens(text):
    return re.findall(r"[a-z0-9+]+", text.lower())


def rouge1_f1(reference, output):
    """Reference-based score: overlap of single words (unigrams), as an F1. 1.0 = same words."""
    ref, out = tokens(reference), tokens(output)
    if not ref or not out:
        return 0.0
    common = 0
    pool = list(ref)
    for w in out:
        if w in pool:
            pool.remove(w)
            common += 1
    if common == 0:
        return 0.0
    p, r = common / len(out), common / len(ref)
    return 2 * p * r / (p + r)


def confusion(human, judge):
    # TODO 3a: human and judge are lists of 'PASS'/'FAIL' (PASS = positive).
    #          Return {"tp":..., "tn":..., "fp":..., "fn":...}.  fp = judge PASS but human FAIL.
    return None


def cohens_kappa(a, b):
    # TODO 3b: kappa = (po - pe) / (1 - pe).  po = share of items where a and b agree.
    #          pe = sum over each label of (share of a with that label) * (share of b with that label).
    return None
