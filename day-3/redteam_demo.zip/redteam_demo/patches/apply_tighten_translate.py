"""Trainer patch 1 (demo step 10): remove the false positive. Run from the repo root:
    python patches/apply_tighten_translate.py
Same edit you can type by hand in helper/guardrails.py (find the line marked 'DEMO: this pattern is deliberately LOOSE')."""
from pathlib import Path

p = Path("helper/guardrails.py")
s = p.read_text(encoding="utf-8")
old = '    r"translate\\s+.{0,20}(instructions|rules|prompt)",'
new = '    r"translate\\s+(your|the)\\s+(system\\s+)?(instructions|rules|prompt)",'
if new in s:
    print("already patched")
elif old not in s:
    raise SystemExit("could not find the loose pattern - is this the original guardrails.py?")
else:
    p.write_text(s.replace(old, new), encoding="utf-8")
    print("patched: the translate pattern now only matches 'translate your/the (system) instructions/rules/prompt'")
