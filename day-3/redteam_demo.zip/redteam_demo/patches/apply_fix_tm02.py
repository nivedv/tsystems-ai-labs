"""Trainer patch 2 (demo step 11): fix the last open finding, TM-02 (attacker text planted in a ticket).
Run from the repo root:
    python patches/apply_fix_tm02.py
It adds _strip_external() to helper/guardrails.py and applies it to ticket title and description."""
from pathlib import Path

p = Path("helper/guardrails.py")
s = p.read_text(encoding="utf-8")
if "_strip_external" in s:
    raise SystemExit("already patched")

helper = '''EXT_ADDR = re.compile(r"[\\w.+-]+@([\\w-]+(?:\\.[\\w-]+)+)")


def _strip_external(text):
    """Ticket text is read by humans and agents later. Remove addresses outside our own domains."""
    return EXT_ADDR.sub(
        lambda m: m.group(0)
        if any(m.group(1).lower() == d or m.group(1).lower().endswith("." + d) for d in ALLOWED_DOMAINS)
        else "[address removed]",
        text,
    )


def authorize_tool('''
old_t = '    title = SECRET_RE.sub("[redacted]", str(args.get("title", ""))[:80])\n    desc = SECRET_RE.sub("[redacted]", str(args.get("description", ""))[:500])'
new_t = '    title = _strip_external(SECRET_RE.sub("[redacted]", str(args.get("title", ""))[:80]))\n    desc = _strip_external(SECRET_RE.sub("[redacted]", str(args.get("description", ""))[:500]))'
if old_t not in s or "def authorize_tool(" not in s:
    raise SystemExit("could not find the ticket lines - is this the original guardrails.py?")
s = s.replace("def authorize_tool(", helper, 1).replace(old_t, new_t)
p.write_text(s, encoding="utf-8")
print("patched: ticket text no longer carries addresses outside our domains")
