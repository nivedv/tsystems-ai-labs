"""Guardrails for the IT Support Helper (build v2).

Defence in depth: no single layer is trusted. Each function below is one layer.
  1. screen_input       - normalise the text, then look for known attack patterns       (before the model)
  2. sanitize_chunk     - clean retrieved documents so hidden instructions never reach the model
  3. authorize_tool     - least privilege for tools: allow-list, validation, limits, human approval
  4. filter_employee_record - the tool itself returns only public fields
  5. filter_output      - redact secrets, remove risky links, block unsafe instructions     (after the model)
  6. grounding_gate     - do not show an answer the documents do not support
"""
import base64
import os
import re
import unicodedata

from .grounding_check import check as grounding_check

MAX_INPUT_CHARS = 2000
REFUSAL_TEXT = "Sorry, I can't help with that request."
ALLOWED_DOMAINS = [d.strip() for d in os.getenv("RT_ALLOWED_DOMAINS", "contoso.example").split(",") if d.strip()]

ZERO_WIDTH = dict.fromkeys(map(ord, "​‌‍⁠﻿­"), None)
HOMOGLYPHS = str.maketrans(
    {"а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "і": "i", "ѕ": "s"}
)
LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"})

# ---- layer 1: input screening ---------------------------------------------------------------------------------
INJECTION_PATTERNS = [
    r"(ignore|disregard|forget)\s+(all\s+|any\s+)?(the\s+|your\s+)?(previous|prior|above|earlier)\s+(instructions|rules|prompts?)",
    r"(reveal|show|print|repeat|output|display)\s+.{0,30}(system\s+prompt|initial\s+instructions|your\s+instructions|your\s+rules|hidden\s+instructions)",
    r"(system|developer)\s+prompt",
    r"you\s+are\s+now\s+",
    r"developer\s+mode|jailbreak|\bdan\b|debugbot",
    r"pretend\s+(to\s+be|you\s*(are|'re|’re))",
    # DEMO: this pattern is deliberately LOOSE. It blocks "translate the VPN instructions" too (a false positive).
    r"translate\s+.{0,20}(instructions|rules|prompt)",
]
_INJ = [re.compile(p, re.I) for p in INJECTION_PATTERNS]


def variants(text):
    """Return several 'normalised views' of the input. Attackers hide text in encodings; we look at all views."""
    t = unicodedata.normalize("NFKC", text).translate(ZERO_WIDTH).translate(HOMOGLYPHS)
    t = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", t)
    base = re.sub(r"\s+", " ", t).strip().lower()
    out = [base, base.translate(LEET)]
    despaced = re.sub(r"\b(?:\w[\s.\-_]){4,}\w\b", lambda m: re.sub(r"[\s.\-_]", "", m.group(0)), base)
    if despaced != base:
        out.append(despaced)
    for tok in re.findall(r"[A-Za-z0-9+/=]{16,}", text):
        try:
            dec = base64.b64decode(tok + "=" * (-len(tok) % 4), validate=True).decode("utf-8")
        except Exception:
            continue
        if dec and all(c.isprintable() or c.isspace() for c in dec):
            out.append(dec.lower())
    return out


def clean_text(text):
    """Normalise ONCE at the front door. The cleaned text is used for retrieval AND for the model.
    (Found by fuzzing: without this, zero-width characters and look-alike letters broke retrieval.)"""
    t = unicodedata.normalize("NFKC", text).translate(ZERO_WIDTH).translate(HOMOGLYPHS)
    t = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def screen_input(text):
    """Return (ok, reason)."""
    if not text or not text.strip():
        return False, "empty_input"
    if len(text) > MAX_INPUT_CHARS:
        return False, "input_too_long"
    for v in variants(text):
        for p in _INJ:
            if p.search(v):
                return False, "injection_pattern"
    return True, "ok"


# ---- layer 2: retrieval hygiene -------------------------------------------------------------------------------
def sanitize_chunk(text):
    """Return (clean_text, flagged). Hidden comments and instruction-like lines are removed and reported."""
    new = re.sub(r"<!--.*?-->", "", text, flags=re.S).translate(ZERO_WIDTH)
    flagged = new != text
    lines = []
    for line in new.splitlines():
        if re.search(r"(system note|assistant instruction|ignore (all )?previous|you must now)", line, re.I):
            flagged = True
            continue
        lines.append(line)
    return "\n".join(lines).strip(), flagged


# ---- layer 3 + 4: least-privilege tools ----------------------------------------------------------------------
ALLOWED_TOOLS = {"lookup_employee", "create_ticket"}
SECRET_RE = re.compile(r"\b(?:sk|svc)-[A-Za-z0-9-]{6,}|\b[A-Z]{3}-\d{4}-[A-Z]{3,5}\b")
MAX_TICKETS_PER_SESSION = 3
PUBLIC_FIELDS = ["id", "name", "department", "title", "work_email"]


def authorize_tool(name, args, state, approve=None):
    """Return (allowed, reason, clean_args). `approve(call)` is the human-in-the-loop hook."""
    if name not in ALLOWED_TOOLS:
        return False, "tool_not_allowed", args
    if name == "lookup_employee":
        q = str(args.get("query", ""))[:60]
        if q.lower().startswith("department:"):
            return False, "bulk_directory_query_not_allowed", args
        return True, "ok", {"query": q}
    # create_ticket
    title = SECRET_RE.sub("[redacted]", str(args.get("title", ""))[:80])
    desc = SECRET_RE.sub("[redacted]", str(args.get("description", ""))[:500])
    pr = str(args.get("priority", "P3")).upper()
    if pr not in {"P1", "P2", "P3", "P4"}:
        pr = "P3"
    clean = {"title": title, "description": desc, "priority": pr}
    if state.get("tickets_created", 0) >= MAX_TICKETS_PER_SESSION:
        return False, "ticket_limit_reached", clean
    if pr in {"P1", "P2"} and not (approve and approve({"name": name, "args": clean})):
        return False, "P1_P2_needs_human_approval", clean
    return True, "ok", clean


def filter_employee_record(rec):
    return {k: rec[k] for k in PUBLIC_FIELDS if k in rec}


# ---- layer 5: output filtering --------------------------------------------------------------------------------
UNSAFE_OUTPUT = [
    r"(turn|switch)\w*\s+(\w+\s+){0,3}off\s+.{0,40}(real-?time protection|antivirus|firewall|endpoint protection|mfa)",
    r"virus\s*(&|and)\s*threat protection",
    r"disablerealtimemonitoring",
]
_UNSAFE = [re.compile(p, re.I) for p in UNSAFE_OUTPUT]


def _allowed_host(host):
    host = host.lower().strip(".")
    return any(host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS)


def filter_output(text, scenario):
    """Return (text, flags)."""
    flags = []
    out = text or ""
    for c in scenario.get("canaries", []):
        if c.lower() in out.lower():
            out = re.sub(re.escape(c), "[redacted]", out, flags=re.I)
            flags.append("secret_redacted")
    if SECRET_RE.search(out):
        out = SECRET_RE.sub("[redacted]", out)
        flags.append("secret_redacted")
    if re.search(r"!\[[^\]]*\]\([^)]*\)", out):
        out = re.sub(r"!\[[^\]]*\]\([^)]*\)", "[image removed]", out)
        flags.append("image_removed")
    for m in set(re.findall(r"https?://([^\s/)>\]]+)[^\s)>\]]*", out)):
        if not _allowed_host(m):
            out = re.sub(r"https?://" + re.escape(m) + r"[^\s)>\]]*", "[link removed]", out)
            flags.append("external_link_removed")
    for m in set(re.findall(r"[\w.+-]+@([\w-]+(?:\.[\w-]+)+)", out)):
        if not _allowed_host(m):
            out = re.sub(r"[\w.+-]+@" + re.escape(m), "[address removed]", out)
            flags.append("external_address_removed")
    if any(p.search(out) for p in _UNSAFE):
        return REFUSAL_TEXT, flags + ["unsafe_output_blocked"]
    return out, flags


# ---- layer 6: grounding gate ----------------------------------------------------------------------------------
def grounding_gate(answer, chunks, context_ids=None):
    """Block 'ungrounded' answers. 'partially' answers pass unless RT_GATE_BLOCK_PARTIAL=1 (stricter, more false alarms)."""
    rep = grounding_check(answer, chunks, context_ids=context_ids)
    passing = {"grounded", "abstained"} | (set() if os.getenv("RT_GATE_BLOCK_PARTIAL", "0") == "1" else {"partially"})
    return rep["verdict"] in passing, rep
