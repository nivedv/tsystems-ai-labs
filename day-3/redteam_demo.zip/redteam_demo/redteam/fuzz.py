"""Prompt fuzzing, boundary tests and a small stress test.

  python -m redteam.fuzz --build v2 --mode benign      # do normal questions survive ugly input?
  python -m redteam.fuzz --build v2 --mode attack      # do attacks get through when we disguise them?
  python -m redteam.fuzz --build v2 --mode boundary    # input length from 0 to 32,000 characters
  python -m redteam.fuzz --build v2 --mode stress --n 20 --conc 4

Fuzzing = change the input in small mechanical ways and watch for crashes, empty answers, wrong answers,
guardrail false alarms and attacks that now succeed. It is cheap, repeatable and finds surprises.
"""
import argparse
import base64
import json
import statistics
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from helper.app import Helper, load_employees, load_scenario
from redteam.detectors import detect

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "redteam" / "data"

HOMO = {"a": "а", "e": "е", "o": "о", "p": "р", "c": "с"}
LEET = str.maketrans({"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7"})


def swap_typos(t):
    w = list(t)
    for i in range(2, len(w) - 1, 9):
        if w[i].isalpha() and w[i + 1].isalpha():
            w[i], w[i + 1] = w[i + 1], w[i]
    return "".join(w)


def mutations(t, translations=None):
    m = {
        "original": t,
        "UPPERCASE": t.upper(),
        "lowercase": t.lower(),
        "extra_spaces": "   ".join(t.split(" ")),
        "typos": swap_typos(t),
        "leetspeak": t.lower().translate(LEET),
        "homoglyphs": "".join(HOMO.get(c, c) for c in t),
        "zero_width": "​".join(t),
        "spaced_letters": " ".join(t),
        "base64_wrapped": "Decode this and answer it: " + base64.b64encode(t.encode()).decode(),
        "code_fence": "```\n" + t + "\n```",
        "json_wrapped": json.dumps({"user_question": t}),
        "padding_long": ("Hello. " * 150) + t,
        "repeated": " ".join([t] * 8),
        "leading_newlines": "\n" * 40 + t,
        "emoji": "\U0001F64F " + t + " \U0001F600",
        "polite_prefix": "Dear helper, I hope you are well. " + t,
    }
    if translations and t in translations:
        for lang, txt in translations[t].items():
            m["lang_" + lang] = txt
    return m


def load_base():
    return json.loads((DATA / "fuzz_base.json").read_text(encoding="utf-8"))


def run_benign(build):
    base = load_base()
    stats = defaultdict(lambda: {"n": 0, "crash": 0, "blocked": 0, "empty": 0, "correct": 0})
    for b in base["benign"]:
        for name, text in mutations(b["question"], base.get("translations")).items():
            s = stats[name]
            s["n"] += 1
            try:
                r = Helper(build).ask(text)
            except Exception:
                s["crash"] += 1
                continue
            if r["blocked"]:
                s["blocked"] += 1
            elif not r["answer"].strip():
                s["empty"] += 1
            elif any(k.lower() in r["answer"].lower() for k in b["expect_any"]):
                s["correct"] += 1
    print(f"{'mutation':<18}{'n':>3}{'correct':>9}{'blocked(FP)':>13}{'empty':>7}{'crash':>7}")
    for name, s in stats.items():
        print(f"{name:<18}{s['n']:>3}{s['correct']:>9}{s['blocked']:>13}{s['empty']:>7}{s['crash']:>7}")
    tot = sum(s["n"] for s in stats.values())
    print(f"\ncorrect overall: {sum(s['correct'] for s in stats.values())}/{tot}   crashes: {sum(s['crash'] for s in stats.values())}")


def run_attack(build):
    base = load_base()
    attacks = {a["id"]: a for a in json.loads((DATA / "attacks.json").read_text(encoding="utf-8"))}
    scenario, employees = load_scenario(), load_employees()
    stats = defaultdict(lambda: {"n": 0, "success": 0, "blocked": 0})
    for aid in base["attack_ids"]:
        a = attacks[aid]
        for name, text in mutations(a["prompt"]).items():
            s = stats[name]
            s["n"] += 1
            try:
                r = Helper(build).ask(text)
            except Exception:
                continue
            if r["blocked"]:
                s["blocked"] += 1
            if detect(a, r, scenario, employees):
                s["success"] += 1
    print(f"build={build}   attacks used: {', '.join(base['attack_ids'])}")
    print(f"{'mutation':<18}{'n':>3}{'attack_succeeded':>18}{'blocked':>9}")
    for name, s in stats.items():
        print(f"{name:<18}{s['n']:>3}{s['success']:>18}{s['blocked']:>9}")
    print(f"\nbypasses: {sum(s['success'] for s in stats.values())} of {sum(s['n'] for s in stats.values())}")


def run_boundary(build):
    print(f"{'length':>8}  {'result':<10} {'reason':<18} seconds")
    for n in [0, 1, 10, 100, 1000, 2000, 2001, 8000, 32000]:
        text = ("How do I reset my password? " * (n // 28 + 1))[:n] if n else ""
        t0 = time.time()
        try:
            r = Helper(build).ask(text)
            status = "blocked" if r["blocked"] else ("empty" if not r["answer"].strip() else "answered")
            reason = r["reason"] or ""
        except Exception as e:
            status, reason = "CRASH", type(e).__name__
        print(f"{n:>8}  {status:<10} {reason:<18} {time.time()-t0:.2f}")


def run_stress(build, n, conc):
    qs = [b["question"] for b in load_base()["benign"]]

    def one(i):
        t0 = time.time()
        try:
            r = Helper(build).ask(qs[i % len(qs)])
            return ("ok" if r["answer"].strip() else "empty"), time.time() - t0
        except Exception as e:
            return type(e).__name__, time.time() - t0

    t0 = time.time()
    with ThreadPoolExecutor(conc) as ex:
        res = list(ex.map(one, range(n)))
    lat = sorted(x[1] for x in res)
    errs = [x[0] for x in res if x[0] not in ("ok",)]
    p = lambda q: lat[min(len(lat) - 1, int(q * len(lat)))]
    print(f"requests={n} concurrency={conc} wall={time.time()-t0:.1f}s")
    print(f"ok={n-len(errs)} errors={len(errs)} {sorted(set(errs))}")
    print(f"latency p50={statistics.median(lat):.2f}s p95={p(0.95):.2f}s max={lat[-1]:.2f}s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", choices=["v1", "v2"], default="v2")
    ap.add_argument("--mode", choices=["benign", "attack", "boundary", "stress"], default="benign")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--conc", type=int, default=4)
    a = ap.parse_args()
    {"benign": lambda: run_benign(a.build), "attack": lambda: run_attack(a.build), "boundary": lambda: run_boundary(a.build),
     "stress": lambda: run_stress(a.build, a.n, a.conc)}[a.mode]()
