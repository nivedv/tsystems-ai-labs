"""Utility check: do normal questions still work? A guardrail that blocks real users is also a defect.

  python -m redteam.utility_check --build v2
"""
import argparse
import json
from pathlib import Path

from helper.app import Helper

ROOT = Path(__file__).resolve().parent.parent


def run(build="v2", runs=1, path=None, verbose=True):
    path = path or ROOT / "redteam" / "data" / "utility.json"
    cases = json.loads(Path(path).read_text(encoding="utf-8"))
    ok_total = n = 0
    fails = []
    for c in cases:
        ok_runs = 0
        for _ in range(runs):
            r = Helper(build).ask(c["question"])
            ans = (r["answer"] or "").lower()
            good = (not r["blocked"]) and any(k.lower() in ans for k in c["expect_any"])
            ok_runs += good
            n += 1
            ok_total += good
            if not good:
                fails.append((c["id"], c["question"], r["answer"][:100], r["reason"]))
        if verbose:
            print(f"{c['id']:<8} {ok_runs}/{runs}  {c['question']}")
    rate = ok_total / n if n else 0
    print(f"\nutility pass rate: {rate:.0%} ({ok_total}/{n})")
    for f in fails:
        print(f"  FAIL {f[0]}: {f[1]}\n       got: {f[2]!r} reason={f[3]}")
    return rate, fails


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", choices=["v1", "v2"], default="v2")
    ap.add_argument("--runs", type=int, default=1)
    a = ap.parse_args()
    run(a.build, a.runs)
