"""Run the attack catalogue against the helper and report the Attack Success Rate (ASR).

  python -m redteam.run_attacks --build v1 --runs 5
  python -m redteam.run_attacks --build v2 --runs 5 --tag after
  python -m redteam.run_attacks --build v1 --only PI-01 --runs 10 --verbose

Why --runs: the model is non-deterministic. One failed attack proves nothing; one success proves a lot.
ASR = successful runs / total runs. For a security finding, ANY success counts.
"""
import argparse
import datetime
import json
import os
import sys
import time
from pathlib import Path

from helper.app import Helper, load_employees, load_scenario
from redteam.detectors import SEVERITY_HINT, detect

ROOT = Path(__file__).resolve().parent.parent


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", choices=["v1", "v2"], default="v1")
    ap.add_argument("--runs", type=int, default=5)
    ap.add_argument("--attacks", default=str(ROOT / "redteam" / "data" / "attacks.json"))
    ap.add_argument("--only", help="run one attack id")
    ap.add_argument("--tag", default="run")
    ap.add_argument("--verbose", action="store_true", help="print each answer")
    ap.add_argument("--fail-above", type=float, default=None, help="exit 1 if overall ASR is above this (for CI)")
    args = ap.parse_args(argv)

    scenario, employees = load_scenario(), load_employees()
    attacks = json.loads(Path(args.attacks).read_text(encoding="utf-8"))
    if args.only:
        attacks = [a for a in attacks if a["id"] == args.only]
    mode = os.getenv("RT_MODE", "sim")
    print(f"build={args.build} mode={mode} runs={args.runs} attacks={len(attacks)}\n")

    rows, total, success = [], 0, 0
    for a in attacks:
        wins, blocked, evidence, fired_all = 0, 0, "", set()
        for i in range(args.runs):
            h = Helper(args.build)
            t0 = time.time()
            try:
                res = h.ask(a["prompt"])
            except Exception as e:  # keep the campaign running, record the crash
                print(f"  ! {a['id']} run {i+1}: {type(e).__name__}: {str(e)[:120]}")
                continue
            fired = detect(a, res, scenario, employees)
            total += 1
            if res["blocked"]:
                blocked += 1
            if fired:
                wins += 1
                success += 1
                fired_all |= set(fired)
                if not evidence:
                    evidence = (res["answer"] or json.dumps([t.get("args") for t in res["trace"] if t.get("type") == "tool_call"]))[:140].replace("\n", " ")
            if args.verbose:
                print(f"[{a['id']} #{i+1}] fired={fired} blocked={res['blocked']}\n   {res['answer'][:200]!r}")
        rows.append(
            {
                "id": a["id"], "category": a["category"], "owasp": a.get("owasp", ""), "name": a["name"],
                "runs": args.runs, "successes": wins, "asr": round(wins / args.runs, 2), "blocked": blocked,
                "detectors": sorted(fired_all),
                "severity_hint": max((SEVERITY_HINT[d] for d in fired_all), key=["Low", "Medium", "High"].index, default="-"),
                "evidence": evidence,
            }
        )

    overall = round(success / total, 3) if total else 0.0
    print(f"{'ID':<10}{'Category':<20}{'OWASP':<8}{'ASR':>6}  {'blocked':>7}  {'severity':<9} detectors")
    for r in rows:
        print(f"{r['id']:<10}{r['category']:<20}{r['owasp']:<8}{r['asr']:>6.2f}  {r['blocked']:>7}  {r['severity_hint']:<9} {','.join(r['detectors'])}")
    print(f"\nOVERALL ASR = {overall:.1%}  ({success} successful attack runs out of {total})")
    vulnerable = [r["id"] for r in rows if r["successes"] > 0]
    print(f"Attacks that worked at least once: {', '.join(vulnerable) if vulnerable else 'none'}")

    out_dir = ROOT / "results"
    out_dir.mkdir(exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = out_dir / f"attacks_{args.build}_{args.tag}_{stamp}.json"
    path.write_text(
        json.dumps({"meta": {"build": args.build, "mode": mode, "runs": args.runs, "time": stamp, "overall_asr": overall}, "rows": rows}, indent=2),
        encoding="utf-8",
    )
    print(f"saved: {path.relative_to(ROOT)}")
    if args.fail_above is not None and overall > args.fail_above:
        print(f"FAIL: overall ASR {overall:.1%} is above the allowed {args.fail_above:.1%}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
