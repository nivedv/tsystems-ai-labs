# Day 3 Trainer Demo: Red-Teaming the IT Support Helper

**Private trainer repo.** Learners get `redteam_lab` instead. Open **TRAINER_GUIDE.md** first.

| Item | Purpose |
|---|---|
| `TRAINER_GUIDE.md` | Pre-flight, run-of-show, 12 demo steps with exact commands, Say lines, expected numbers, failure table |
| `worksheets/FINDING_EXAMPLE.md` | A finished finding report to show on screen (shows the standard learners must meet) |
| `helper/` | The target: IT Support Helper, builds `v1` (weak) and `v2` (hardened) |
| `helper/guardrails.py` | Six guardrail layers. Shipped **unpatched**, so the two live fixes in the demo work |
| `redteam/` | Toolkit: `run_attacks`, `compare`, `ask`, `utility_check`, `fuzz`, detectors, grounding check |
| `redteam/data/` | 13 attacks, 10 utility questions, fuzz base prompts, 12 grounding cases |
| `patches/` | Scripted copies of the two live edits (use if typing fails on stage) |
| `ci/redteam.yml` | Stretch: red-team gate in CI (not tested live) |

Quick start (Windows PowerShell):
```powershell
python -m venv .venv ; .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      # fill in endpoint, key, deployment, API version
python -m redteam.check_env
```
`RT_MODE=sim` runs everything offline with a rule-based simulator. **The simulator is not a model.** It makes the demo repeatable; live gpt-4.1 numbers will differ.
