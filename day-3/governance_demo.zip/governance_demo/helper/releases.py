"""Model and version control: a release is a manifest that pins EVERYTHING that can change the behaviour.

  model deployment + API version | system prompt hash | knowledge-base hash | policy hash | guardrail code hash
plus: owner, evaluation evidence, required approvals. If any pinned item changes after sign-off, integrity fails
and the release needs a new approval. Promotion and rollback only move a pointer in registry.json.
"""
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REL = ROOT / "releases"
REQUIRED_ROLES = ["product_owner", "security", "ai_quality"]


def _sha_files(paths):
    h = hashlib.sha256()
    for p in sorted(paths):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()[:12]


def fingerprints():
    from . import app
    from .policy import load

    h = ROOT / "helper"
    return {
        "model_deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4.1"),
        "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "(set in .env)"),
        "prompt_hash": hashlib.sha256((app.SYSTEM_V2).encode()).hexdigest()[:12],
        "kb_hash": _sha_files(list((h / "data" / "kb").glob("*.md"))),
        "policy_hash": load()["_hash"],
        "guardrail_hash": _sha_files([h / "guardrails.py", h / "pii.py", h / "safety.py", h / "lang.py"]),
    }


def _registry():
    p = REL / "registry.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"current": None, "previous": None, "history": []}


def _save_registry(r):
    REL.mkdir(exist_ok=True)
    (REL / "registry.json").write_text(json.dumps(r, indent=2), encoding="utf-8")


def manifest_path(rid):
    return REL / f"{rid}.json"


def load_manifest(rid):
    return json.loads(manifest_path(rid).read_text(encoding="utf-8"))


def save_manifest(m):
    REL.mkdir(exist_ok=True)
    manifest_path(m["release"]).write_text(json.dumps(m, indent=2), encoding="utf-8")


def create(rid, owner, notes):
    m = {"release": rid, "created": time.strftime("%Y-%m-%d"), "owner": owner, "notes": notes,
         "pinned": fingerprints(), "evidence": {}, "approvals": [], "status": "draft"}
    save_manifest(m)
    return m


def integrity(rid):
    """Return list of pinned items that changed since the manifest was written."""
    m, now = load_manifest(rid), fingerprints()
    return [k for k, v in m["pinned"].items() if k != "api_version" and now.get(k) != v]


def missing_approvals(m):
    got = {a["role"] for a in m["approvals"] if a.get("decision") == "approve"}
    return [r for r in REQUIRED_ROLES if r not in got]


def approve(rid, role, name, decision="approve", comment=""):
    m = load_manifest(rid)
    m["approvals"] = [a for a in m["approvals"] if a["role"] != role]
    m["approvals"].append({"role": role, "name": name, "decision": decision, "comment": comment, "date": time.strftime("%Y-%m-%d")})
    save_manifest(m)
    return m


def current():
    return _registry()["current"]


def promote(rid):
    m = load_manifest(rid)
    gate = m.get("evidence", {}).get("gate")
    if not gate or gate.get("status") != "PASS":
        return False, "release gate has not passed"
    if integrity(rid):
        return False, "pinned items changed since the gate ran: " + ", ".join(integrity(rid))
    if missing_approvals(m):
        return False, "missing approvals: " + ", ".join(missing_approvals(m))
    r = _registry()
    r["previous"], r["current"] = r["current"], rid
    r["history"].append({"ts": time.strftime("%Y-%m-%d %H:%M"), "action": "promote", "release": rid})
    m["status"] = "live"
    save_manifest(m)
    _save_registry(r)
    return True, f"{rid} is live (previous: {r['previous']})"


def rollback(reason):
    r = _registry()
    if not r["previous"]:
        return False, "no previous release to roll back to"
    bad = r["current"]
    r["current"], r["previous"] = r["previous"], None
    r["history"].append({"ts": time.strftime("%Y-%m-%d %H:%M"), "action": "rollback", "from": bad, "to": r["current"], "reason": reason})
    _save_registry(r)
    return True, f"rolled back {bad} -> {r['current']}"
