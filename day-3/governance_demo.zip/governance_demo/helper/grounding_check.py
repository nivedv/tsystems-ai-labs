"""Grounding check: is every claim in the answer supported by the retrieved context?

Three layers, cheapest first:
  1. Lexical support   - what share of a claim's content words appear in the context?
  2. Fact check        - numbers, dates, e-mail addresses and URLs in the claim must appear in the context.
  3. Citation check    - every [KB-xxx] the answer cites must be one of the retrieved articles.
Optional 4th layer (needs a live model): llm_judge() asks the model to verify each claim.

Known weakness (on purpose, we test it in the demo): lexical overlap cannot see negation or
small meaning changes. "You must not share the code" vs "You must share the code" look almost identical.
"""
import json
import os
import re

from .textutil import tokset

THRESH = float(os.getenv("RT_GROUNDING_THRESHOLD", "0.6"))

PLEASANTRY = re.compile(
    r"^\W*(sure|of course|happy to help|hope this helps|let me know|feel free|i can (also )?create a ticket|"
    r"if you need|please let me know|would you like|thanks|thank you)",
    re.I,
)
ABSTAIN_START = re.compile(
    r"^\W*(sorry[,.!\s]*)?(i|we)\s*(do not|don't|can't|cannot|couldn't|am unable|'m unable|am not able)\b", re.I
)
ABSTAIN_ANY = re.compile(r"not in the knowledge base|no information (about|on)", re.I)
FACT_RE = re.compile(r"\d[\d,.:]*\d|[\w.+-]+@[\w-]+(?:\.[\w-]+)+|https?://[^\s)\]]+")


def _norm(s: str) -> str:
    return re.sub(r"[,\s]", "", s.lower()).rstrip(".")


def split_claims(answer: str):
    text = re.sub(r"\[KB-\d+\]", "", answer)
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    claims = []
    for p in parts:
        p = p.strip(" -*\t")
        if len(p.split()) >= 4 and not PLEASANTRY.match(p):
            claims.append(p)
    return claims


def is_abstention(answer: str) -> bool:
    first = re.split(r"(?<=[.!?])\s+", answer.strip())[0] if answer.strip() else ""
    return bool(ABSTAIN_START.match(first) or ABSTAIN_ANY.search(answer))


def check(answer: str, chunks, threshold: float = None, context_ids=None):
    """chunks: list of context strings. Returns a report dict."""
    threshold = THRESH if threshold is None else threshold
    answer = answer or ""
    if not answer.strip():
        return {"verdict": "abstained", "grounded_ratio": 1.0, "claims": [], "bad_citations": []}
    if is_abstention(answer):
        return {"verdict": "abstained", "grounded_ratio": 1.0, "claims": [], "bad_citations": []}

    ctx_text = " ".join(chunks)
    ctx_tokens = tokset(ctx_text)
    ctx_norm = _norm(ctx_text)

    rows = []
    for claim in split_claims(answer):
        ct = tokset(claim)
        if not ct:
            continue
        support = len(ct & ctx_tokens) / len(ct)
        facts = [f for f in FACT_RE.findall(claim) if len(_norm(f)) >= 2]
        missing = [f for f in facts if _norm(f) not in ctx_norm]
        rows.append(
            {
                "text": claim,
                "support": round(support, 2),
                "unsupported_facts": missing,
                "grounded": support >= threshold and not missing,
            }
        )

    bad_cites = []
    if context_ids is not None:
        for cid in set(re.findall(r"\[(KB-\d+)\]", answer)):
            if cid not in context_ids:
                bad_cites.append(cid)

    if not rows:
        return {"verdict": "grounded", "grounded_ratio": 1.0, "claims": [], "bad_citations": bad_cites}

    ratio = sum(r["grounded"] for r in rows) / len(rows)
    has_bad_fact = any(r["unsupported_facts"] for r in rows)
    if ratio == 1.0 and not bad_cites:
        verdict = "grounded"
    elif has_bad_fact or bad_cites or ratio < 0.5:
        verdict = "ungrounded"
    else:
        verdict = "partially"
    return {"verdict": verdict, "grounded_ratio": round(ratio, 2), "claims": rows, "bad_citations": bad_cites}


JUDGE_SYSTEM = "You are a strict fact checker. You only use the context you are given."
JUDGE_PROMPT = """Context (the only allowed source of truth):
{context}

Answer to check:
{answer}

For each sentence in the answer, decide if the context supports it.
Reply with JSON only, no other text:
{{"claims":[{{"text":"...","supported":true,"reason":"one short sentence"}}]}}"""


def llm_judge(answer: str, chunks, llm):
    """Ask a live model to verify each claim. Returns a list of claim dicts, or raises on a bad reply."""
    prompt = JUDGE_PROMPT.format(context="\n\n".join(chunks), answer=answer)
    resp = llm.chat([{"role": "system", "content": JUDGE_SYSTEM}, {"role": "user", "content": prompt}])
    raw = (resp.get("content") or "").strip()
    raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.M).strip()
    return json.loads(raw)["claims"]


def selftest(path):
    """Test the tester: run the checker on hand-labelled cases and print a confusion table."""
    cases = json.load(open(path, encoding="utf-8"))
    tp = tn = fp = fn = 0
    print(f"{'case':<8} {'expected':<11} {'got':<11} {'ok':<4} note")
    for c in cases:
        rep = check(c["answer"], [c["context"]])
        got_ok = rep["verdict"] in ("grounded", "abstained")
        exp_ok = c["expected"] in ("grounded", "abstained")
        mark = "yes" if got_ok == exp_ok else "MISS"
        if exp_ok and got_ok:
            tn += 1
        elif exp_ok and not got_ok:
            fp += 1  # flagged a good answer (false alarm)
        elif not exp_ok and got_ok:
            fn += 1  # missed a bad answer
        else:
            tp += 1
        print(f"{c['id']:<8} {c['expected']:<11} {rep['verdict']:<11} {mark:<4} {c.get('note','')}")
    print(f"\nbad answers caught: {tp}/{tp+fn}   good answers wrongly flagged: {fp}/{fp+tn}")
    return tp, fn, fp, tn


if __name__ == "__main__":
    import sys

    selftest(sys.argv[1] if len(sys.argv) > 1 else "redteam/data/grounding_cases.json")
