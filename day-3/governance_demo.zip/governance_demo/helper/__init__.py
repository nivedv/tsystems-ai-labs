try:  # load .env (RT_MODE, Azure settings) as soon as the package is imported
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass
