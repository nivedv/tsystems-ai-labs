"""Content safety (a guardrail layer, Module 6): a small local lexicon scorer.

score(text) -> {category: severity 0..6}   (0 = nothing found, 6 = very strong)

This is a teaching stand-in. In production you add a managed classifier (for example Azure AI Content Safety or the
platform content filter on your deployment) and keep this as a cheap first layer you fully control.
"""
import json
import re
from pathlib import Path

LEXICON = json.loads((Path(__file__).resolve().parent / "data" / "safety_lexicon.json").read_text(encoding="utf-8"))


def _norm(text):
    return re.sub(r"\s+", " ", text.lower()).strip()


def score(text):
    t = _norm(text)
    out = {}
    for cat, terms in LEXICON.items():
        total = sum(w for term, w in terms.items() if term in t)
        out[cat] = min(6, total)
    return out
