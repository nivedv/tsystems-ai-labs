"""PII detection and redaction (a guardrail layer, Module 6).

detect(text)  -> list of findings  {type, start, end, text}
redact(text, findings, actions) -> text with each finding replaced by [TYPE]

Rules of thumb used here:
  * check the structure (Luhn for cards) before you call something a card: fewer false alarms
  * the company's own e-mail domain is NOT personal data in this helper (work e-mail is public)
  * redact BEFORE the model sees the text: a ticket that already contains a card number cannot be un-written
"""
import re

ALLOWED_DOMAINS = ("contoso.example",)

CARD_RE = re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")
IBAN_RE = re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){3,7}(?: ?[A-Z0-9]{1,3})?\b")
NATID_RE = re.compile(r"(?<!\d)(?<!\d )\d{4} \d{4} \d{4}(?! ?\d)")
PHONE_RE = re.compile(r"(?<![\w+])\+\d{1,3}[ -]?\d[\d -]{5,12}\d(?!\d)|(?<![\w+])0\d{2,4}[ -]\d{6,8}(?!\d)")
EMAIL_RE = re.compile(r"[\w.+-]+@([\w-]+(?:\.[\w-]+)+)")


def luhn_ok(digits):
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


def detect(text, allowed_domains=ALLOWED_DOMAINS):
    found, taken = [], []

    def add(kind, m):
        s, e = m.start(), m.end()
        if any(s < b and a < e for a, b in taken):
            return
        taken.append((s, e))
        found.append({"type": kind, "start": s, "end": e, "text": m.group(0)})

    for m in CARD_RE.finditer(text):
        digits = re.sub(r"\D", "", m.group(0))
        if 13 <= len(digits) <= 19 and luhn_ok(digits):
            add("card", m)
    for m in IBAN_RE.finditer(text):
        add("iban", m)
    for m in NATID_RE.finditer(text):
        add("national_id", m)
    for m in PHONE_RE.finditer(text):
        add("phone", m)
    for m in EMAIL_RE.finditer(text):
        dom = m.group(1).lower()
        if not any(dom == d or dom.endswith("." + d) for d in allowed_domains):
            add("email_external", m)
    return sorted(found, key=lambda f: f["start"])


def redact(text, findings, actions=None):
    """Replace every finding whose action is 'redact' (or not listed) with [TYPE]."""
    out = text
    for f in sorted(findings, key=lambda f: -f["start"]):
        if actions and actions.get(f["type"]) == "allow":
            continue
        out = out[: f["start"]] + f"[{f['type'].upper()}]" + out[f["end"]:]
    return out
