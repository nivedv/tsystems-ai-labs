"""Tiny text helpers shared by retrieval, the simulator and the grounding checker."""
import re

STOP = set(
    "a an the is are was were be been to of for on in at by with and or but do does did how what when where "
    "which who why can could should would i my me we our you your it its this that these those please from "
    "there their they them if as so not no yes any some about into onto up out".split()
)


def stem(w: str) -> str:
    if len(w) > 5 and w.endswith("ing"):
        return w[:-3]
    if len(w) > 4 and w.endswith("ed"):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        return w[:-1]
    return w


def tokens(text: str):
    return [stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP]


def tokset(text: str):
    return set(tokens(text))
