"""Policy as configuration. The rules live in data/policy.json, not buried in code, so they can be reviewed,
versioned, hashed into the release manifest and changed without redeploying code."""
import hashlib
import json
import os
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"


def load(path=None):
    p = Path(path or os.getenv("GOV_POLICY") or DATA / "policy.json")
    raw = p.read_text(encoding="utf-8")
    pol = json.loads(raw)
    pol["_hash"] = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return pol
