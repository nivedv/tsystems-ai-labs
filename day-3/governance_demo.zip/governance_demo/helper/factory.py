"""One place that builds the thing under test: v1, v2 (Module 5) or gov (Module 6 governed runtime)."""


def make(build):
    if build == "gov":
        from .runtime import GovernedHelper

        return GovernedHelper()
    from .app import Helper

    return Helper(build)
