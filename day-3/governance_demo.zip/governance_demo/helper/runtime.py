"""GovernedHelper: the IT Support Helper wrapped in the Module 6 'governed runtime'.

  request -> kill switch -> budget -> language -> input PII -> input safety -> [Module 5 helper, build v2] ->
             output PII -> output safety -> disclosure -> audit + interaction log -> response

Every decision is recorded in `decisions` (and in the audit trail). Rules come from policy.json, not from code.
Same ask() shape as Helper, so the Module 5 attack tools run unchanged with --build gov.
"""
import json
import time
from pathlib import Path

from . import audit as A
from . import guardrails as G
from . import lang, pii, policy, releases, safety
from .app import Helper

ROOT = Path(__file__).resolve().parent.parent

MSG = {
    "paused": "The IT Support Helper is paused for maintenance. Please contact the IT Service Desk.",
    "budget": "You have reached the limit for this session. Please start a new session or contact the IT Service Desk.",
    "pii_block": "Please don't share card numbers, bank details or personal ID numbers here. I have not stored it. If you need help with a payment, contact the Finance helpdesk.",
    "safety_block": "I can't help with that request.",
    "self_harm": ("I'm really sorry you are going through this. You deserve support from a real person. Please talk to someone you trust, "
                  "your Employee Assistance Programme, or your local emergency services right now. I can't help with this safely, "
                  "and I have not created any ticket."),
    "language": ("I can currently answer in English only, so I may get this wrong. Please ask in English, or contact the IT Service Desk: "
                 "a person will help you in your language. I can create a ticket for you if you write 'create a ticket'."),
}


def est_tokens(text):
    return max(1, len(text) // 4)


class GovernedHelper:
    def __init__(self, release=None, llm=None, audit_path=None, log_path=None, pol=None, user="anonymous", session="s0"):
        self.pol = pol or policy.load()
        self.inner = Helper("v2", llm=llm)
        self.release = release or releases.current() or "dev"
        self.audit = A.AuditLog(audit_path) if audit_path else None
        self.log_path = Path(log_path) if log_path else None
        self.user, self.session = user, session
        self.requests, self.tokens = 0, 0

    # ------------------------------------------------------------------------------------------------------
    def _finish(self, out, q_hash, decisions, t0, tokens, question_redacted=""):
        core = out["answer"]
        out["answer_core"] = core
        if self.pol["output"].get("disclosure") and not out["blocked"]:
            out["answer"] = core + "\n\n" + self.pol["output"]["disclosure_text"].format(release=self.release)
        out["decisions"] = decisions
        out["release"] = self.release
        self.tokens += tokens
        ms = int((time.time() - t0) * 1000)
        if self.audit:
            self.audit.append({"release": self.release, "policy": self.pol["_hash"], "user": A.sha(self.user, 8), "session": A.sha(self.session, 8),
                               "q_hash": q_hash, "decisions": decisions, "blocked": out["blocked"], "reason": out["reason"], "tokens": tokens})
        if self.log_path:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "release": self.release, "q": question_redacted, "answer": core,
                                    "context_ids": out.get("context_ids", []), "blocked": out["blocked"], "reason": out["reason"],
                                    "decisions": decisions, "tokens": tokens, "ms": ms}) + "\n")
        return out

    def ask(self, question, approve=None):
        t0 = time.time()
        pol, dec = self.pol, []
        out = {"question": question, "answer": "", "blocked": True, "reason": None, "trace": [], "context_ids": [], "context_text": []}
        q_hash = A.sha(question)

        if pol.get("kill_switch"):
            dec.append("kill_switch")
            out.update(answer=MSG["paused"], reason="kill_switch")
            return self._finish(out, q_hash, dec, t0, 0)

        b = pol["budgets"]
        self.requests += 1
        if self.requests > b["max_requests_per_session"] or self.tokens > b["max_tokens_per_session"]:
            dec.append("budget_exceeded")
            out.update(answer=MSG["budget"], reason="budget_exceeded")
            return self._finish(out, q_hash, dec, t0, 0)

        q = G.clean_text(question)

        # --- language (honest fallback instead of a silent wrong answer) ---
        if pol["input"].get("unsupported_language") == "fallback" and not lang.is_english(q):
            dec.append("language_fallback")
            out.update(answer=MSG["language"], reason="language_fallback")
            return self._finish(out, q_hash, dec, t0, est_tokens(question), question)

        # --- input PII ---
        acts = pol["input"]["pii"]
        found = pii.detect(q)
        if any(acts.get(f["type"]) == "block" for f in found):
            dec.append("pii_input_block:" + ",".join(sorted({f["type"] for f in found if acts.get(f["type"]) == "block"})))
            out.update(answer=MSG["pii_block"], reason="pii_input_block")
            return self._finish(out, q_hash, dec, t0, est_tokens(question), pii.redact(q, found))
        if any(acts.get(f["type"]) == "redact" for f in found):
            dec.append("pii_input_redact:" + ",".join(sorted({f["type"] for f in found if acts.get(f["type"]) == "redact"})))
        q_clean = pii.redact(q, found, {k: v for k, v in acts.items()})

        # --- input safety ---
        sc = safety.score(q_clean)
        for cat, rule in pol["input"]["safety"].items():
            if sc.get(cat, 0) >= rule["threshold"] and rule["action"] != "allow":
                dec.append(f"safety_input:{cat}:{rule['action']}")
                if rule["action"] == "safe_completion":
                    out.update(answer=MSG["self_harm"], reason="safety_safe_completion")
                else:
                    out.update(answer=MSG["safety_block"], reason="safety_block")
                return self._finish(out, q_hash, dec, t0, est_tokens(question), "[withheld: safety]")

        # --- Module 5 layers + model ---
        res = self.inner.ask(q_clean, approve=approve)
        out.update({k: res[k] for k in ("trace", "context_ids", "context_text", "blocked", "reason")})
        ans = res["answer"]
        tokens = est_tokens(q_clean) + est_tokens(" ".join(res["context_text"])) + est_tokens(ans)

        # --- output PII ---
        if pol["output"].get("pii") == "redact":
            of = pii.detect(ans)
            if of:
                ans = pii.redact(ans, of)
                dec.append("pii_output_redact:" + ",".join(sorted({f["type"] for f in of})))

        # --- output safety ---
        osc = safety.score(ans)
        thr = pol["output"].get("safety_threshold")
        if thr is not None and any(v >= thr for v in osc.values()):
            dec.append("safety_output_block")
            ans, out["blocked"], out["reason"] = MSG["safety_block"], True, "safety_output_block"
        out["answer"] = ans
        return self._finish(out, q_hash, dec, t0, tokens, q_clean)
