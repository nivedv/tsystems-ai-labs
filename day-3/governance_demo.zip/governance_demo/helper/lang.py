"""Tiny language check. The helper's knowledge base and retrieval work in English only, so we must not pretend otherwise.
(Found in Module 5 fuzzing: German, French and Hindi questions got silent wrong answers.)"""
import re

DE = {"wie", "ich", "mein", "meine", "meinen", "das", "die", "der", "und", "ist", "nicht", "kann", "ein", "eine", "wo", "was", "mir", "mich", "zurück", "für"}
FR = {"comment", "je", "mon", "ma", "mes", "les", "des", "est", "pas", "puis", "une", "un", "pour", "dans", "mot", "passe", "réinitialiser", "où", "que"}
ES = {"cómo", "como", "mi", "mis", "puedo", "una", "los", "las", "está", "para", "contraseña", "donde", "dónde"}
EN = {"how", "do", "i", "my", "the", "is", "what", "can", "to", "a", "of", "and", "for", "on", "in", "me", "it", "you", "are", "does", "should"}


def is_english(text):
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return True
    non_ascii = sum(1 for c in letters if ord(c) > 0x024F)  # outside Latin scripts (Hindi, Arabic, Chinese...)
    if non_ascii / len(letters) > 0.3:
        return False
    words = re.findall(r"[^\W\d_]+", text.lower())
    other = sum(1 for w in words if w in DE | FR | ES)
    eng = sum(1 for w in words if w in EN)
    return not (other >= 2 and other > eng)
