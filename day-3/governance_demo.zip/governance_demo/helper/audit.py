"""Tamper-evident audit trail: every record contains the hash of the record before it (a hash chain).
Change or delete one line and verify() tells you where the chain breaks.
Privacy rule: the audit log stores HASHES and DECISIONS, never the user's raw text."""
import hashlib
import json
import time
from pathlib import Path


def sha(text, n=12):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:n]


class AuditLog:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.prev, self.seq = "GENESIS", 0
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    rec = json.loads(line)
                    self.prev, self.seq = rec["hash"], rec["seq"]

    def append(self, event):
        self.seq += 1
        rec = {"seq": self.seq, "ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "prev": self.prev, "event": event}
        rec["hash"] = sha(json.dumps({k: rec[k] for k in ("seq", "ts", "prev", "event")}, sort_keys=True), 16)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
        self.prev = rec["hash"]
        return rec


def verify(path):
    """Return (ok, records_checked, first_bad_seq)."""
    prev, n = "GENESIS", 0
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        want = sha(json.dumps({k: rec[k] for k in ("seq", "ts", "prev", "event")}, sort_keys=True), 16)
        n += 1
        if rec["prev"] != prev or rec["hash"] != want:
            return False, n, rec["seq"]
        prev = rec["hash"]
    return True, n, None
