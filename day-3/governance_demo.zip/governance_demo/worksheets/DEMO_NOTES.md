# Demo notes (trainer scratch sheet)

| Step | Live number (fill in) | Sim number |
|---|---|---|
| Gate on draft policy: G2 ASR | | 71.4% (15/21 at --runs 3) |
| Gate on draft: G5 silent failures | | 5/5 |
| Attacks after policy_final: ASR | | 0.0% (0/35 at --runs 5) |
| Fairness before language patch | | silent 1/5 (fr) |
| Gate on rel-1.1.0 | | PASS |
| Monitor first alert | | day 9 (synthetic data) |
