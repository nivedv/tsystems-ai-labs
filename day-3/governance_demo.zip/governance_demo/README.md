# Day 3 Trainer Demo (Module 6): Guardrails, Responsible AI, Governance & Production

**Private trainer repo.** Learners get `governance_lab`. Open **TRAINER_GUIDE.md** first.

The system is the same IT Support Helper from Modules 1–5. Module 5's six guardrail layers are already inside. Module 6 adds a **governed runtime** around it.

| Item | Purpose |
|---|---|
| `TRAINER_GUIDE.md` | Pre-flight, run-of-show, 11 demo steps, Say lines, expected numbers, failure table |
| `helper/runtime.py` | The governed runtime: kill switch, budget, language, PII, safety, disclosure, audit |
| `helper/data/policy.json` | **Policy as configuration.** Shipped as a permissive DRAFT. You fix it live. |
| `helper/pii.py`, `safety.py`, `lang.py` | PII detector, content-safety scorer, language check |
| `helper/audit.py` | Tamper-evident audit trail (hash chain) |
| `helper/releases.py` + `releases/` | Release manifests, approvals, promote, rollback |
| `tools/` | `release_gate`, `release`, `monitor`, `online_eval`, `fairness_check`, `pii_selftest`, `audit_tool`, `run_traffic`, `simulate_traffic` |
| `redteam/` | Module 5 toolkit plus new PII and safety attacks (`attacks_m6.json`) |
| `docs/` | Filled examples: system card, responsible-AI sign-off, incident runbook, build-and-assure contract |
| `patches/` | `policy_final.json` and `apply_fix_language.py` (scripted copies of the live fixes) |

Quick start (Windows PowerShell):
```powershell
python -m venv .venv ; .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      # fill in endpoint, key, deployment, API version
python -m redteam.check_env
```
`RT_MODE=sim` runs everything offline with a rule-based simulator. **The simulator is not a model.** Production monitoring data in the demo is **synthetic**; Euro prices are illustrative.
