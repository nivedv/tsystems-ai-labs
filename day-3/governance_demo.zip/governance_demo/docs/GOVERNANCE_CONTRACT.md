# The build-and-assure contract for a governed release

*One agreement between the team that BUILDS the system and the team that ASSURES it. Nothing goes live unless both sides did their part and both can show evidence.*

| Stage | BUILD team delivers | ASSURE team checks (evidence) | Tool in this repo |
|---|---|---|---|
| 1. Define | Purpose, users, out-of-scope, system card draft | Risks identified (threat model, fairness, privacy); policy limits agreed | `docs/SYSTEM_CARD.md`, `helper/data/policy.json` |
| 2. Build | Guardrails as code and as policy; pinned model, prompt, knowledge base | Red-team suite (Module 5) plus PII and safety attacks | `redteam/run_attacks` |
| 3. Verify | A release candidate with a manifest | Release gate: attacks, utility, PII quality, equal service, audit, operations, manifest | `tools.release_gate` |
| 4. Approve | Evidence pack (gate report, system card, RAI checklist) | Named humans sign: product owner, security, AI quality | `tools.release approve` |
| 5. Release | Promote the exact approved build | Integrity check: nothing changed since sign-off | `tools.release promote / check` |
| 6. Operate | Monitoring, cost limits, rollback, runbook | Drift alerts, online evals, audit sampling, incident drills | `tools.monitor`, `tools.online_eval`, `docs/INCIDENT_RUNBOOK.md` |
| 7. Learn | Every incident becomes a new test | Gate thresholds reviewed | attack and utility files |

**Three rules:** (1) No evidence, no approval. (2) Any change to a pinned item means a new gate and new approvals. (3) The people who build do not sign alone.
