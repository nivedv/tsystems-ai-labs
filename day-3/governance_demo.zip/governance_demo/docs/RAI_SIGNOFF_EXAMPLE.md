# Responsible-AI and sign-off checklist: IT Support Helper rel-1.1.0 (FILLED EXAMPLE)

**Prepared by:** AI Quality Lead · **Date:** 2026-11-04 · **Decision requested:** approve for production (all employees)

Rule: **every tick needs evidence** (a command, a file, a number). No evidence = not ticked.

| # | Question | ✔ | Evidence |
|---|---|---|---|
| **Fairness** | | | |
| 1 | Do all user groups get the same quality of service, or are differences known and handled? | ◐ | `tools.fairness_check`: non-English users get a hand-over, not an answer (0/5 correct, 5/5 handed over, 0 silent). Gap accepted, see risks. |
| 2 | Are people described fairly (no private or sensitive data shown)? | ✔ | Gate G2 (PII/safety attacks 0%); directory returns public fields only (Module 5, EX-01/02: 0%) |
| **Transparency** | | | |
| 3 | Does the user know it is an AI, and which release? | ✔ | Disclosure line on every answer (`ask --build gov`) |
| 4 | Are purpose, limits and known gaps documented? | ✔ | `docs/SYSTEM_CARD.md` §2, §5 |
| **Human oversight** | | | |
| 5 | Can a human stop it, approve risky actions and take over? | ✔ | Kill switch (G7), P1/P2 approval (Module 5, TM-01), language and self-harm hand-over |
| **Safety and security** | | | |
| 6 | Does it hold under the Module 5 attacks and the new PII and safety attacks? | ✔ | G1 0/39, G2 0/21 (3 runs each) |
| 7 | Do normal questions still work (no over-blocking)? | ✔ | G3 13/13 |
| **Privacy** | | | |
| 8 | Is personal data blocked or redacted before the model sees it, and kept out of logs? | ✔ | G2, G4 (recall 100%, precision 100% on regression cases), G6 (no raw text in audit) |
| **Accountability** | | | |
| 9 | Is there a named owner and a tamper-evident record of decisions? | ✔ | Manifest owner field; audit hash chain verified and tamper test (G6) |
| 10 | Can we find out which model, prompt, knowledge base and policy produced an answer? | ✔ | Release manifest pins five hashes (G8); release id in every log line |
| **Operations** | | | |
| 11 | Are cost limits, monitoring, rollback and an incident plan in place? | ✔ | Budget test (G7), `tools.monitor` alerts, `release rollback`, `docs/INCIDENT_RUNBOOK.md` |
| 12 | Is any change after sign-off forced through the gate again? | ✔ | `release check` detects changed pinned items |

**Residual risks (accepted, with owner and date)**
| Risk | Level | Owner | Mitigation / review |
|---|---|---|---|
| Non-English users get slower service | Medium | Product Owner | Hand-over message now; multilingual retrieval by Q1 |
| PII detector misses words-as-digits and dotted cards | Low | Security | Add to detector; managed PII service before wider rollout |
| Word-list safety scorer misses new wording | Medium | AI Quality | Add managed classifier; review flagged logs weekly |

**Recommendation:** ☐ Approve  ☑ Approve with conditions  ☐ Reject
Conditions: review residual risks at 30 days; no new languages announced until multilingual evaluation exists.

| Role | Name | Decision | Date |
|---|---|---|---|
| Product Owner | | | |
| Security | | | |
| AI Quality | | | |
