# System card: IT Support Helper (rel-1.1.0)

*A system card tells a user, an auditor and a new team member what this system is, what it is for, and what it is NOT for. One page. Keep it next to the code.*

| | |
|---|---|
| **System** | IT Support Helper (RAG assistant with two tools) |
| **Release** | rel-1.1.0 (see `releases/rel-1.1.0.json` for pinned model, prompt, knowledge base, policy and guardrail hashes) |
| **Owner** | AI Quality Lead (accountable); Product Owner IT Service Desk (business owner) |
| **Model** | gpt-4.1 on Azure OpenAI (Foundry deployment `gpt-4.1`) |

## 1. Purpose and users
Answers employee questions about IT topics (passwords, VPN, Wi-Fi, laptops, mailboxes) from the approved knowledge base, and can create tickets. Users: all employees. Language: English.

## 2. Out of scope (the helper must refuse or hand over)
Legal, HR or medical advice · employee personal data (salary, private phone, address) · anything that weakens security controls · payments · requests in languages other than English (hand over to a person).

## 3. Data
Knowledge base: 11 internal articles (synthetic in training). Employee directory: public fields only (name, department, title, work e-mail). The helper stores **no** raw user text in the audit log (hashes and decisions only). Interaction log keeps redacted text.

## 4. Controls (what protects users)
| Area | Control | Evidence |
|---|---|---|
| Security | 6 layers from Module 5 | gate G1: 0% ASR |
| Privacy | PII detect, block or redact (input and output) | gate G2, G4 |
| Content safety | harassment and threats blocked; self-harm gets a human, supportive reply | gate G2 |
| Transparency | every answer carries an AI disclosure and the release id | runtime |
| Human oversight | P1/P2 tickets need a human; self-harm and unsupported language hand over to a person; kill switch | gate G7 |
| Accountability | audit trail (hash chain), release manifest, named approvers | gate G6, G8 |

## 5. Known limitations (we tell users and auditors)
1. **Language:** works in English only. Other languages get a clear hand-over message, not a quality answer. Cost of this: non-English speakers get slower service. Planned fix: multilingual embeddings and evaluation set.
2. **PII detector gaps:** card numbers written as words, or with dots as separators, are not detected.
3. **Content safety is a small word list.** It misses new wording and sometimes flags harmless text (for example "this pop-up is useless"). Add a managed classifier before wider rollout.
4. **Model can still be wrong.** The grounding gate reduces, not removes, wrong answers.

## 6. Monitoring and change control
Daily metrics with alerts (grounding, abstain rate, latency, cost, PII flags, user feedback). Any change to prompt, knowledge base, policy, guardrail code or model **requires a new gate run and new approvals**. Rollback: `python -m tools.release rollback`.

*Contact: IT Service Desk, ai-quality@contoso.example (synthetic address).*
