# Incident runbook: IT Support Helper

**Use when:** a monitor alert fires (grounding, abstain, latency, cost, PII, user feedback), a user reports harm, or a red-team finding reaches production.

| Step | Who | Do | Command / where |
|---|---|---|---|
| 1. Detect | monitor / user | Note time, alert, release id | `python -m tools.monitor` |
| 2. Triage (15 min) | AI Quality on call | Severity? Data leak or harm = **Sev 1**. Quality drop only = **Sev 2**. | table below |
| 3. Contain | on call | Sev 1: **kill switch** (`"kill_switch": true` in policy.json, redeploy policy). Sev 2: **rollback** to the last good release. | `python -m tools.release rollback --reason "..."` |
| 4. Communicate | Product Owner | Tell users (service desk banner), tell Security if data or harm is involved. Keep facts, no blame. | template below |
| 5. Investigate | AI Quality + Security | Use the audit trail and interaction log by release id. What changed? (`release check`) | `python -m tools.audit_tool verify` |
| 6. Fix and re-release | Engineering | Fix, add the failing case to the attack or utility suite, run the gate, get approvals again. | `python -m tools.release_gate --release rel-x` |
| 7. Review (within 5 days) | all | Blameless review: cause, detection time, what the gate missed, new test added. | |

**Severity**
| Sev | Examples | Contain within |
|---|---|---|
| 1 | personal data shown to the wrong person, harmful content, secrets leaked, runaway cost | 15 minutes |
| 2 | groundedness falls, abstain rate doubles, latency or cost +50% | 4 hours |
| 3 | single wrong answer, cosmetic | next release |

**User message template:** "The IT Support Helper is temporarily [paused / reverted to the previous version] because [one plain sentence]. Please contact the IT Service Desk on [channel]. We will update you by [time]."

**Fire drill (do once per quarter):** trigger the kill switch in test, roll back, and time it.
