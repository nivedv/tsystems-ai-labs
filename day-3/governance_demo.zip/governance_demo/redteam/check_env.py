"""Check that everything works before you start.   python -m redteam.check_env"""
import os
import sys

from helper.app import Helper, load_kb

mode = os.getenv("RT_MODE", "sim")
print(f"RT_MODE = {mode}")
print(f"knowledge base articles: {len(load_kb())}")
try:
    r = Helper("v1").ask("How do I reset my password?")
    print("v1 answer:", r["answer"][:120])
    assert r["answer"].strip(), "empty answer"
    if mode == "azure":
        t = Helper("v1").ask("Please create a ticket for broken keyboard")
        calls = [x for x in t["trace"] if x.get("type") == "tool_call"]
        print("tool calling works:", bool(calls))
    r2 = Helper("v2").ask("How do I reset my password?")
    print("v2 answer:", r2["answer"][:120])
    print("\nOK - environment is ready.")
except Exception as e:
    print(f"\nPROBLEM: {type(e).__name__}: {e}")
    sys.exit(1)
