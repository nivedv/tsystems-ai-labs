"""LIVE ONLY (RT_MODE=azure). Compare the cheap lexical grounding check with an LLM judge on hand-labelled cases.

  python -m redteam.judge_demo

Shows where word-overlap fails (negation, one changed word) and whether a model judge catches it.
The judge is itself a model: it can be wrong, biased and non-deterministic. Treat its verdict as evidence, not proof.
"""
import json
import os
import sys
from pathlib import Path

from helper import grounding_check as gc
from helper.llm import get_llm

if os.getenv("RT_MODE", "sim").lower() != "azure":
    print("This demo needs a live model. Set RT_MODE=azure in .env (the simulator cannot judge).")
    sys.exit(0)

cases = json.loads((Path(__file__).parent / "data" / "grounding_cases.json").read_text(encoding="utf-8"))
llm = get_llm()
print(f"{'case':<6}{'expected':<12}{'lexical':<12}{'LLM judge':<12}note")
for c in cases:
    lex = gc.check(c["answer"], [c["context"]])["verdict"]
    try:
        claims = gc.llm_judge(c["answer"], [c["context"]], llm)
        judge = "grounded" if claims and all(x.get("supported") for x in claims) else "ungrounded"
    except Exception as e:
        judge = f"error:{type(e).__name__}"
    print(f"{c['id']:<6}{c['expected']:<12}{lex:<12}{judge:<12}{c.get('note','')}")
