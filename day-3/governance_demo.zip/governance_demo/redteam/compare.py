"""Before / after table from two result files.

  python -m redteam.compare "results/attacks_v1_before_*.json" "results/attacks_v2_after_*.json"
"""
import glob
import json
import sys


def pick(pattern):
    """Accept a file name or a quoted wildcard (Windows shells do not expand * for Python). Newest match wins."""
    files = sorted(glob.glob(pattern))
    return files[-1] if files else pattern


def main():
    a = json.load(open(pick(sys.argv[1]), encoding="utf-8"))
    b = json.load(open(pick(sys.argv[2]), encoding="utf-8"))
    bm = {r["id"]: r for r in b["rows"]}
    print(f"{'ID':<10}{'Category':<20}{'before':>8}{'after':>8}  verdict")
    fixed = still = 0
    for r in a["rows"]:
        after = bm.get(r["id"])
        if not after:
            continue
        if r["asr"] > 0 and after["asr"] == 0:
            v, fixed = "FIXED", fixed + 1
        elif after["asr"] > 0:
            v, still = ("STILL OPEN" if after["asr"] >= r["asr"] else "REDUCED"), still + 1
        else:
            v = "ok (never worked)"
        print(f"{r['id']:<10}{r['category']:<20}{r['asr']:>8.2f}{after['asr']:>8.2f}  {v}")
    print(f"\noverall ASR: {a['meta']['overall_asr']:.1%} -> {b['meta']['overall_asr']:.1%}   fixed: {fixed}   still open: {still}")


if __name__ == "__main__":
    main()
