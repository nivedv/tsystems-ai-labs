"""Trainer fix 3 (demo step 8): the language detector missed 'Comment me connecter au VPN ?'.
Adds common French function words. Run from the repo root:  python patches/apply_fix_language.py"""
from pathlib import Path
p = Path("helper/lang.py"); s = p.read_text(encoding="utf-8")
if '"au"' in s: raise SystemExit("already patched")
old = 'FR = {"comment", "je", "mon",'
new = 'FR = {"comment", "me", "au", "du", "le", "la", "je", "mon",'
assert old in s, "not the original lang.py"
p.write_text(s.replace(old, new, 1), encoding="utf-8")
print("patched: French function words added to helper/lang.py")
