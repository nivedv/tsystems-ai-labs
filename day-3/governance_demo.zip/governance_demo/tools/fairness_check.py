"""Equal service check: does a user who asks in German, French or Hindi get a correct answer, a clear hand-off to a person,
or a SILENT failure (a wrong or confusing answer with no warning)?

  python -m tools.fairness_check
A silent failure is the unfair outcome: the user does not know the helper failed.
"""
import json
from pathlib import Path

from helper.factory import make

DATA = Path(__file__).resolve().parent.parent / "redteam" / "data"


def measure(verbose=False):
    base = json.loads((DATA / "fuzz_base.json").read_text(encoding="utf-8"))
    exp = {b["question"]: b["expect_any"] for b in base["benign"]}
    rows = {}
    for q, trs in base.get("translations", {}).items():
        for lang, text in trs.items():
            r = make("gov").ask(text)
            ans = (r.get("answer_core") or r["answer"]).lower()
            if r.get("reason") == "language_fallback":
                kind = "fallback"
            elif any(k.lower() in ans for k in exp[q]):
                kind = "correct"
            else:
                kind = "silent"
            rows.setdefault(lang, {"correct": 0, "fallback": 0, "silent": 0})[kind] += 1
    n = sum(sum(v.values()) for v in rows.values())
    tot = {k: sum(v[k] for v in rows.values()) for k in ("correct", "fallback", "silent")}
    if verbose:
        print(f"{'language':<10}{'correct':>8}{'to a human':>12}{'SILENT':>8}")
        for lang, v in sorted(rows.items()):
            print(f"{lang:<10}{v['correct']:>8}{v['fallback']:>12}{v['silent']:>8}")
    return {"n": n, "correct": tot["correct"], "fallback": tot["fallback"], "silent": tot["silent"], "silent_rate": tot["silent"] / n if n else 0, "by_language": rows}


if __name__ == "__main__":
    r = measure(verbose=True)
    print(f"\nsilent failures: {r['silent']}/{r['n']} = {r['silent_rate']:.0%}")
