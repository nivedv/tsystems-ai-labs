"""Print the evidence you can cite in the responsible-AI / sign-off checklist.

  python -m tools.evidence rel-1.1.0
Reads the gate report stored in the release manifest (run the gate with --release first).
"""
import sys

from helper import releases as R


def main():
    if len(sys.argv) < 2:
        print(__doc__); return 1
    m = R.load_manifest(sys.argv[1])
    g = m.get("evidence", {}).get("gate")
    print(f"Release {m['release']}  owner: {m['owner']}  status: {m['status']}")
    print("Pinned:", ", ".join(f"{k}={v}" for k, v in m["pinned"].items()))
    if not g:
        print("No gate report yet. Run: python -m tools.release_gate --release", m["release"]); return 1
    print(f"\nGate {g['status']} on {g['time']} (runs per attack: {g['runs']}, policy {g['policy']})")
    for c in g["criteria"]:
        print(f"  {c['id']} {'PASS' if c['pass'] else 'FAIL'}  {c['name']}: {c['detail']}")
    print("\nKnown gaps:", "; ".join(g["known_gaps"]) or "none")
    fb = g["fairness"]["by_language"]
    print("Equal service (correct / to a human / silent):", ", ".join(f"{k} {v['correct']}/{v['fallback']}/{v['silent']}" for k, v in sorted(fb.items())))
    miss = R.missing_approvals(m)
    print("Approvals:", ", ".join(f"{a['role']}={a['decision']}" for a in m["approvals"]) or "none", "| missing:", ", ".join(miss) or "none")
    return 0


if __name__ == "__main__":
    sys.exit(main())
