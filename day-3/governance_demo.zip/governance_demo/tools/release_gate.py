"""The release gate: ONE command that turns 'we think it is safe' into evidence.

  python -m tools.release_gate --release rel-1.1.0 --runs 3

Criteria (thresholds come from policy.json -> gate):
  G1 Module 5 attack suite        ASR <= max_asr_module5
  G2 Module 6 attack suite        PII + content safety, ASR <= max_asr_module6
  G3 Utility                      normal questions still work
  G4 PII detector quality         recall / precision on labelled cases (known gaps listed, not hidden)
  G5 Equal service / honest failure   no SILENT failures for non-English users
  G6 Audit trail                  chain verifies, tampering is detected, no raw PII stored
  G7 Operations                   budget limit, kill switch and rollback target work
  G8 Release manifest             everything that changes behaviour is pinned
The gate does NOT approve. Humans approve (tools.release approve ...). The gate only decides if they may be asked.
"""
import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

from helper import policy, releases
from helper.app import load_employees, load_scenario
from redteam.run_attacks import campaign
from redteam import utility_check
from tools import fairness_check, ops_checks, pii_selftest, safety_selftest

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "redteam" / "data"


def run(release=None, runs=3, quiet=False):
    pol = policy.load()
    g = pol["gate"]
    crit = []

    def add(cid, name, ok, detail):
        crit.append({"id": cid, "name": name, "pass": bool(ok), "detail": detail})
        if not quiet:
            print(f"  {cid}  {'PASS' if ok else 'FAIL'}  {name}: {detail}")

    sc, emp = load_scenario(), load_employees()
    m5 = json.loads((DATA / "attacks.json").read_text(encoding="utf-8"))
    m6 = json.loads((DATA / "attacks_m6.json").read_text(encoding="utf-8"))
    rows, tot, ok5 = campaign("gov", m5, runs, sc, emp)
    asr5 = ok5 / tot if tot else 1
    bad5 = [r["id"] for r in rows if r["successes"]]
    add("G1", "Module 5 attacks", asr5 <= g["max_asr_module5"], f"ASR {asr5:.1%} ({ok5}/{tot})" + (f"; open: {', '.join(bad5)}" if bad5 else ""))
    rows, tot, ok6 = campaign("gov", m6, runs, sc, emp)
    asr6 = ok6 / tot if tot else 1
    bad6 = [r["id"] for r in rows if r["successes"]]
    add("G2", "Module 6 attacks (PII, content safety)", asr6 <= g["max_asr_module6"], f"ASR {asr6:.1%} ({ok6}/{tot})" + (f"; open: {', '.join(bad6)}" if bad6 else ""))

    import io, contextlib
    rates = []
    for f in ("utility.json", "utility_m6.json"):
        with contextlib.redirect_stdout(io.StringIO()):
            rate, fails = utility_check.run("gov", 1, DATA / f, verbose=False)
        rates.append((rate, len(json.loads((DATA / f).read_text(encoding="utf-8"))), fails))
    n = sum(r[1] for r in rates)
    passed = sum(round(r[0] * r[1]) for r in rates)
    add("G3", "Utility (normal questions)", passed / n >= g["min_utility"], f"{passed}/{n} = {passed / n:.0%}" + ("; failed: " + ", ".join(x[0] for r in rates for x in r[2]) if passed < n else ""))

    rec, prec, gaps = pii_selftest.score()
    rok, rtot = pii_selftest.redact_score()
    sok, stot, sgaps = safety_selftest.score_cases()
    gaps = gaps + sgaps
    add("G4", "Detector quality (PII and safety)", rec >= g["min_pii_recall"] and prec >= g["min_pii_precision"] and rok == rtot and sok == stot,
        f"PII recall {rec:.0%}, precision {prec:.0%}; redaction {rok}/{rtot}; safety cases {sok}/{stot}; known gaps (accepted, listed in sign-off): {len(gaps)}")

    fr = fairness_check.measure()
    add("G5", "No silent failures for non-English users", fr["silent_rate"] <= g["max_silent_failure_rate"],
        f"silent failures {fr['silent']}/{fr['n']} = {fr['silent_rate']:.0%}; answered correctly {fr['correct']}/{fr['n']}, sent to a human {fr['fallback']}/{fr['n']}")

    ops = ops_checks.run_all()
    for cid, nm, ok, det in ops["audit"]:
        add("G6", nm, ok, det)
    for cid, nm, ok, det in ops["ops"]:
        add("G7", nm, ok, det)

    if release and releases.manifest_path(release).exists():
        m = releases.load_manifest(release)
        miss = [k for k in ("model_deployment", "prompt_hash", "kb_hash", "policy_hash", "guardrail_hash") if not m["pinned"].get(k)]
        changed = releases.integrity(release)
        add("G8", "Release manifest complete and current", not miss and not changed and bool(m["owner"]),
            "all pinned, owner " + m["owner"] if not miss and not changed else f"missing {miss} changed {changed}")
    else:
        add("G8", "Release manifest complete and current", False, f"no manifest for {release!r}: run  python -m tools.release create <id> --owner <name>")

    status = "PASS" if all(c["pass"] for c in crit) else "BLOCKED"
    report = {"status": status, "time": time.strftime("%Y-%m-%d %H:%M"), "runs": runs, "policy": pol["policy_version"], "criteria": crit,
              "known_gaps": gaps, "fairness": fr}
    if release and releases.manifest_path(release).exists():
        m = releases.load_manifest(release)
        m["evidence"]["gate"] = report
        m["status"] = "gate_passed" if status == "PASS" else "gate_failed"
        releases.save_manifest(m)
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", default=None)
    ap.add_argument("--runs", type=int, default=3)
    a = ap.parse_args()
    print(f"RELEASE GATE  release={a.release}  runs={a.runs}\n")
    rep = run(a.release, a.runs)
    print(f"\nGATE STATUS: {rep['status']}")
    if rep["known_gaps"]:
        print("Known gaps (write these in the sign-off as accepted risks):")
        for k in rep["known_gaps"]:
            print(f"  - {k}")
    if a.release and releases.manifest_path(a.release).exists():
        m = releases.load_manifest(a.release)
        print("Approvals still needed:", ", ".join(releases.missing_approvals(m)) or "none")
    return 0 if rep["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
