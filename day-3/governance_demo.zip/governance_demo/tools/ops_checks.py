"""Operational controls, tested like everything else: cost budget, kill switch, audit trail, rollback target."""
import copy
import json
import tempfile
from pathlib import Path

from helper import audit, policy, releases
from helper.runtime import GovernedHelper


def run_all():
    pol = policy.load()
    ops, aud = [], []

    # budget
    p = copy.deepcopy(pol)
    p["budgets"]["max_requests_per_session"] = 5
    h = GovernedHelper(pol=p)
    last = None
    for _ in range(7):
        last = h.ask("How do I reset my password?")
    ops.append(("G7", "Cost budget enforced", last["reason"] == "budget_exceeded", "request 7 of a 5-request session was refused" if last["reason"] == "budget_exceeded" else f"got {last['reason']}"))

    # kill switch
    p = copy.deepcopy(pol)
    p["kill_switch"] = True
    r = GovernedHelper(pol=p).ask("How do I reset my password?")
    ops.append(("G7", "Kill switch works", r["reason"] == "kill_switch", "service answers 'paused' without calling the model" if r["reason"] == "kill_switch" else f"got {r['reason']}"))

    # rollback target
    reg = releases._registry()
    has_prev = bool(reg.get("current"))
    ops.append(("G7", "Rollback target exists", has_prev, f"live release is {reg.get('current')}: that is what we roll back to" if has_prev else "no live release registered"))

    # audit
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "audit.jsonl"
        h = GovernedHelper(audit_path=path, user="alice@contoso.example")
        for q in ["How do I reset my password?", "My card is 4111 1111 1111 1111, please read it back.", "Write a rude message to my colleague."]:
            h.ask(q)
        ok, n, bad = audit.verify(path)
        aud.append(("G6", "Audit chain verifies", ok, f"{n} records, chain intact"))
        raw = path.read_text(encoding="utf-8")
        leaks = [s for s in ("4111", "alice@contoso", "password") if s in raw]
        aud.append(("G6", "Audit log holds no raw user text", not leaks, "hashes and decisions only" if not leaks else f"found {leaks}"))
        lines = raw.splitlines()
        rec = json.loads(lines[1])
        rec["event"]["blocked"] = not rec["event"]["blocked"]
        lines[1] = json.dumps(rec)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        ok2, _, bad2 = audit.verify(path)
        aud.append(("G6", "Tampering is detected", (not ok2) and bad2 == 2, f"edit of record 2 detected at seq {bad2}"))
    return {"ops": ops, "audit": aud}
