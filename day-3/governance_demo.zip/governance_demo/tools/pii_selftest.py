"""Test your tester: how good is the PII detector on labelled cases?

  python -m tools.pii_selftest
Cases whose note starts with 'KNOWN' are known gaps. They are reported, but they do not decide the gate.
"""
import json
from pathlib import Path

from helper import pii

DATA = Path(__file__).resolve().parent.parent / "redteam" / "data"


def score(verbose=False):
    cases = json.loads((DATA / "pii_cases.json").read_text(encoding="utf-8"))
    tp = fp = fn = 0
    gaps = []
    for c in cases:
        got = {f["type"] for f in pii.detect(c["text"])}
        want = set(c["expect"])
        known = c["note"].startswith("KNOWN")
        ok = got == want
        if verbose:
            print(f"{c['id']}  {'ok  ' if ok else ('GAP ' if known else 'FAIL')}  want={sorted(want)} got={sorted(got)}  {c['note']}")
        if known:
            if not ok:
                gaps.append(f"{c['id']}: {c['note'].partition(':')[2].strip()}")
            continue
        tp += len(got & want)
        fp += len(got - want)
        fn += len(want - got)
    recall = tp / (tp + fn) if tp + fn else 1.0
    precision = tp / (tp + fp) if tp + fp else 1.0
    return recall, precision, gaps


REDACT_TESTS = [
    ("Call me on +49 170 1234567 now.", None, "Call me on [PHONE] now."),
    ("Card 4111 1111 1111 1111 and IBAN GB82 WEST 1234 5698 7654 32.", None, "Card [CARD] and IBAN [IBAN]."),
    ("Write to john.doe@gmail.example please.", None, "Write to [EMAIL_EXTERNAL] please."),
    ("Call me on +49 170 1234567 now.", {"phone": "allow"}, "Call me on +49 170 1234567 now."),
]


def redact_score(verbose=False):
    ok = 0
    for text, actions, want in REDACT_TESTS:
        got = pii.redact(text, pii.detect(text), actions)
        ok += got == want
        if verbose:
            print(f"R  {'ok  ' if got == want else 'FAIL'}  {got!r}" + ("" if got == want else f"   wanted {want!r}"))
    return ok, len(REDACT_TESTS)


if __name__ == "__main__":
    r, p, g = score(verbose=True)
    print(f"\nrecall {r:.0%}  precision {p:.0%}   known gaps: {len(g)}")
    print("\nredaction tests:")
    a, b = redact_score(verbose=True)
    print(f"redaction: {a}/{b}")
