"""SYNTHETIC production traffic for the monitoring demo. Not real data. Deterministic (seeded).

  python -m tools.simulate_traffic                  # writes data/prod_metrics_synthetic.jsonl
Story: days 1-7 normal on rel-1.0.0. Day 8 rel-1.1.0 goes live. On day 10 a billing e-mail makes some users paste card numbers (PII flags rise: the guardrail works, but it is a signal). From day 9 a knowledge-base re-index lowers answer quality
(groundedness falls, 'I don't have that' rises, longer contexts raise cost and latency). Day 11 rollback to rel-1.0.0.
"""
import json
import random
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "helper" / "data" / "prod_metrics_synthetic.jsonl"


def day_profile(day, rollback_day):
    if day < 8 or day >= rollback_day:
        rel, g, ab, tok, lat, td = ("rel-1.0.0" if day < 8 or day >= rollback_day else "rel-1.1.0"), 0.92, 0.08, 900, 1200, 0.04
    else:
        rel = "rel-1.1.0"
        if day == 8:
            g, ab, tok, lat, td = 0.91, 0.09, 920, 1220, 0.05
        else:
            g, ab, tok, lat, td = 0.70, 0.24, 1650, 2100, 0.19
    return rel, g, ab, tok, lat, td


def generate(rollback_day=11, days=14, per_day=80, seed=7):
    rnd = random.Random(seed)
    rows = []
    for day in range(1, days + 1):
        rel, g, ab, tok, lat, td = day_profile(day, rollback_day)
        for _ in range(per_day):
            abstain = rnd.random() < ab
            blocked = rnd.random() < 0.05
            rows.append({
                "day": day, "release": rel, "blocked": blocked, "abstain": abstain and not blocked,
                "grounded_ratio": 0.0 if blocked else round(min(1, max(0, rnd.gauss(g, 0.08))), 2),
                "tokens": int(rnd.gauss(tok, tok * 0.25)),
                "latency_ms": int(rnd.lognormvariate(0, 0.35) * lat),
                "pii_flag": rnd.random() < (0.06 if day == 10 else 0.0),
                "thumbs": "down" if rnd.random() < td else ("up" if rnd.random() < 0.3 else None),
            })
    return rows


if __name__ == "__main__":
    rows = generate()
    OUT.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")
    print(f"wrote {len(rows)} synthetic records to {OUT}")
