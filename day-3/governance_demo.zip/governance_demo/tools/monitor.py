"""Production monitor: daily metrics, drift against a baseline, alerts.

  python -m tools.monitor                       # reads helper/data/prod_metrics_synthetic.jsonl
  python -m tools.monitor --file other.jsonl
Drift = the world or the system changed and quality moved, even though nobody 'changed the code'. Compare to a baseline.
"""
import argparse
import json
import statistics
from pathlib import Path

from helper import policy

DEFAULT = Path(__file__).resolve().parent.parent / "helper" / "data" / "prod_metrics_synthetic.jsonl"


def p95(xs):
    xs = sorted(xs)
    return xs[int(0.95 * (len(xs) - 1))]


def daily(rows, price):
    days = {}
    for r in rows:
        days.setdefault(r["day"], []).append(r)
    out = []
    for d, rs in sorted(days.items()):
        answered = [r for r in rs if not r["blocked"]]
        out.append({
            "day": d, "release": rs[-1]["release"], "n": len(rs),
            "abstain": sum(r["abstain"] for r in rs) / len(rs),
            "grounded": statistics.mean(r["grounded_ratio"] for r in answered),
            "p95": p95([r["latency_ms"] for r in rs]),
            "cost_req": statistics.mean(r["tokens"] for r in rs) / 1000 * price,
            "cost_day": sum(r["tokens"] for r in rs) / 1000 * price,
            "down": sum(r["thumbs"] == "down" for r in rs) / len(rs),
            "pii_1000": 1000 * sum(r["pii_flag"] for r in rs) / len(rs),
        })
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", default=str(DEFAULT))
    a = ap.parse_args()
    pol = policy.load()
    mon = pol["monitoring"]
    rows = [json.loads(l) for l in Path(a.file).read_text(encoding="utf-8").splitlines() if l.strip()]
    ds = daily(rows, pol["budgets"]["price_per_1k_tokens_eur"])
    base = [d for d in ds if d["day"] <= mon["baseline_days"]]
    b = {k: statistics.mean(d[k] for d in base) for k in ("abstain", "grounded", "p95", "cost_req", "down")}
    print(f"{'day':>3} {'release':<10}{'req':>5}{'abstain':>9}{'grounded':>9}{'p95 ms':>8}{'EUR/req':>9}{'EUR/day':>9}{'thumbs-':>8}  alerts")
    al = mon["alerts"]
    alerts = []
    for d in ds:
        fl = []
        if b["grounded"] - d["grounded"] > al["grounded_ratio_drop"]: fl.append("GROUNDING")
        if d["abstain"] - b["abstain"] > al["abstain_rate_rise"]: fl.append("ABSTAIN")
        if d["p95"] / b["p95"] - 1 > al["p95_latency_rise"]: fl.append("LATENCY")
        if d["cost_req"] / b["cost_req"] - 1 > al["cost_per_request_rise"]: fl.append("COST")
        if d["pii_1000"] > al["pii_flags_per_1000"]: fl.append("PII")
        if d["down"] > al["thumbs_down_rate"]: fl.append("USER-FEEDBACK")
        if d["cost_day"] > pol["budgets"]["daily_budget_eur"]: fl.append("DAILY-BUDGET")
        print(f"{d['day']:>3} {d['release']:<10}{d['n']:>5}{d['abstain']:>9.0%}{d['grounded']:>9.2f}{d['p95']:>8.0f}{d['cost_req']:>9.4f}{d['cost_day']:>9.2f}{d['down']:>8.0%}  {' '.join(fl)}")
        if fl:
            alerts.append((d["day"], d["release"], fl))
    print(f"\nbaseline (days 1-{mon['baseline_days']}): grounded {b['grounded']:.2f}, abstain {b['abstain']:.0%}, p95 {b['p95']:.0f} ms, EUR/request {b['cost_req']:.4f}")
    if alerts:
        first = alerts[0]
        print(f"FIRST ALERT: day {first[0]} on {first[1]}: {', '.join(first[2])}")
        print("=> start the incident runbook (docs/INCIDENT_RUNBOOK.md): triage, contain (rollback or kill switch), communicate, fix, review.")
    else:
        print("No alerts.")
    print("\n(Data is SYNTHETIC. Euro prices are illustrative.)")


if __name__ == "__main__":
    main()
