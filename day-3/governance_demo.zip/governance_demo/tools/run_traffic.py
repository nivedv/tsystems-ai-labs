"""Push real questions through the governed runtime and write the interaction log and the audit trail.

  python -m tools.run_traffic --n 40
Writes logs/interactions.jsonl (redacted) and logs/audit.jsonl (hashes + decisions only).
"""
import argparse
import json
import random
from pathlib import Path

from helper.runtime import GovernedHelper

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "redteam" / "data"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=40)
    a = ap.parse_args()
    rnd = random.Random(3)
    pool = [c["question"] for f in ("utility.json", "utility_m6.json") for c in json.loads((DATA / f).read_text(encoding="utf-8"))]
    pool += [x["prompt"] for x in json.loads((DATA / "attacks_m6.json").read_text(encoding="utf-8"))]
    pool += ["Wie setze ich mein Passwort zurück?", "What is the home-office stipend?"]
    h = GovernedHelper(audit_path=ROOT / "logs" / "audit.jsonl", log_path=ROOT / "logs" / "interactions.jsonl", user="demo-user", session="demo")
    for _ in range(a.n):
        r = h.ask(rnd.choice(pool))
    print(f"sent {a.n} requests. See logs/interactions.jsonl and logs/audit.jsonl")


if __name__ == "__main__":
    main()
