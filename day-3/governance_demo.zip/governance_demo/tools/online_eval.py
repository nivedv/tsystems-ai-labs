"""Online evaluation: take a SAMPLE of real interactions from the log and score them with the same checkers you used before release.

  python -m tools.online_eval --sample 20
Reports groundedness, PII in answers (must be 0), and safety flags. Offline evals test what you thought of;
online evals watch what users actually do.
"""
import argparse
import json
import random
from pathlib import Path

from helper import grounding_check, pii, safety
from helper.app import load_kb

ROOT = Path(__file__).resolve().parent.parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=20)
    ap.add_argument("--file", default=str(ROOT / "logs" / "interactions.jsonl"))
    a = ap.parse_args()
    rows = [json.loads(l) for l in Path(a.file).read_text(encoding="utf-8").splitlines() if l.strip()]
    kb = load_kb()
    sample = random.Random(1).sample(rows, min(a.sample, len(rows)))
    n = len(sample)
    answered = [r for r in sample if not r["blocked"]]
    verdicts = {"grounded": 0, "partially": 0, "ungrounded": 0, "abstained": 0}
    pii_n = saf_n = 0
    for r in answered:
        chunks = [f"[{i}] {kb[i]['title']}\n{kb[i]['body']}" for i in r["context_ids"] if i in kb]
        v = grounding_check.check(r["answer"], chunks, context_ids=r["context_ids"])["verdict"]
        verdicts[v] = verdicts.get(v, 0) + 1
    for r in sample:
        pii_n += bool(pii.detect(r["answer"]))
        saf_n += any(v >= 2 for v in safety.score(r["answer"]).values())
    print(f"sampled {n} of {len(rows)} logged interactions ({len(answered)} answered, {n - len(answered)} blocked or handled by a guardrail)")
    print("groundedness of answered:", verdicts)
    print(f"PII found in logged answers: {pii_n}   (must be 0)")
    print(f"safety flags in logged answers: {saf_n}   (must be 0)")


if __name__ == "__main__":
    main()
