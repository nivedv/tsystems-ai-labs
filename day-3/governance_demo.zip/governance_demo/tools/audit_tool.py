"""Audit trail tools.
  python -m tools.audit_tool verify                 # check logs/audit.jsonl
  python -m tools.audit_tool tamper-demo            # copy the log, edit ONE record, show that verify() catches it
"""
import json
import sys
from pathlib import Path

from helper import audit

LOG = Path(__file__).resolve().parent.parent / "logs" / "audit.jsonl"


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "verify"
    if cmd == "verify":
        ok, n, bad = audit.verify(LOG)
        print(f"{n} records. " + ("Chain intact." if ok else f"CHAIN BROKEN at record {bad}."))
        return 0 if ok else 1
    if cmd == "tamper-demo":
        lines = LOG.read_text(encoding="utf-8").splitlines()
        i = min(2, len(lines) - 1)
        rec = json.loads(lines[i])
        rec["event"]["blocked"] = not rec["event"]["blocked"]
        lines[i] = json.dumps(rec)
        copy = LOG.with_name("audit_tampered.jsonl")
        copy.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"edited record {rec['seq']} in a COPY ({copy.name}). Verifying the copy:")
        ok, n, bad = audit.verify(copy)
        print(f"  -> {'intact?!' if ok else f'CHAIN BROKEN at record {bad}'}")
        return 0
    print(__doc__)


if __name__ == "__main__":
    sys.exit(main())
