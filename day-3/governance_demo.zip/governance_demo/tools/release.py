"""Release control. Humans decide; this tool records and enforces.

  python -m tools.release status
  python -m tools.release create rel-1.1.0 --owner "Nived" --notes "adds PII + safety guardrails"
  python -m tools.release check rel-1.1.0              # did anything change since the manifest was written?
  python -m tools.release approve rel-1.1.0 --role security --name "A. Reviewer" --comment "..."
  python -m tools.release promote rel-1.1.0            # needs: gate PASS + all approvals + integrity OK
  python -m tools.release rollback --reason "grounding dropped"
"""
import argparse
import json
import sys

from helper import releases as R


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    c = sub.add_parser("create"); c.add_argument("id"); c.add_argument("--owner", required=True); c.add_argument("--notes", default="")
    k = sub.add_parser("check"); k.add_argument("id")
    a = sub.add_parser("approve"); a.add_argument("id"); a.add_argument("--role", required=True, choices=R.REQUIRED_ROLES); a.add_argument("--name", required=True)
    a.add_argument("--decision", default="approve", choices=["approve", "reject"]); a.add_argument("--comment", default="")
    p = sub.add_parser("promote"); p.add_argument("id")
    r = sub.add_parser("rollback"); r.add_argument("--reason", required=True)
    args = ap.parse_args()

    if args.cmd == "status":
        reg = R._registry()
        print(f"live: {reg['current']}   previous: {reg['previous']}")
        for h in reg["history"][-5:]:
            print("  ", h)
        if reg["current"] and R.manifest_path(reg["current"]).exists():
            m = R.load_manifest(reg["current"])
            print("pinned:", json.dumps(m["pinned"]))
    elif args.cmd == "create":
        m = R.create(args.id, args.owner, args.notes)
        print(f"created {args.id}. Pinned:")
        for k_, v in m["pinned"].items():
            print(f"  {k_:<18}{v}")
    elif args.cmd == "check":
        ch = R.integrity(args.id)
        print("OK: nothing changed since the manifest was written." if not ch else "CHANGED since manifest: " + ", ".join(ch) + "\n=> the gate result and approvals no longer apply. Re-run the gate and re-approve.")
        return 1 if ch else 0
    elif args.cmd == "approve":
        m = R.approve(args.id, args.role, args.name, args.decision, args.comment)
        print(f"recorded: {args.role} ({args.name}) -> {args.decision}. Still missing: {', '.join(R.missing_approvals(m)) or 'nothing'}")
    elif args.cmd == "promote":
        ok, msg = R.promote(args.id)
        print(("PROMOTED: " if ok else "REFUSED: ") + msg)
        return 0 if ok else 1
    elif args.cmd == "rollback":
        ok, msg = R.rollback(args.reason)
        print(("ROLLED BACK: " if ok else "REFUSED: ") + msg)
        return 0 if ok else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
