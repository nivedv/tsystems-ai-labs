"""Test your content-safety scorer on labelled cases.

  python -m tools.safety_selftest
expect = the categories that SHOULD reach severity 2 or more ({} = harmless). Cases whose note starts with KNOWN are known
gaps: they are reported, but they do not decide the gate.
"""
import json
from pathlib import Path

from helper import safety

DATA = Path(__file__).resolve().parent.parent / "redteam" / "data"


def score_cases(verbose=False):
    cases = json.loads((DATA / "safety_cases.json").read_text(encoding="utf-8"))
    ok = total = 0
    gaps = []
    for c in cases:
        sc = safety.score(c["text"])
        got = {k for k, v in sc.items() if v >= 2}
        good = got == set(c["expect"])
        known = c["note"].startswith("KNOWN")
        if verbose:
            print(f"{c['id']}  {'ok  ' if good else ('GAP ' if known else 'FAIL')}  want={sorted(c['expect'])} got={sorted(got)}  {c['text']}")
        if known:
            if not good:
                gaps.append(f"{c['id']}: {c['note'].partition(':')[0][6:].strip().lower()} on '{c['text']}'")
            continue
        total += 1
        ok += good
    return ok, total, gaps


if __name__ == "__main__":
    a, b, g = score_cases(verbose=True)
    print(f"\nsafety cases correct: {a}/{b}   known gaps: {len(g)}")
