# Day 2 — Lab 8 overlay (embeddings + local Chroma)
Copy the contents of this folder into the root of your Day 1 repo (`tsystems-ai-labs`). Adds `day2_lab_8/`, `lib/embed_helpers.py`, `lib/kb_tools.py`, `setup/check_env_day2.py`.
Install: `pip install chromadb`. Add to your own `.env` (never commit it): `AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small`.
Then open `day2_lab_8/LAB_CARD.md`. Needs your Day 1 `lib/common.py`, `lib/textutils.py`, `kb/`, `data/lab4_questions.json`.
