"""Day 2: run this first. Checks your settings, including the embedding deployment, and makes ONE tiny embedding call.
It never prints your key."""
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "lib"))
from common import REQUIRED, ROOT, load_env  # noqa: E402

load_env()
ok = (ROOT / ".env").exists()
print(f".env file in repo root: {'found' if ok else 'NOT FOUND'}")
for k in REQUIRED:
    v = os.environ.get(k)
    if not v:
        print(f"[MISSING] {k}")
        ok = False
    elif k == "AZURE_OPENAI_API_KEY":
        print(f"[ set   ] {k}  (value hidden)")
    else:
        print(f"[ set   ] {k} = {v}")
e = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
print(f"[ set   ] AZURE_OPENAI_EMBEDDING_DEPLOYMENT = {e}" if e else
      "[ note  ] AZURE_OPENAI_EMBEDDING_DEPLOYMENT not set. Add the line from .env.example. Using 'text-embedding-3-small' for now.")
if ok:
    try:
        import embed_helpers
        client, dep = embed_helpers.get_embed_client()
        r = client.embeddings.create(model=dep, input=["test"])
        print(f"[ ok    ] embedding call worked. vector length = {len(r.data[0].embedding)}")
    except Exception as ex:
        from common import explain_error
        explain_error(ex)
        ok = False
print("\nREADY for Lab 8." if ok else "\nNot ready. Fix the lines above, or raise your hand.")
