# Lab 8 — Same articles, searched by meaning (30 minutes)

**Story.** In Lab 7 (Day 1) your IT Support Helper found KB articles by counting shared words. Today the SAME 10 articles and the SAME 6 questions from Lab 4 go through **embeddings** (`text-embedding-3-small`) and a **local Chroma database**. You will measure if finding by meaning is better.

## Setup (3 min)
1. Copy this overlay into your repo root (adds `day2_lab_8/`, `lib/embed_helpers.py`, `setup/check_env_day2.py`; `lib/kb_tools.py` is also provided).
2. `pip install chromadb`
3. Add ONE line to your `.env` (never share it): `AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small`
4. `python setup/check_env_day2.py` must end with "READY".

## Your 4 TODOs — all in `day2_lab_8/scripts/lab_chroma.py`
| Min | TODO | What |
|---|---|---|
| 3–10 | 1 | `embed_texts`: ask Azure for one vector per text |
| 10–15 | 2 | `build_store`: add the 10 articles (text + vector) to Chroma |
| 15–20 | 3 | `search_store`: ask Chroma for the nearest articles; turn distance into cosine |
| 20–23 | 4 | `recall_at_k`: the same metric as Day 1 |

Run: `python day2_lab_8/scripts/lab_chroma.py`

## Then (23–30 min)
- Fill `results/RESULT_TABLE.md` from YOUR run.
- Run with your own question: `python day2_lab_8/scripts/lab_chroma.py --ask "I cannot get in after too many tries."` Compare the two columns.
- Write ONE sentence: *"Embedding search was better/worse than keyword for ___ because ___."*

## Done when
- [ ] Output says "Chroma now holds 10 articles (1536 numbers each)"
- [ ] You have recall@1/2/3 for keyword AND chroma
- [ ] You tried one question of your own
- [ ] You wrote your one sentence

## Stretch
- Which question did embeddings rank 1 but keyword did not? Why do those words differ?
- Ask something not in the KB ("What is the dress code?"). What cosine does the best article get?

## Rules
Never print or paste your API key. Your numbers are your evidence — do not copy from a neighbour. Stuck? `hints/HINTS.md` has 3 levels per TODO.
