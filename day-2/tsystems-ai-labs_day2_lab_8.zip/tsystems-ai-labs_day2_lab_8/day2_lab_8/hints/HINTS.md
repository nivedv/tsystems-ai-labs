# Lab 8 hints (3 levels each — open one level at a time)

## TODO 1 — `embed_texts`
- **L1.** The client has `embeddings.create`, like `chat.completions.create` on Day 1.
- **L2.** `model=` is the deployment name, `input=` is the whole list of texts.
- **L3.** `resp = client.embeddings.create(model=deployment, input=texts)` then `return [item.embedding for item in resp.data]`

## TODO 2 — `build_store`
- **L1.** A Chroma collection stores three parallel lists: ids, documents (text), embeddings (numbers).
- **L2.** `ids`, `docs`, `vectors` are already prepared above the TODO.
- **L3.** `col.add(ids=ids, documents=docs, embeddings=vectors)`

## TODO 3 — `search_store`
- **L1.** `col.query(query_embeddings=[qvec], n_results=k)` — note the list around `qvec`.
- **L2.** Results are lists inside lists: first question = index `[0]`. Chroma gives a DISTANCE (small = close).
- **L3.** `res = col.query(...)`; `return [(i, 1 - d) for i, d in zip(res["ids"][0], res["distances"][0])]`

## TODO 4 — `recall_at_k`
- **L1.** A hit = the right article is among the first k ids.
- **L2.** `q["key"]` is the right article; `rankings[q["id"]]` is the list, best first.
- **L3.** `hits = sum(1 for q in questions if q["key"] in rankings[q["id"]][:k])`; `return hits / len(questions)`

## Common errors
| You see | Meaning | Fix |
|---|---|---|
| `404 DeploymentNotFound` | wrong embedding deployment name | check the `.env` line |
| `TODO n is not done yet` | message names the TODO to finish | do that one |
| `No module named chromadb` | not installed | `pip install chromadb` |
| `Expected embeddings to be a list` | passed one vector, not a list of vectors | wrap in `[ ]` |
