# Lab 8 — my results (fill in from YOUR run)

| Search | recall@1 | recall@2 | recall@3 |
|---|---|---|---|
| Keyword (Day 1) | | | |
| Chroma + embeddings (today) | | | |

Questions Chroma got at rank 1 but keyword did not: ______

My own question: ______________________   Keyword top-1: ______   Chroma top-1: ______   cosine: ______

My one sentence:
______________________________________________
