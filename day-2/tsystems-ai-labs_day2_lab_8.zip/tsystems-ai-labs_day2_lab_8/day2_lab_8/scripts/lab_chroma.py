"""Lab 8: the SAME 10 IT-support articles, now searched by MEANING with embeddings stored in Chroma (local).

Run from the repo root:
  python day2_lab_8/scripts/lab_chroma.py
  python day2_lab_8/scripts/lab_chroma.py --ask "I cannot get in after too many tries."
Do the 4 TODOs in this file, top to bottom. Each run makes 1-2 embedding calls.
"""
import argparse
import json
import pathlib
import shutil
import sys

import chromadb

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(REPO / "lib"))
import common  # noqa: E402
import embed_helpers  # noqa: E402
import kb_tools  # noqa: E402

CHROMA_DIR = HERE.parent / "results" / "chroma"


def embed_texts(texts):
    """Turn a list of texts into a list of vectors (one list of 1,536 numbers per text, same order)."""
    client, deployment = embed_helpers.get_embed_client()
    # TODO 1: call client.embeddings.create(model=deployment, input=texts)
    #         and return [item.embedding for item in resp.data]
    return None


def build_store(kb):
    """Create a fresh local Chroma collection and put every article into it."""
    shutil.rmtree(CHROMA_DIR, ignore_errors=True)
    db = chromadb.PersistentClient(path=str(CHROMA_DIR))
    col = db.create_collection("lab_kb", metadata={"hnsw:space": "cosine"})
    ids = list(kb)
    docs = [kb[i] for i in ids]
    vectors = embed_texts(docs)
    if not vectors:
        sys.exit("TODO 1 is not done yet: embed_texts returns None. See hints/HINTS.md")
    # TODO 2: add the articles to the collection: col.add(ids=..., documents=..., embeddings=...)
    return col


def search_store(col, qvec, k):
    """Return the ids of the k nearest articles, best first."""
    # TODO 3: res = col.query(query_embeddings=[qvec], n_results=k)
    #         Chroma returns lists inside lists: the ids are in res["ids"][0]; distances in res["distances"][0].
    #         Return [(id, 1 - distance), ...]  (cosine similarity = 1 - distance)
    return None


def recall_at_k(rankings, questions, k):
    """Share of questions whose right article (q["key"]) is in the first k ids of rankings[q["id"]]."""
    # TODO 4: count the hits and return hits / len(questions)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ask", help="your own question")
    args = ap.parse_args()
    kb = kb_tools.load_kb()
    questions = json.loads((REPO / "data/lab4_questions.json").read_text(encoding="utf-8"))["questions"]
    try:
        col = build_store(kb)
        if col.count() == 0:
            sys.exit("TODO 2 is not done yet: nothing was added to Chroma. See hints/HINTS.md")
        extra = [args.ask] if args.ask else []
        qvecs = embed_texts([q["text"] for q in questions] + extra)
    except Exception as e:
        common.explain_error(e)
        sys.exit(1)
    print(f"Chroma now holds {col.count()} articles ({len(qvecs[0])} numbers each).\n")

    rank_kw, rank_ch, best = {}, {}, {}
    for q, qv in zip(questions, qvecs):
        rank_kw[q["id"]] = kb_tools.keyword_rank(q["text"], kb)
        res = search_store(col, qv, len(kb))
        if not res:
            sys.exit("TODO 3 is not done yet: search_store returns nothing.")
        rank_ch[q["id"]] = [i for i, _ in res]
        best[q["id"]] = res[0][1]

    print(f"{'q':<5}{'right':<9}{'keyword rank':<15}{'chroma rank':<14}{'best cosine'}")
    for q in questions:
        print(f"{q['id']:<5}{q['key']:<9}{rank_kw[q['id']].index(q['key']) + 1!s:<15}{rank_ch[q['id']].index(q['key']) + 1!s:<14}{best[q['id']]:.3f}")

    print(f"\n{'':<10}{'recall@1':<11}{'recall@2':<11}{'recall@3':<11}")
    out = {}
    for name, ranks in (("keyword", rank_kw), ("chroma", rank_ch)):
        vals = [recall_at_k(ranks, questions, k) for k in (1, 2, 3)]
        if any(v is None for v in vals):
            sys.exit("TODO 4 is not done yet: recall_at_k returns None.")
        out[name] = [round(v, 2) for v in vals]
        print(f"{name:<10}" + "".join(f"{v:<11.2f}" for v in vals))
    (HERE.parent / "results" / "lab8_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    if args.ask:
        print(f"\nYour question: {args.ask}")
        print(f"{'KEYWORD (Day 1)':<28}CHROMA (today)")
        kw = kb_tools.keyword_rank(args.ask, kb)[:3]
        ch = search_store(col, qvecs[-1], 3)
        for a, (b, sc) in zip(kw, ch):
            print(f"{a:<28}{b}  cosine {sc:.3f}   {kb[b][:50]}...")
    print("\nWrite your numbers in results/RESULT_TABLE.md. Six questions: one question = about 17 points.")


if __name__ == "__main__":
    main()
