"""Provided: load the 10 articles and the Day 1 keyword search, so Lab 5 does not depend on your Day 1 files."""
import pathlib
import re

import common
import textutils

KB_DIR = common.ROOT / "kb"


def load_kb(kb_dir=KB_DIR):
    kb = {}
    for p in sorted(pathlib.Path(kb_dir).glob("KB-*.txt")):
        raw = p.read_text(encoding="utf-8")
        title = re.search(r"Title:\s*(.*)", raw).group(1).strip()
        body = re.search(r"Text:\s*(.*)", raw, re.S).group(1).strip()
        kb[p.stem] = f"{title}. {body}"
    return kb


def keyword_rank(question, kb):
    """Day 1 search: score = how many DIFFERENT question words are in the article. Returns ids, best first (ties: smaller id)."""
    q = set(textutils.words(question))
    rows = [(i, len(q & set(textutils.words(t)))) for i, t in kb.items()]
    rows.sort(key=lambda r: (-r[1], r[0]))
    return [i for i, _ in rows]
