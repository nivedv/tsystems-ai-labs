"""Provided: the Azure client plus the name of the EMBEDDING deployment (text-embedding-3-small)."""
import os

import common


def get_embed_client():
    client, _chat = common.get_client()
    return client, os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
