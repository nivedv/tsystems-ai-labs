# Leave and Attendance Policy

## Annual leave
Full-time employees receive 24 days of paid annual leave per calendar year. Leave accrues monthly at two days per month. Up to five unused days can be carried forward to the next year; the remainder lapses on 31 March.

## Sick leave
Employees receive 10 days of paid sick leave per year. A medical certificate is required for absences of three or more consecutive days. Notify your manager before the start of your working day if you are unwell.

## Parental leave
Primary caregivers are entitled to 26 weeks of paid parental leave. Secondary caregivers are entitled to four weeks. Parental leave must begin within 12 months of the birth or adoption.

## Remote work
Employees may work remotely up to three days per week with manager agreement. Core collaboration hours are 11:00 to 16:00 in the employee's local time. Remote work from another country for more than 10 working days in a year requires HR and tax approval.

## Public holidays
The company observes 12 public holidays per year, published in the HR portal each December. If a public holiday falls on a weekend, no substitute day is given.
