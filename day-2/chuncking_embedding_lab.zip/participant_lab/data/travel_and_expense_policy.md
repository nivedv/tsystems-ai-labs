# Travel and Expense Policy

## Booking business travel
All business travel must be booked through the corporate travel portal at least 14 days before departure. Economy class is required for flights under six hours. Business class is allowed for flights of six hours or longer with director approval. Hotels must be booked within the nightly cap: 150 USD for tier-1 cities and 100 USD elsewhere.

## Claiming expenses
Submit expense claims within 30 days of the trip ending. Attach itemised receipts for any single expense above 25 USD. Claims without receipts are rejected unless the amount is under 25 USD. Reimbursement is paid in the next monthly payroll cycle after manager approval.

## Meals and per diem
When travelling, the daily meal allowance is 60 USD in tier-1 cities and 40 USD elsewhere. Alcohol is not reimbursable. Client entertainment must be pre-approved by a manager and cannot exceed 100 USD per person.

## Mileage
Use of a personal car for business travel is reimbursed at 0.58 USD per mile. Record the start and end location and total miles in the claim.
