"""
PARTICIPANT LAB - Build a RAG assistant for the Contoso HR & Travel Policy Bot
STARTER FILE - complete every TODO. Tasks 1-5 are explained in the lab guide.
"""
import os
import glob
import numpy as np
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()
client = AzureOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-10-21"),
)
EMBED_DEPLOYMENT = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
CHAT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4.1")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100
TOP_K = 3
MIN_SCORE = 0.30


# TASK 1 - CHUNKING
def chunk_text(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    # TODO 1: slide a window of `size` characters across `text` with `overlap` characters shared.
    # Snap each cut to the last space inside the window so words are not split.
    # Return a list of stripped, non-empty chunk strings.
    raise NotImplementedError


def load_and_chunk(folder="data"):
    records = []
    for path in sorted(glob.glob(os.path.join(folder, "*.md"))):
        name = os.path.basename(path)
        with open(path, encoding="utf-8") as f:
            text = f.read()
        for i, chunk in enumerate(chunk_text(text)):
            records.append({"id": f"{name}#{i}", "source": name, "text": chunk})
    return records


# TASK 2 - EMBEDDINGS
def embed(texts):
    # TODO 2a: call client.embeddings.create(model=EMBED_DEPLOYMENT, input=texts)
    # Return a numpy float32 array of shape (len(texts), 1536).
    raise NotImplementedError


def build_index(records):
    # TODO 2b: embed every chunk's text, then L2-normalise each row (so dot product == cosine).
    raise NotImplementedError


# TASK 3 - VECTOR SEARCH + RETRIEVAL
def retrieve(query, records, index, k=TOP_K):
    # TODO 3: embed + normalise the query, score = index @ q, take the top k by score,
    # drop anything below MIN_SCORE, and return records with an added 'score' key.
    raise NotImplementedError


# TASK 4 - GROUNDING
SYSTEM_PROMPT = """You are the Contoso HR and Travel Policy assistant.
Answer ONLY from the CONTEXT provided. Cite the source file in square brackets after each fact.
If the context does not contain the answer, reply exactly: "I can't find that in the policy documents - please contact HR."
Do not use outside knowledge."""


def answer(query, hits):
    # TODO 4: if hits is empty return the refusal sentence. Otherwise build a CONTEXT block
    # ('[source] + newline + text' for each hit), call client.chat.completions.create(model=CHAT_DEPLOYMENT,
    # temperature=0, messages=[system, user]) and return the message content.
    raise NotImplementedError


# TASK 5 - TEST HARNESS
TEST_QUESTIONS = [
    ("How many days of annual leave can I carry forward?", True),
    ("Do I need a receipt for a 20 dollar taxi?", True),
    ("Can I fly business class to Singapore?", True),
    ("What is the dress code for the office?", False),   # not in the documents
]

def main():
    records = load_and_chunk("data")
    print(f"Chunks: {len(records)}")
    index = build_index(records)
    print(f"Index shape: {index.shape}")
    for q, expected in TEST_QUESTIONS:
        hits = retrieve(q, records, index)
        print("\n" + "=" * 70 + f"\nQ: {q}   (answer in KB: {expected})")
        for h in hits:
            print(f"   {h['score']:.3f}  {h['id']}")
        print(answer(q, hits))

if __name__ == "__main__":
    main()
