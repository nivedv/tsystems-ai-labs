"""
PARTICIPANT LAB - Build a RAG assistant for the Contoso HR & Travel Policy Bot
SOLUTION FILE (trainer copy). Participants receive rag_lab_starter.py.
"""
import os
import glob
import numpy as np
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()
client = AzureOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-10-21"),
)
EMBED_DEPLOYMENT = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
CHAT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT", "gpt-4.1")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100
TOP_K = 3
MIN_SCORE = 0.30


# TASK 1 - CHUNKING
def chunk_text(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            space = text.rfind(" ", start, end)
            if space > start + size // 2:
                end = space
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def load_and_chunk(folder="data"):
    records = []
    for path in sorted(glob.glob(os.path.join(folder, "*.md"))):
        name = os.path.basename(path)
        with open(path, encoding="utf-8") as f:
            text = f.read()
        for i, chunk in enumerate(chunk_text(text)):
            records.append({"id": f"{name}#{i}", "source": name, "text": chunk})
    return records


# TASK 2 - EMBEDDINGS
def embed(texts):
    resp = client.embeddings.create(model=EMBED_DEPLOYMENT, input=texts)
    return np.array([d.embedding for d in resp.data], dtype=np.float32)


def build_index(records):
    vectors = embed([r["text"] for r in records])
    return vectors / np.linalg.norm(vectors, axis=1, keepdims=True)


# TASK 3 - VECTOR SEARCH + RETRIEVAL
def retrieve(query, records, index, k=TOP_K):
    q = embed([query])[0]
    q = q / np.linalg.norm(q)
    scores = index @ q
    top = np.argsort(scores)[::-1][:k]
    return [{**records[i], "score": float(scores[i])} for i in top if scores[i] >= MIN_SCORE]


# TASK 4 - GROUNDING
SYSTEM_PROMPT = """You are the Contoso HR and Travel Policy assistant.
Answer ONLY from the CONTEXT provided. Cite the source file in square brackets after each fact.
If the context does not contain the answer, reply exactly: "I can't find that in the policy documents - please contact HR."
Do not use outside knowledge."""


def answer(query, hits):
    if not hits:
        return "I can't find that in the policy documents - please contact HR."
    context = "\n\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)
    resp = client.chat.completions.create(
        model=CHAT_DEPLOYMENT,
        temperature=0,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"CONTEXT:\n{context}\n\nQUESTION: {query}"},
        ],
    )
    return resp.choices[0].message.content


# TASK 5 - TEST HARNESS
TEST_QUESTIONS = [
    ("How many days of annual leave can I carry forward?", True),
    ("Do I need a receipt for a 20 dollar taxi?", True),
    ("Can I fly business class to Singapore?", True),
    ("What is the dress code for the office?", False),   # not in the documents
]

def main():
    records = load_and_chunk("data")
    print(f"Chunks: {len(records)}")
    index = build_index(records)
    print(f"Index shape: {index.shape}")
    for q, expected in TEST_QUESTIONS:
        hits = retrieve(q, records, index)
        print("\n" + "=" * 70 + f"\nQ: {q}   (answer in KB: {expected})")
        for h in hits:
            print(f"   {h['score']:.3f}  {h['id']}")
        print(answer(q, hits))

if __name__ == "__main__":
    main()
