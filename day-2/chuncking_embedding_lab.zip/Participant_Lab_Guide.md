# Participant Lab: Build a RAG Assistant for HR and Travel Policies

**Duration:** 50 minutes | **Work:** individually in VS Code
**Folder:** `participant_lab/` | **Starter file:** `rag_lab_starter.py`
**Models (Azure OpenAI deployments):** `text-embedding-3-small`, `gpt-4.1`

## Scenario
Contoso employees keep asking HR the same questions about travel and leave. You will build an assistant that answers **only** from two policy documents, cites the source file, and refuses when the answer is not in the documents.

You repeat the method from the trainer demo on **different data**. Do not copy the demo; apply the pattern.

## Setup (5 min)
1. Open the `participant_lab` folder in VS Code.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`. Your trainer will share the endpoint, key and deployment names. The embedding deployment is `text-embedding-3-small`.
4. Open `data/` and skim both policies (about 2 minutes).

## Tasks (complete the TODOs in `rag_lab_starter.py`)

| # | Task | Time | Done when |
|---|---|---|---|
| 1 | **Chunking** - implement `chunk_text` (window of 500 chars, 100 overlap, snap cuts to a space) | 10 min | `load_and_chunk("data")` returns chunks; none longer than ~500 chars; neighbours overlap |
| 2 | **Embeddings** - implement `embed` and `build_index` (batch call, normalise rows) | 10 min | `index.shape` equals `(number of chunks, 1536)` |
| 3 | **Vector search + retrieval** - implement `retrieve` (cosine via dot product, top-k, threshold) | 10 min | Each query prints scored chunks, best first |
| 4 | **Grounding** - implement `answer` (context block, system rules, temperature 0, refusal) | 10 min | Answers include `[source file]` citations |
| 5 | **Test and tune** - run `python rag_lab_starter.py` and review the 4 test questions | 5 min | See acceptance criteria |

## Acceptance criteria (the lab is passed when all are true)
- Index shape matches your chunk count and 1,536 dimensions.
- The three in-scope questions each retrieve the correct policy file at rank 1:
  - annual leave carry-forward -> `leave_and_attendance_policy.md`
  - receipt for a 20 dollar taxi -> `travel_and_expense_policy.md`
  - business class flight -> `travel_and_expense_policy.md`
- The out-of-scope question (dress code) returns the refusal sentence.
- Every factual answer cites a source file.

## Hints
- Task 1: `text.rfind(" ", start, end)` finds the last space inside the window. Next window starts at `end - overlap`.
- Task 2: `resp.data[i].embedding` holds one vector. Normalise with `np.linalg.norm(v, axis=1, keepdims=True)`.
- Task 3: `np.argsort(scores)[::-1][:k]` gives best-first indices.
- Task 4: if `hits` is empty, return the refusal without calling the model.
- Stuck for more than 5 minutes? Raise your hand.

## Stretch goals (if you finish early)
1. Add 3 more test questions of your own, including one trap that is not in the documents. Record pass or fail for each.
2. Change `CHUNK_SIZE` to 250, then 800. Re-run the same questions. Which setting gives the best retrieval? Write down one sentence why.
3. Print `score` for the out-of-scope question. What threshold separates relevant from irrelevant on this data?
4. Make `retrieve` accept an optional `source` filter (metadata filtering).

## Reflection (answer in a comment at the bottom of your file)
- Which step took longest to get right, and why?
- What would break if documents were embedded with one model and questions with another?
- Name one change you would make before using this on 10,000 documents.
