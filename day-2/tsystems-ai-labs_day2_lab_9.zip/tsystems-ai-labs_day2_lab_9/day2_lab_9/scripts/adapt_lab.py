"""The adaptation decision, with evidence. Same questions, three ways to give the model company knowledge:

  P  prompt only        : just an instruction, no articles
  S  stuff everything   : all 10 articles pasted into the prompt (long prompt)
  R  RAG                : the 2 best articles found by Chroma (Day 2)

  python day2_lab_9/scripts/adapt_lab.py                       # 6 questions + the VPN-7 probe, 3 conditions = 21 chat calls
  python day2_lab_9/scripts/adapt_lab.py --price-in 0.40 --price-out 1.60     # your price per 1M tokens (look it up; do not guess)
Fine-tuning is not run here. It needs hundreds of labelled examples and a training job. See the decision memo.
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "lib"))
sys.path.insert(0, str(HERE))
import argparse
import json
import time

import agent_tools
import common
import grounding as rag

ap = argparse.ArgumentParser()
ap.add_argument("--questions", default="data/lab4_questions.json")
ap.add_argument("--facts", default="data/adapt_facts_b.json")
ap.add_argument("--price-in", type=float, default=None, help="price per 1M input tokens")
ap.add_argument("--price-out", type=float, default=None, help="price per 1M output tokens")
a = ap.parse_args()

kb = agent_tools._load_kb()
questions = json.loads((common.ROOT / a.questions).read_text(encoding="utf-8"))["questions"]
facts = json.loads((common.ROOT / a.facts).read_text(encoding="utf-8"))
probe = "What is our VPN-7 remote access policy?"
PROMPT_ONLY = ("You are the IT Support Helper of our company. Answer the employee's question briefly. "
               "If you do not know, reply: not found.")


def condition_messages(cond, question):
    # TODO 5: return the list of chat messages for each condition:
    #   "P": system = PROMPT_ONLY, user = question                                  (no articles)
    #   "S": rag.build_messages(question, hits, kb) with ALL 10 articles as hits    (hits are tuples like ("KB-001",))
    #   "R": the same, but hits = the 2 articles from agent_tools.search_kb(question, k=2)["articles"]
    raise SystemExit("TODO 5 is not done yet. See hints/HINTS.md")


client, deployment = common.get_client()
rows = {c: {"fact": 0, "right": 0, "pt": 0, "ct": 0, "probe_nf": None, "probe_pt": 0} for c in "PSR"}
try:
    for cond in "PSR":
        for q in questions:
            resp, _ = common.call_model(client, deployment, condition_messages(cond, q["text"]))
            ans = resp.choices[0].message.content or ""
            rows[cond]["fact"] += facts[q["id"]] in ans.lower()
            rows[cond]["right"] += q["key"] in rag.cited(ans)
            rows[cond]["pt"] += resp.usage.prompt_tokens
            rows[cond]["ct"] += resp.usage.completion_tokens
            time.sleep(0.2)
        resp, _ = common.call_model(client, deployment, condition_messages(cond, probe))
        rows[cond]["probe_nf"] = "not found" in (resp.choices[0].message.content or "").lower()
        rows[cond]["probe_pt"] = resp.usage.prompt_tokens
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)

n = len(questions)
names = {"P": "prompt only", "S": "stuff all 10 articles", "R": "RAG (Chroma, k=2)"}
print(f"\n{'':<24}{'has the fact':<14}{'cites right':<13}{'VPN-7 -> not found':<20}{'avg input tokens':<18}")
for c in "PSR":
    r = rows[c]
    print(f"{names[c]:<24}{str(r['fact']) + '/' + str(n):<14}{str(r['right']) + '/' + str(n):<13}{'yes' if r['probe_nf'] else 'NO (it answered)':<20}{r['pt'] // n:<18}")
if a.price_in is not None and a.price_out is not None:
    print("\nEstimated cost for 1,000 questions at YOUR prices:")
    for c in "PSR":
        r = rows[c]
        cost = (r["pt"] / n * 1000 * a.price_in + r["ct"] / n * 1000 * a.price_out) / 1_000_000
        print(f"  {names[c]:<24}{cost:.4f}")
else:
    print("\n(Add --price-in and --price-out, per 1M tokens, to see cost per 1,000 questions. Use the price from your Azure pricing page.)")
print(f"\nCaution: {n} questions + 1 probe. One question = about {round(100 / n)} points. 'has the fact' is a simple phrase check.")
