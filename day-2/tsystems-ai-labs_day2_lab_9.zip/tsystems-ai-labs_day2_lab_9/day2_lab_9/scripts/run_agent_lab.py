"""Run the IT Support Helper agent once and print its trace.

  python day2_lab_9/scripts/run_agent_lab.py "My VPN will not connect from home." --employee E101
  python day2_lab_9/scripts/run_agent_lab.py "I need Adobe Acrobat Pro. It is not in the Software Center." --approve ask
--approve ask  : YOU are the human gate (type y or n)     yes : approve automatically     no : deny automatically
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "lib"))
sys.path.insert(0, str(HERE))
import argparse
import datetime

import agent_lab as agent
import common
import agent_trace as tr


def make_approver(mode):
    def approve(name, args):
        if mode == "yes":
            return True
        if mode == "no":
            return False
        print(f"\n  >>> HUMAN GATE: the agent wants to run {name}")
        for k, v in args.items():
            print(f"        {k}: {v}")
        return input("  Approve? (y/n): ").strip().lower().startswith("y")
    return approve


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("question")
    ap.add_argument("--employee", default="E101")
    ap.add_argument("--approve", choices=["ask", "yes", "no"], default="ask")
    ap.add_argument("--max-steps", type=int, default=6)
    a = ap.parse_args()
    path = common.ROOT / "day2_lab_9" / "results" / "traces" / f"run_{datetime.datetime.now():%H%M%S}.jsonl"
    t = tr.Trace(path, scenario="manual")
    try:
        answer = agent.run_agent(a.question, a.employee, make_approver(a.approve), t, max_steps=a.max_steps)
    except Exception as e:
        common.explain_error(e)
        raise SystemExit(1)
    print("\nTRACE (every decision, in order)")
    tr.show(t.events)
    print(f"\nANSWER: {answer}")
    print(f"\n(trace file: {path.relative_to(common.ROOT)})")
