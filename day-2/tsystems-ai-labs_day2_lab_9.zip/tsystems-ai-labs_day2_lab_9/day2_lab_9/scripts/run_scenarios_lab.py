"""Run the 4 scenarios, several times each, and check TRACE assertions (not exact words).

  python day2_lab_9/scripts/run_scenarios_lab.py                 # 1 run each, a human is auto-approved
  python day2_lab_9/scripts/run_scenarios_lab.py --repeat 3      # 3 runs each: non-deterministic flows need a pass RATE
  python day2_lab_9/scripts/run_scenarios_lab.py --approve no    # the human says NO to every ticket
  python day2_lab_9/scripts/run_scenarios_lab.py --only t2 --show
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "lib"))
sys.path.insert(0, str(HERE))
import argparse
import json

import agent_lab as agent
import assert_lab as at
import common
import agent_trace as tr
from run_agent_lab import make_approver

ap = argparse.ArgumentParser()
ap.add_argument("--repeat", type=int, default=1)
ap.add_argument("--approve", choices=["yes", "no"], default="yes")
ap.add_argument("--only", default="")
ap.add_argument("--show", action="store_true", help="print each trace")
a = ap.parse_args()

scen = json.loads((common.ROOT / "data/agent_scenarios.json").read_text(encoding="utf-8"))["scenarios"]
if a.only:
    scen = [s for s in scen if s["id"] in a.only.split(",")]
client, deployment = common.get_client()
names = [f.__name__ for f in at.CHECKS]
tally = {s["id"]: {n: 0 for n in names} for s in scen}
fails = []
tokens = 0
for s in scen:
    for r in range(1, a.repeat + 1):
        t = tr.Trace(common.ROOT / "day2_lab_9" / "results" / "traces" / f"{s['id']}_{a.approve}_{r}.jsonl", scenario=s["id"])
        try:
            agent.run_agent(s["text"], s["employee"], make_approver(a.approve), t, client=client, deployment=deployment)
        except Exception as e:
            common.explain_error(e)
            raise SystemExit(1)
        tokens += sum(e["prompt_tokens"] + e["completion_tokens"] for e in t.events if e["type"] == "model_call")
        if a.show:
            print(f"\n--- {s['id']} run {r}")
            tr.show(t.events)
        for n, (ok, msg) in at.check_all(t.events, s["expect"], a.approve).items():
            tally[s["id"]][n] += ok
            if not ok:
                fails.append(f"{s['id']} run {r}: {n} -> {msg}")

print(f"\nPass rate per assertion  ({a.repeat} run(s) per scenario, human = {a.approve})")
short = [n.replace("a_", "")[:15] for n in names]
print(f"{'':<5}" + "".join(f"{x:<17}" for x in short))
for s in scen:
    print(f"{s['id']:<5}" + "".join(f"{tally[s['id']][n]}/{a.repeat:<15}" for n in names))
print(f"\ntotal tokens for this batch: {tokens}")
if fails:
    print("\nFAILED CHECKS")
    for f in fails:
        print("  " + f)
else:
    print("\nAll assertions passed.")
print("Traces are in day2_lab_9/results/traces/. Open one and read it like a story.")
