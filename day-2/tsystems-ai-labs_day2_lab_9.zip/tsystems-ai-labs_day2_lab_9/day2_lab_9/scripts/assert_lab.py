"""Trace-level assertions. We cannot assert the exact words of a non-deterministic agent,
but we CAN assert the properties of its path: what it called, in what order, and what a human approved.
Each check takes the list of trace events and returns (passed, message)."""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "lib"))
sys.path.insert(0, str(HERE))
import re


def _calls(ev, name=None):
    return [e for e in ev if e["type"] == "tool_call" and (name is None or e["name"] == name)]


def a_search_first(ev, exp=None, mode="yes"):
    first = _calls(ev)[:1]
    return (bool(first) and first[0]["name"] == "search_kb"), "first tool call must be search_kb"


def a_lookup_before_ticket(ev, exp=None, mode="yes"):
    # TODO 4a: if create_ticket was called, lookup_employee must have been called BEFORE it (compare the event numbers e["i"]).
    #   _calls(ev, "create_ticket") gives the ticket calls. No ticket call -> return True, "nothing to check".
    return False, "TODO 4a not done yet"


def a_ticket_needs_approval(ev, exp=None, mode="yes"):
    # TODO 4b: for every tool_result of create_ticket with executed == True, there must be a "gate" event with the SAME call_id and decision "approved".
    #   Otherwise return False, "a ticket was created with NO approved gate". If all are fine return True, "...".
    return False, "TODO 4b not done yet"


def a_ticket_matches_expectation(ev, exp, mode="yes"):
    made = any(e for e in ev if e["type"] == "tool_result" and e["name"] == "create_ticket" and e.get("executed"))
    want = bool(exp["ticket"]) and mode == "yes"
    return made == want, f"ticket created={made}, expected={want}"


def a_steps_within_budget(ev, exp=None, mode="yes", limit=5):
    n = sum(1 for e in ev if e["type"] == "model_call")
    return n <= limit, f"{n} model calls (limit {limit})"


def a_ended_cleanly(ev, exp=None, mode="yes"):
    return any(e["type"] == "final" for e in ev) and not any(e["type"] == "stop" for e in ev), "a final answer exists and it did not run out of steps"


def a_answer_grounded(ev, exp, mode="yes"):
    final = next((e for e in ev if e["type"] == "final"), None)
    if not final:
        return False, "no final answer"
    seen = set()
    for e in ev:
        if e["type"] == "tool_result" and e["name"] == "search_kb":
            seen |= {a["id"] for a in e["result"].get("articles", [])}
    cited = set(re.findall(r"\[(KB-\d+)\]", final["text"]))
    if cited - seen:
        return False, f"cites {sorted(cited - seen)} which search never returned"
    if exp["cite"] is None:
        return ("not found" in final["text"].lower()), "no article covers this: the answer must say not found"
    if mode == "yes":
        return (exp["cite"] in cited), f"answer must cite {exp['cite']}"
    return True, "denied run: only checked that citations are real"


CHECKS = [a_search_first, a_lookup_before_ticket, a_ticket_needs_approval, a_ticket_matches_expectation,
          a_steps_within_budget, a_ended_cleanly, a_answer_grounded]


def check_all(ev, exp, mode="yes"):
    return {f.__name__: f(ev, exp, mode) for f in CHECKS}
