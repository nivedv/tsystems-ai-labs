"""The agent loop: model -> tool call -> (human gate) -> tool result -> model ... until it answers.
Control flow lives HERE, in plain Python, not in the prompt. Every decision goes to the trace."""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "lib"))
sys.path.insert(0, str(HERE))
import json

import agent_tools
import common
from agent_tools import GATED, TOOLS, dispatch

SYSTEM = (
    "You are the IT Support Helper for employees. "
    "ALWAYS call search_kb first. Answer ONLY from the articles and cite IDs like [KB-004]. "
    "If the articles do not cover the question, reply: not found. Do not open a ticket for it. "
    "If an article says a request, form or manager approval is needed, call lookup_employee, then create_ticket. "
    "Never open a ticket for a question the articles already answer. "
    "Signed-in employee ID: {employee_id}."
)


def run_agent(user_text, employee_id, approve, trace, max_steps=6, client=None, deployment=None):
    """approve(name, args) -> True/False is the human gate. Returns the final answer (or None if it ran out of steps)."""
    if client is None:
        client, deployment = common.get_client()
    messages = [{"role": "system", "content": SYSTEM.format(employee_id=employee_id)},
                {"role": "user", "content": user_text}]
    trace.log("run_start", scenario=trace.scenario, employee=employee_id, question=user_text, max_steps=max_steps)
    for step in range(1, max_steps + 1):
        resp, _secs = common.call_model(client, deployment, messages, tools=TOOLS)
        msg = resp.choices[0].message
        calls = msg.tool_calls or []
        trace.log("model_call", step=step, prompt_tokens=resp.usage.prompt_tokens,
                  completion_tokens=resp.usage.completion_tokens, tool_calls=[c.function.name for c in calls])
        if not calls:
            trace.log("final", step=step, text=msg.content or "")
            return msg.content
        # TODO 1: the model asked for tools. Add the ASSISTANT message that contains those tool calls to `messages`:
        #   {"role": "assistant", "content": msg.content,
        #    "tool_calls": [{"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}} for c in calls]}
        raise SystemExit("TODO 1 is not done yet. See hints/HINTS.md")
        for c in calls:
            name = c.function.name
            args = json.loads(c.function.arguments or "{}")
            trace.log("tool_call", step=step, call_id=c.id, name=name, args=args)
            executed = True
            # TODO 2: the HUMAN GATE.
            #   If name is in GATED: approved = approve(name, args), then trace.log("gate", step=step, call_id=c.id, name=name,
            #   decision="approved" or "denied"). If denied: executed = False and result = {"error": "A human reviewer denied this action. Do not retry."}
            #   If approved, or the tool is not gated: result = dispatch(name, args)
            raise SystemExit("TODO 2 is not done yet. See hints/HINTS.md")
            # TODO 3: make this step traceable. Log ONE "tool_result" event:
            #   trace.log("tool_result", step=step, call_id=c.id, name=name, ok=..., executed=executed, result=result)
            #   ok is True when the tool ran and result has no "error" key.
            messages.append({"role": "tool", "tool_call_id": c.id, "content": json.dumps(result)})
    trace.log("stop", reason="max_steps")
    return None
