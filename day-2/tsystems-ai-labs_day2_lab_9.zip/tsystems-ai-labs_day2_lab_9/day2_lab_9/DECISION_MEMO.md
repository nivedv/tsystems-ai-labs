# Decision memo — how should the IT Support Helper get company knowledge?

## Options compared
| Option | Evidence from my run | Data it needs | What happens when an article changes | Verdict |
|---|---|---|---|---|
| Prompt only | | none | nothing to update, but it cannot know | |
| Stuff all 10 articles | | the articles | edit the text | |
| RAG (Chroma + embeddings) | | the articles | re-embed that article | |
| Fine-tune | NOT run. Needs hundreds of labelled question-answer pairs and a training job. We have ____ pairs. | | retrain | |
| Don't use AI | Which of our requests could be a plain link or form? ______________ | none | edit the form | |

## My choice (one option): ______________________

## My argument (5 sentences, at least 2 numbers from my table)
1.
2.
3.
4.
5.

## What would change my mind (a measurable trigger, e.g. "if the KB grows past ___ articles" or "if recall@2 falls below ___")
______________________________________________

## Honest limits of my evidence
______________________________________________
