# Lab 9 hints (3 levels each — open one level at a time)

## TODO 1 — put the tool request into `messages`
- **L1.** The API wants to see that the assistant asked for tools BEFORE it sees the tool answers.
- **L2.** Append ONE assistant message that has a `tool_calls` list. Each item has `id`, `type: "function"` and `function: {name, arguments}`.
- **L3.** `messages.append({"role": "assistant", "content": msg.content, "tool_calls": [{"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}} for c in calls]})`

## TODO 2 — the human gate
- **L1.** Only tools in `GATED` need a human. The other tools run straight away.
- **L2.** `approve(name, args)` returns True or False. Log a `gate` event either way, then decide whether to run the tool. A denied tool returns an error text the model can read.
- **L3.**
```
if name in GATED:
    approved = approve(name, args)
    trace.log("gate", step=step, call_id=c.id, name=name, decision="approved" if approved else "denied")
    if not approved:
        executed = False
        result = {"error": "A human reviewer denied this action. Do not retry. Tell the employee what happens next."}
    else:
        result = dispatch(name, args)
else:
    result = dispatch(name, args)
```

## TODO 3 — the `tool_result` event
- **L1.** One trace line per tool result: step, call_id, name, ok, executed, result.
- **L2.** `ok` = the tool really ran AND the result has no `"error"` key.
- **L3.** `trace.log("tool_result", step=step, call_id=c.id, name=name, ok=executed and "error" not in result, executed=executed, result=result)`

## TODO 4 — trace assertions
- **L1.** `_calls(ev, "create_ticket")` returns the ticket call events. Every event has a number `e["i"]` that grows with time.
- **L2a.** Ticket call exists? Then the first `lookup_employee` call must have a smaller `i`.
- **L2b.** For each `tool_result` of `create_ticket` with `executed` True, find a `gate` with the same `call_id` and decision `approved`.
- **L3a.** `tick = _calls(ev,"create_ticket"); look = _calls(ev,"lookup_employee"); return (not tick) or (bool(look) and look[0]["i"] < tick[0]["i"]), "..."`
- **L3b.** `for r in results: if not any(g["type"]=="gate" and g["call_id"]==r["call_id"] and g["decision"]=="approved" for g in ev): return False, "..."` then `return True, "..."`

## TODO 5 — three conditions
- **L1.** P: no articles. S: all 10 articles. R: only the 2 best from Chroma.
- **L2.** The Day 1 helper `rag.build_messages(question, hits, kb)` takes `hits` as tuples whose first item is the article ID.
- **L3.** P: `[{"role":"system","content":PROMPT_ONLY},{"role":"user","content":question}]` · S: `rag.build_messages(question, [(i,) for i in kb], kb)` · R: `hits=[(x["id"],) for x in agent_tools.search_kb(question, k=2)["articles"]]`

## Common errors
| You see | Meaning | Fix |
|---|---|---|
| `400 ... messages with role 'tool' must be a response to a preceding message with 'tool_calls'` | TODO 1 missing or wrong | add the assistant message BEFORE the tool messages |
| `404 DeploymentNotFound` | chat or embedding deployment name | check `.env` |
| Every assertion fails on `ticket_needs_approval` | no `gate` event logged (TODO 2) or no `tool_result` (TODO 3) | check both |
| Agent stops with "max_steps" | it kept calling tools | read the trace: which tool, how many times? |
