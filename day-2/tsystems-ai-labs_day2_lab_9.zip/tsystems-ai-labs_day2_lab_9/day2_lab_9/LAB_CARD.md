# Lab 9 — Your IT Support Helper becomes an agent (70 minutes)

**Story.** In Lab 7/8 your helper answered a question once. Real requests have steps: find the article, look up the employee, open a ticket. Today the model chooses the tools, YOU decide which actions need a human, and every decision lands in a trace you can test.
Part B then answers a manager's question: *"Do we need RAG, a long prompt, or fine-tuning for this helper?"* — with evidence.

## Setup (5 min)
1. Copy this overlay into your repo root (adds `day2_lab_9/`, `data/employees.json`, `data/agent_scenarios.json`, `data/adapt_facts_b.json`, `lib/agent_tools.py`, `lib/agent_trace.py`, `lib/grounding.py`, `lib/embed_helpers.py`).
2. `pip install chromadb` (you did this in Lab 8) and keep the line `AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small` in `.env`.
3. `python setup/check_env_day2.py` must end with "READY".

## Part A — Build the agent with a human gate (min 5–45)
| Min | Step | File |
|---|---|---|
| 5–15 | **TODO 1** put the model's tool request into the conversation | `day2_lab_9/scripts/agent_lab.py` |
| 15–22 | **TODO 2** the human gate for gated tools | same file |
| 22–27 | **TODO 3** log the `tool_result` event | same file |
| 27–30 | Run: `python day2_lab_9/scripts/run_agent_lab.py "My VPN will not connect from home." --employee E101 --approve yes` and READ the trace |
| 30–32 | Run the ticket case yourself as the gate: `python day2_lab_9/scripts/run_agent_lab.py "I need Adobe Acrobat Pro. It is not in the Software Center." --approve ask` — type `y`, then run again and type `n` |
| 32–42 | **TODO 4** two trace assertions in `assert_lab.py`, then `python day2_lab_9/scripts/run_scenarios_lab.py --repeat 3` |
| 42–45 | Fill Part A of `results/RESULT_TABLE.md` |

## Part B — Prompt vs RAG vs fine-tune, with evidence (min 45–70)
| Min | Step |
|---|---|
| 45–50 | **TODO 5** `condition_messages` in `adapt_lab.py` (three ways to give the model company knowledge) |
| 50–55 | Run `python day2_lab_9/scripts/adapt_lab.py` (21 chat calls). Add `--price-in` / `--price-out` using YOUR price per 1M tokens from the Azure pricing page |
| 55–68 | Fill `DECISION_MEMO.md`: table, your choice, 5-sentence argument using at least 2 numbers, one "what would change my mind" trigger |
| 68–70 | Swap memos with your neighbour; find one claim not backed by a number |

## Done when
- [ ] t1 shows no ticket, t2 and t3 show a `GATE` event before the ticket, t4 says "not found" with no ticket
- [ ] `run_scenarios_lab.py --repeat 3` prints pass rates; every assertion row is filled in your table (a fail is data — write which scenario and why)
- [ ] You ran the deny case and the agent explained it could not open the ticket
- [ ] `DECISION_MEMO.md` has a choice, two numbers, and a trigger
- [ ] Nothing in your files or screen shows your API key

## Stretch
- Add a 4th assertion: "the ticket summary names the manager". Does it hold in 3 runs?
- Move `lookup_employee` into `GATED` too. What does that cost the employee? Is it a good gate?
- Run `run_scenarios_lab.py --approve no` and explain every number.

## Rules
Never print your key. Do not copy numbers from a neighbour or the slides: results vary per run and per deployment. Stuck? `hints/HINTS.md`, three levels per TODO.
