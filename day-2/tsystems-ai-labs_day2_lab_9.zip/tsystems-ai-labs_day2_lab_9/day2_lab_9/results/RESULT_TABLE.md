# Lab 9 — my results (fill in from YOUR runs)

## Part A — pass rate per assertion (`run_scenarios_lab.py --repeat 3`)
| Scenario | search_first | lookup_before_ticket | ticket_needs_approval | ticket_matches | steps_ok | ended_cleanly | answer_grounded |
|---|---|---|---|---|---|---|---|
| t1 VPN | /3 | /3 | /3 | /3 | /3 | /3 | /3 |
| t2 software | /3 | /3 | /3 | /3 | /3 | /3 | /3 |
| t3 folder | /3 | /3 | /3 | /3 | /3 | /3 | /3 |
| t4 VPN-7 | /3 | /3 | /3 | /3 | /3 | /3 | /3 |

Deny run (`--approve no --only t2`): ticket created? ____  What did the agent tell the employee? ______________
One assertion that failed and WHY (read the trace): ______________________________

## Part B — evidence (`adapt_lab.py`)
| Condition | has the fact (of 6) | cites right (of 6) | VPN-7 -> not found? | avg input tokens | cost per 1,000 q |
|---|---|---|---|---|---|
| prompt only | | | | | |
| stuff all 10 articles | | | | | |
| RAG (Chroma, k=2) | | | | | |
