# Day 2 — Lab 9 overlay (tool-calling agent, human gate, traces, adaptation decision)
Copy the contents of this folder into the root of your Day 1 repo (`tsystems-ai-labs`). Adds `day2_lab_9/`, `data/employees.json`, `data/agent_scenarios.json`, `data/adapt_facts_b.json`, `lib/agent_tools.py`, `lib/agent_trace.py`, `lib/grounding.py`, `lib/embed_helpers.py`, `setup/check_env_day2.py`.
Needs: `pip install chromadb`, and `AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small` in your own `.env` (never commit it). Then open `day2_lab_9/LAB_CARD.md`.
Requires your Day 1 `lib/common.py`, `kb/`, `data/lab4_questions.json`.
