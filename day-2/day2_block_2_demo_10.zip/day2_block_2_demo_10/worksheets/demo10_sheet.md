# Demo 10 sheet (fill live from the printed output)
Step 1: tools called, in order: ______________   ticket? ____
Step 2: gate shown before the ticket? ____   ticket id: ______
Step 3: after DENY, what did the agent say? ______________
Step 4 pass rates (of 3 runs):  search_first __  lookup_before_ticket __  ticket_needs_approval __  ticket_matches __  steps_ok __  ended_cleanly __  answer_grounded __
        Which assertion failed, in which scenario, and what did the trace show? ______________
Step 5: has the fact P __/6  S __/6  R __/6 | cites right S __/6  R __/6 | VPN-7 not found P __ S __ R __ | avg input tokens P __ S __ R __
Caution: 6 questions; one = about 17 points.
