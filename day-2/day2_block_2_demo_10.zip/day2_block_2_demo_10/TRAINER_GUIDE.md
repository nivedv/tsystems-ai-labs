# Trainer guide — Demo 10 (Day 2 · Block 2 · 25 min)

**Place in the day.** After the concept slides on tool-calling, orchestration, human-in-the-loop and trace assertions. Before Lab 9. Verbatim speech is in the deck's speaker notes.

## 1. Why this demo and why this data
| Choice | Reason |
|---|---|
| Same IT Support Helper and 10 articles | Learners recognise the data; only the new idea (tools + gate + trace) is new |
| `search_kb` is the Day 2 Chroma RAG | RAG becomes ONE tool among others — the bridge from the morning |
| Ticket is the only gated tool | It is the only action with a side effect that is hard to undo. KB-007 and KB-009 really say "raise a request with manager approval" |
| Control flow in Python | `max_steps`, `GATED`, tool errors are code, not prompt hopes |
| Assertions on the PATH, not the words | Non-deterministic agents: we cannot assert wording, we can assert order, approvals, step budget and honest citations |
| `adapt_eval.py` on Day 1 questions | The adaptation decision uses numbers learners already know |

## 2. What is deterministic and what is not
| Item | Status |
|---|---|
| Tool list, schemas, `GATED = {create_ticket}`, employees, scenarios, assertion logic | deterministic (offline-tested with a scripted fake model) |
| What the real model chooses, wording, token counts, fact hits, pass rates | **NOT yet measured on Azure — rehearse and write the real values on the sheet** |
| Chat deployment supports tool calling | must be true; `check_env.py` tests it |
Never quote numbers you have not seen on your own screen. Run each step twice in rehearsal: if the model behaves differently, that is your teaching material (non-determinism).

## 3. Before class (45 min the day before)
- [ ] `pip install -r requirements.txt`; `.env` has the 5 values; `python scripts/check_env.py` says READY
- [ ] Run steps 1–5 once. The first agent run builds Chroma (1 embedding call, then cached in `outputs/agent_chroma`)
- [ ] `python scripts/run_scenarios.py --repeat 3` — note any failing assertion and open that trace. A real failure is a better demo than a clean table; keep it
- [ ] Decide your price per 1M tokens (input and output) from the Azure pricing page for the deployed model. Do NOT guess; if unsure, run without prices and say so
- [ ] Editor tabs: `agent.py` (the loop), `agent_tools.py` (`GATED`), `assert_trace.py`, an example trace file
- [ ] Delete `outputs/tickets.json` before class so ticket IDs start at INC-1001

## 4. Run sheet (25 min)
| Min | Step | Command | Say / point at |
|---|---|---|---|
| 0–2 | frame | (slide) | "Same helper. Today it can act. Three tools, one gate, one trace." |
| 2–6 | 1 | step 1 command | Read the trace top to bottom like a story: MODEL asks for `search_kb` → RESULT → MODEL answers. "No ticket, because the article answers it." Open `agent.py`: the loop is 25 lines |
| 6–12 | 2 | step 2 command, type `y` | Narrate: search → KB-007 says approval needed → lookup (manager) → the loop STOPS at the gate and asks YOU. Show the printed args. Then `type outputs\tickets.json` |
| 12–15 | 3 | step 2 command, type `n` | GATE → DENIED, `executed=False`, the model got an error text and explained. "A denied action is an input to the agent, not a crash" |
| 15–20 | 4 | step 4 command | Read the pass-rate table. "Not one run — a rate." Show one assertion in `assert_trace.py` (`a_ticket_needs_approval`). If something fails: open that trace together |
| 20–25 | 5 | step 5 command | Read the three rows. Ask the room to choose before you reveal your reading. State what the numbers do NOT prove (6 questions). Fine-tune: not run — say why (needs labelled pairs, a training job, retraining on change). Hand over to Lab 9 |

## 5. Teaching points to hit
1. The model proposes, your code disposes: `dispatch` and `approve` are your code.
2. Gate where an action is irreversible, costly, leaks data, or speaks for the company. Reads run free.
3. A trace without assertions is a diary. Assertions on a trace are a test.
4. Wrong tool for the job: password lockout has a self-service portal (KB-004). A plain link may beat an agent — raise this in the debrief.

## 6. If it fails
| Symptom | Fix |
|---|---|
| `400 ... tools` / "tool_calls" error | check API version in `.env`; the deployment must support tool calling |
| `404 DeploymentNotFound` | chat vs embedding deployment name mixed up |
| Agent never calls a tool | rerun once; if persistent, show the trace and tighten `SYSTEM` live (a good lesson) |
| Agent loops until `STOP max_steps` | show it: that is why the budget exists |
| Chroma error after changing `kb/` | delete `outputs/agent_chroma` |
| 429 | wait 30 s |
| No network | show saved traces in `outputs/traces/` and read them |

## 7. Honest limits to say out loud
Four scenarios, three runs each: a pass rate of 3/3 is not proof. Assertions check the path, not whether the advice is correct. The approval prompt here is a terminal `input()`; a real system needs an audit log, identity, timeouts and a queue.
