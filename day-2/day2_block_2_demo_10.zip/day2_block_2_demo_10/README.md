# Day 2 · Block 2 · Demo 10 — The IT Support Helper becomes an agent (trainer demo, 25 min)

Same helper, same 10 KB articles. Now the MODEL chooses tools (`search_kb` = Day 2 RAG with Chroma, `lookup_employee`, `create_ticket`), a HUMAN gates the one action with a side effect, and every decision is written to a trace that we test with assertions. The last step compares prompt vs stuffing vs RAG with evidence.

## Setup
```
pip install -r requirements.txt
copy .env.example .env        # 4 Day 1 values + AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small
python scripts/check_env.py   # embedding call + a chat call WITH tools must both work
```
## Steps
| # | Command | Shows |
|---|---|---|
| 1 | `python scripts/run_agent.py "My VPN will not connect from home." --employee E101 --approve yes` | search → answer with citation, no ticket. Read the trace |
| 2 | `python scripts/run_agent.py "I need Adobe Acrobat Pro. It is not in the Software Center." --approve ask` | search → lookup → **GATE** → ticket. You type `y` |
| 3 | same command, type `n` | gate DENIED, no ticket, the agent explains |
| 4 | `python scripts/run_scenarios.py --repeat 3` | 4 scenarios × 3 runs, 7 trace assertions, pass RATES |
| 5 | `python scripts/adapt_eval.py` (add `--price-in X --price-out Y`, your price per 1M tokens) | prompt vs stuff vs RAG on the 6 Day 1 questions + VPN-7 |

Files: `scripts/agent.py` (the loop), `agent_tools.py` (tools, schemas, `GATED`), `agent_trace.py`, `assert_trace.py`, `run_agent.py`, `run_scenarios.py`, `adapt_eval.py`, `rag.py` (Day 1 grounded prompt), `data/` (employees, scenarios, facts), `kb/` (Day 1 articles), `worksheets/`.
Outputs (gitignored): `outputs/traces/*.jsonl`, `outputs/tickets.json`, `outputs/agent_chroma/`.
