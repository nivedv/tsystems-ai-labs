"""The agent loop: model -> tool call -> (human gate) -> tool result -> model ... until it answers.
Control flow lives HERE, in plain Python, not in the prompt. Every decision goes to the trace."""
import json

import agent_tools
import common
from agent_tools import GATED, TOOLS, dispatch

SYSTEM = (
    "You are the IT Support Helper for employees. "
    "ALWAYS call search_kb first. Answer ONLY from the articles and cite IDs like [KB-004]. "
    "If the articles do not cover the question, reply: not found. Do not open a ticket for it. "
    "If an article says a request, form or manager approval is needed, call lookup_employee, then create_ticket. "
    "Never open a ticket for a question the articles already answer. "
    "Signed-in employee ID: {employee_id}."
)


def run_agent(user_text, employee_id, approve, trace, max_steps=6, client=None, deployment=None):
    """approve(name, args) -> True/False is the human gate. Returns the final answer (or None if it ran out of steps)."""
    if client is None:
        client, deployment = common.get_client()
    messages = [{"role": "system", "content": SYSTEM.format(employee_id=employee_id)},
                {"role": "user", "content": user_text}]
    trace.log("run_start", scenario=trace.scenario, employee=employee_id, question=user_text, max_steps=max_steps)
    for step in range(1, max_steps + 1):
        resp, _secs = common.call_model(client, deployment, messages, tools=TOOLS)
        msg = resp.choices[0].message
        calls = msg.tool_calls or []
        trace.log("model_call", step=step, prompt_tokens=resp.usage.prompt_tokens,
                  completion_tokens=resp.usage.completion_tokens, tool_calls=[c.function.name for c in calls])
        if not calls:
            trace.log("final", step=step, text=msg.content or "")
            return msg.content
        # ---TODO 1 START---
        messages.append({"role": "assistant", "content": msg.content, "tool_calls": [
            {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}} for c in calls]})
        # ---TODO 1 END---
        for c in calls:
            name = c.function.name
            args = json.loads(c.function.arguments or "{}")
            trace.log("tool_call", step=step, call_id=c.id, name=name, args=args)
            executed = True
            # ---TODO 2 START---
            if name in GATED:
                approved = approve(name, args)
                trace.log("gate", step=step, call_id=c.id, name=name, decision="approved" if approved else "denied")
                if not approved:
                    executed = False
                    result = {"error": "A human reviewer denied this action. Do not retry. Tell the employee what happens next."}
                else:
                    result = dispatch(name, args)
            else:
                result = dispatch(name, args)
            # ---TODO 2 END---
            # ---TODO 3 START---
            shown = result
            if name == "search_kb" and "articles" in result:
                shown = {"articles": [{"id": a["id"], "score": a["score"], "text": a["text"][:70]} for a in result["articles"]]}
            trace.log("tool_result", step=step, call_id=c.id, name=name, ok=executed and "error" not in result, executed=executed, result=shown)
            # ---TODO 3 END---
            messages.append({"role": "tool", "tool_call_id": c.id, "content": json.dumps(result)})
    trace.log("stop", reason="max_steps")
    return None
