"""Run the IT Support Helper agent once and print its trace.

  python scripts/run_agent.py "My VPN will not connect from home." --employee E101
  python scripts/run_agent.py "I need Adobe Acrobat Pro. It is not in the Software Center." --approve ask
--approve ask  : YOU are the human gate (type y or n)     yes : approve automatically     no : deny automatically
"""
import argparse
import datetime

import agent
import common
import agent_trace as tr


def make_approver(mode):
    def approve(name, args):
        if mode == "yes":
            return True
        if mode == "no":
            return False
        print(f"\n  >>> HUMAN GATE: the agent wants to run {name}")
        for k, v in args.items():
            print(f"        {k}: {v}")
        return input("  Approve? (y/n): ").strip().lower().startswith("y")
    return approve


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("question")
    ap.add_argument("--employee", default="E101")
    ap.add_argument("--approve", choices=["ask", "yes", "no"], default="ask")
    ap.add_argument("--max-steps", type=int, default=6)
    a = ap.parse_args()
    path = common.ROOT / "outputs" / "traces" / f"run_{datetime.datetime.now():%H%M%S}.jsonl"
    t = tr.Trace(path, scenario="manual")
    try:
        answer = agent.run_agent(a.question, a.employee, make_approver(a.approve), t, max_steps=a.max_steps)
    except Exception as e:
        common.explain_error(e)
        raise SystemExit(1)
    print("\nTRACE (every decision, in order)")
    tr.show(t.events)
    print(f"\nANSWER: {answer}")
    print(f"\n(trace file: {path.relative_to(common.ROOT)})")
