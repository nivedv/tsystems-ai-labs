"""Tiny keyword search over the 10 synthetic articles.

Score = how many DIFFERENT question words appear in the article (title + text).
Deterministic: same question -> same scores -> same order. Ties are broken by article ID.
This is the 'retrieval step' you debug first when RAG goes wrong.
"""
import pathlib
import random
import re

STOP = set("""a an the is are was were be been am i we you my our your it its this that to of in on at for from with
and or not do does did can could should would how what why when who which me us there their they them if as by so
please very more most some any about after before again""".split())


def load_kb(kb_dir, exclude=()):
    kb = {}
    for p in sorted(pathlib.Path(kb_dir).glob("KB-*.txt")):
        text = p.read_text(encoding="utf-8")
        art_id = p.stem
        if art_id in exclude:
            continue
        title = re.search(r"Title:\s*(.*)", text).group(1).strip()
        body = re.search(r"Text:\s*(.*)", text, re.S).group(1).strip()
        kb[art_id] = f"{title}. {body}"
    return kb


def words(s):
    out = []
    for w in re.findall(r"[a-z0-9]+", s.lower()):
        if w in STOP or len(w) < 2:
            continue
        if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.append(w)
    return out


def score_all(question, kb):
    q = set(words(question))
    rows = []
    for art_id, text in kb.items():
        hit = q & set(words(text))
        rows.append((art_id, len(hit), sorted(hit)))
    rows.sort(key=lambda r: (-r[1], r[0]))
    return rows


def search(question, kb, k=2, min_score=0, mode="keyword", seed=7):
    """Return the top-k (id, score, matched_words). mode='random' is Break C."""
    if mode == "random":
        rnd = random.Random(seed + sum(map(ord, question)))
        ids = sorted(kb)
        rnd.shuffle(ids)
        return [(i, 0, []) for i in ids[:k]]
    rows = [r for r in score_all(question, kb) if r[1] >= min_score]
    return rows[:k]
