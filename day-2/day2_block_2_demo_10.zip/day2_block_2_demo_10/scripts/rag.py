"""The pieces of the tiny RAG: prompt assembly, model call, citation check."""
import re

import common

# Exact rule from the slide (Demo 5, step 4):
GROUND_SYSTEM = (
    "Answer ONLY from the articles. "
    "Cite IDs like [KB-004]. "
    "If missing, reply: not found."
)


def build_context(hits, kb):
    return "\n".join(f"[{h[0]}] {kb[h[0]]}" for h in hits)


def build_messages(question, hits, kb):
    user = build_context(hits, kb) + "\n\nQuestion: " + question
    return [
        {"role": "system", "content": GROUND_SYSTEM},
        {"role": "user", "content": user},
    ]


def cited(answer):
    return re.findall(r"\[(KB-\d+)\]", answer)


def check(answer, retrieved_ids):
    """Demo 6 citation check. Same logic as the slide."""
    c = cited(answer)
    if "not found" in answer.lower():
        return "pass_not_found"
    if not c:
        return "fail_no_citation"
    if any(x not in retrieved_ids for x in c):
        return "fail_fake_citation"
    return "pass"


def ask(client, deployment, question, hits, kb):
    msgs = build_messages(question, hits, kb)
    resp, secs = common.call_model(client, deployment, msgs)
    return resp.choices[0].message.content or "", resp.usage.total_tokens, resp.choices[0].finish_reason
