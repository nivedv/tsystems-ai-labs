"""The three tools of the IT Support Helper agent.

search_kb        : Day 2 RAG as a TOOL (embeddings + local Chroma). Safe: reads only.
lookup_employee  : reads the employee record. Safe: reads only.
create_ticket    : WRITES a ticket. This is the action with a side effect, so a human must approve it (the gate).
"""
import json

import common

OUT = common.ROOT / "outputs"
GATED = {"create_ticket"}

TOOLS = [
    {"type": "function", "function": {
        "name": "search_kb",
        "description": "Search the IT knowledge base by meaning. Returns the 2 best articles with their IDs.",
        "parameters": {"type": "object", "properties": {"query": {"type": "string", "description": "the employee's problem in plain words"}}, "required": ["query"]}}},
    {"type": "function", "function": {
        "name": "lookup_employee",
        "description": "Get name, department and manager of an employee by employee ID.",
        "parameters": {"type": "object", "properties": {"employee_id": {"type": "string"}}, "required": ["employee_id"]}}},
    {"type": "function", "function": {
        "name": "create_ticket",
        "description": "Open a service desk ticket. Only when the knowledge base says a request or approval is needed. A human must approve it.",
        "parameters": {"type": "object", "properties": {
            "employee_id": {"type": "string"},
            "category": {"type": "string", "enum": ["software_request", "access_request", "other"]},
            "summary": {"type": "string", "description": "one or two sentences: what is needed and who approves"}},
            "required": ["employee_id", "category", "summary"]}}},
]


def _embed(texts):
    import embed_helpers
    client, deployment = embed_helpers.get_embed_client()
    resp = client.embeddings.create(model=deployment, input=list(texts))
    return [d.embedding for d in sorted(resp.data, key=lambda d: d.index)]


def _load_kb():
    import re
    kb = {}
    for p in sorted((common.ROOT / "kb").glob("KB-*.txt")):
        raw = p.read_text(encoding="utf-8")
        title = re.search(r"Title:\s*(.*)", raw).group(1).strip()
        body = re.search(r"Text:\s*(.*)", raw, re.S).group(1).strip()
        kb[p.stem] = f"{title}. {body}"
    return kb


_COL = None


def _collection():
    """Build the local Chroma collection once (1 embedding call), then reuse it."""
    global _COL
    if _COL is None:
        import chromadb
        kb = _load_kb()
        db = chromadb.PersistentClient(path=str(OUT / "agent_chroma"))
        col = db.get_or_create_collection("agent_kb", metadata={"hnsw:space": "cosine"})
        if col.count() != len(kb):
            db.delete_collection("agent_kb")
            col = db.create_collection("agent_kb", metadata={"hnsw:space": "cosine"})
            ids = list(kb)
            col.add(ids=ids, documents=[kb[i] for i in ids], embeddings=_embed([kb[i] for i in ids]))
        _COL = col
    return _COL


def search_kb(query, k=2):
    col = _collection()
    res = col.query(query_embeddings=_embed([query]), n_results=k)
    return {"articles": [{"id": i, "score": round(1 - d, 3), "text": t}
                         for i, d, t in zip(res["ids"][0], res["distances"][0], res["documents"][0])]}


def lookup_employee(employee_id):
    emp = json.loads((common.ROOT / "data" / "employees.json").read_text(encoding="utf-8"))["employees"].get(employee_id)
    return {"employee_id": employee_id, **emp} if emp else {"error": f"unknown employee {employee_id}"}


def create_ticket(employee_id, category, summary):
    OUT.mkdir(exist_ok=True)
    path = OUT / "tickets.json"
    tickets = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    t = {"ticket_id": f"INC-{1001 + len(tickets)}", "employee_id": employee_id, "category": category, "summary": summary, "status": "open"}
    tickets.append(t)
    path.write_text(json.dumps(tickets, indent=2), encoding="utf-8")
    return {"ticket_id": t["ticket_id"], "status": "open"}


FUNCS = {"search_kb": search_kb, "lookup_employee": lookup_employee, "create_ticket": create_ticket}


def dispatch(name, args):
    """Run one tool. Never raises: a bad call comes back as an error the model can read."""
    if name not in FUNCS:
        return {"error": f"unknown tool {name}"}
    try:
        return FUNCS[name](**args)
    except TypeError as e:
        return {"error": f"bad arguments: {e}"}
