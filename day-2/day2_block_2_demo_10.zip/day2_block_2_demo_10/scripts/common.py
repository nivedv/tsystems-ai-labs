"""Shared helpers. Reads settings from environment variables (or a local .env file).
The API key is never printed by any script in this package."""
import os
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
REQUIRED = [
    "AZURE_OPENAI_ENDPOINT",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_API_VERSION",
    "AZURE_OPENAI_DEPLOYMENT",
]


def load_env():
    p = ROOT / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def missing_settings():
    load_env()
    return [k for k in REQUIRED if not os.environ.get(k)]


def get_client():
    miss = missing_settings()
    if miss:
        print("Missing settings:", ", ".join(miss))
        print("Run:  python scripts/check_env.py   (and see .env.example)")
        sys.exit(2)
    from openai import AzureOpenAI

    client = AzureOpenAI(
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    )
    return client, os.environ["AZURE_OPENAI_DEPLOYMENT"]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8").strip()


HINTS = {
    "AuthenticationError": "401: the key is wrong, expired, or not loaded in THIS terminal.",
    "PermissionDeniedError": "403: key is valid but not allowed (network rule, or wrong resource).",
    "NotFoundError": "404: usually the DEPLOYMENT name is wrong (it is your deployment name, not the model name).",
    "RateLimitError": "429: too many requests. Wait 20-30 seconds and run once more.",
    "APIConnectionError": "Network problem: VPN, proxy, or the endpoint URL is mistyped.",
    "BadRequestError": "400: check the API version, or a parameter your model does not accept.",
    "APITimeoutError": "Timeout: try again; check the network.",
}


def explain_error(e):
    name = type(e).__name__
    print(f"\nCALL FAILED: {name}")
    print(str(e)[:400])
    print("Hint:", HINTS.get(name, "Read the message above aloud, then check endpoint, key, deployment, API version."))


def call_model(client, deployment, messages, **extra):
    t0 = time.time()
    resp = client.chat.completions.create(model=deployment, messages=messages, **extra)
    return resp, time.time() - t0


def show_result(resp, seconds):
    ch = resp.choices[0]
    print("\n--- REPLY " + "-" * 50)
    print(ch.message.content)
    print("-" * 60)
    print("finish_reason     :", ch.finish_reason)
    u = resp.usage
    print("prompt_tokens     :", u.prompt_tokens)
    print("completion_tokens :", u.completion_tokens)
    print("total_tokens      :", u.total_tokens)
    print(f"time taken        : {seconds:.1f} s")


def save_output(name, text):
    out = ROOT / "outputs"
    out.mkdir(exist_ok=True)
    path = out / name
    path.write_text(text, encoding="utf-8")
    print(f"(saved to outputs/{name})")


# ---------------- Day 2 additions: embeddings ----------------
def get_embed_client():
    """Same client as the chat model, but returns the EMBEDDING deployment name.
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT defaults to 'text-embedding-3-small' if you did not set it."""
    client, _chat_deployment = get_client()
    return client, os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
