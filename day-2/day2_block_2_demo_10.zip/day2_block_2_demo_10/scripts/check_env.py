"""Run FIRST. Settings + one tiny chat call + one tiny embedding call. Never prints the key."""
import os

import common

common.load_env()
ok = True
for k in common.REQUIRED + ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"]:
    v = os.environ.get(k)
    if not v and k == "AZURE_OPENAI_EMBEDDING_DEPLOYMENT":
        print(f"[ note  ] {k} not set -> default text-embedding-3-small")
    elif not v:
        print(f"[MISSING] {k}")
        ok = False
    else:
        print(f"[ set   ] {k}" + ("  (value hidden)" if "KEY" in k else f" = {v}"))
for pkg in ("openai", "chromadb"):
    try:
        __import__(pkg)
        print(f"[ ok    ] {pkg}")
    except ImportError:
        print(f"[MISSING] {pkg} -> pip install -r requirements.txt")
        ok = False
if ok:
    try:
        import embed_helpers
        client, dep = embed_helpers.get_embed_client()
        n = len(client.embeddings.create(model=dep, input=["test"]).data[0].embedding)
        print(f"[ ok    ] embedding call worked (vector length {n})")
        _c, chat = common.get_client()
        r = client.chat.completions.create(model=chat, messages=[{"role": "user", "content": "Say OK"}], tools=[{"type": "function", "function": {"name": "noop", "description": "x", "parameters": {"type": "object", "properties": {}}}}])
        print("[ ok    ] chat call with tools worked")
    except SystemExit:
        ok = False
    except Exception as e:
        common.explain_error(e)
        ok = False
print("\nREADY for the agent demo." if ok else "\nFix the items above, then run again.")
