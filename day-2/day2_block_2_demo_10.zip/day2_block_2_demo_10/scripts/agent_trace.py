"""Every decision the agent makes becomes ONE line of JSON. That file is the trace.
Event types: run_start, model_call, tool_call, gate, tool_result, final, stop."""
import json
import time


class Trace:
    def __init__(self, path=None, scenario=None):
        self.events = []
        self.path = path
        self.scenario = scenario
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("", encoding="utf-8")

    def log(self, type, **data):
        ev = {"i": len(self.events) + 1, "t": round(time.time(), 2), "type": type, **data}
        self.events.append(ev)
        if self.path:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(ev) + "\n")
        return ev


def load(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def show(events):
    """Human-readable view of a trace."""
    for e in events:
        t = e["type"]
        if t == "model_call":
            print(f"  {e['i']:>2}  step {e['step']}  MODEL   tokens {e['prompt_tokens']}+{e['completion_tokens']}  wants: {e['tool_calls'] or 'to answer'}")
        elif t == "tool_call":
            print(f"  {e['i']:>2}  step {e['step']}  CALL    {e['name']}({json.dumps(e['args'])[:90]})")
        elif t == "gate":
            print(f"  {e['i']:>2}  step {e['step']}  GATE    {e['name']} -> {e['decision'].upper()}")
        elif t == "tool_result":
            print(f"  {e['i']:>2}  step {e['step']}  RESULT  {e['name']} ok={e['ok']}  {json.dumps(e['result'])[:90]}")
        elif t == "final":
            print(f"  {e['i']:>2}  step {e['step']}  FINAL   {e['text'][:110]}")
        elif t == "stop":
            print(f"  {e['i']:>2}  STOP    {e['reason']}")
