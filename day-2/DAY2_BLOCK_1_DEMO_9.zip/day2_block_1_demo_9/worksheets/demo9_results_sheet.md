# Demo 9 results sheet (fill live from the printed output)
| Metric (6 questions) | Keyword (Day 1) | Chroma + embeddings |
|---|---|---|
| recall@1 | | |
| recall@2 | | |
| recall@3 | | |

Vector shape: ____ articles x ____ numbers.   Best cosine for VPN-7: ______   Lowest best-cosine of the 6 real questions: ______
Min-score I would try: ______   (6 questions: one question = about 17 points)
