# Day 2 · Demo 9 — Embeddings + local Chroma (trainer demo, 20 min)

Continues Day 1: same IT Support Helper, same 10 KB articles, same questions, same grounded prompt and citation check. Only the search step changes: articles become embeddings (`text-embedding-3-small`) stored in a **local Chroma** database.

## Setup
```
pip install -r requirements.txt
copy .env.example .env     # 4 Day 1 values + AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-small
python scripts/check_env.py
```
## Steps
| # | Command | Shows |
|---|---|---|
| 1 | `python scripts/build_store.py` | 10 articles → 10 vectors of 1,536 numbers → saved in Chroma (`outputs/chroma`) |
| 2 | `python scripts/compare_search.py` | keyword vs Chroma on the same questions |
| 3 | `python scripts/metrics_chroma.py` | recall@1/2/3 both ways + VPN-7 threshold evidence |
| 4 | `python scripts/run_rag_chroma.py --questions q2,q4 --k 2` | grounded answer with citations |
| 5 | `python scripts/run_rag_chroma.py --probe --min-score <from step 3>` | VPN-7: "not found" |

No-chat options: `run_rag_chroma.py --retrieval-only`, `--dry-run`. `build_store.py --reset` rebuilds the database.
Files: `scripts/embed.py` (text→numbers), `scripts/store.py` (Chroma), `kb/` (Day 1 articles), `data/questions.json` (Day 1), `worksheets/`.
