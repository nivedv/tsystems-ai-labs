# Trainer guide — Demo 9 (Day 2, 20 min)

## Why
Day 1 left a measured keyword baseline. Demo 9 changes ONE thing — how articles are found — and re-measures with the same questions and metric. Chroma is the store: local folder, no server.

## Deterministic vs not
| Item | Status |
|---|---|
| Keyword recall (set A): 0.67 / 0.83 / 1.00 | deterministic, from Day 1 |
| Vector shape 10 × 1,536 | deterministic (default size) |
| Chroma recall, cosine values, VPN-7 score | **not yet measured on Azure — rehearse and fill the sheet** |
Never quote offline test numbers; they were from a fake embedder.

## Before class
- [ ] `pip install -r requirements.txt` (adds chromadb); `.env` has the 5th line; `check_env.py` passes
- [ ] Rehearse steps 1–5; write real numbers on the sheet; pick the min-score from step 3 evidence (or say there is no gap)
- [ ] Run step 1 once so `outputs/chroma` exists (class run is then instant)

## Run sheet
| Min | Do | Say (gist) |
|---|---|---|
| 0–5 | step 1 | "Each article becomes 1,536 numbers. Chroma keeps text, numbers and id together, in a folder on this laptop." Show first 5 numbers |
| 5–10 | step 2 | Pick the question keyword missed; ask the class to predict first |
| 10–14 | step 3 | Read both recall rows. Then threshold lines: "a number, not a feeling" |
| 14–18 | step 4 | Answer + citation check — prompt unchanged from Day 1 |
| 18–20 | step 5 | VPN-7 → "not found". Hand over to Lab 8 |

## Failures
| Symptom | Fix |
|---|---|
| 404 DeploymentNotFound | `AZURE_OPENAI_EMBEDDING_DEPLOYMENT` must equal the Azure deployment name |
| `No module named chromadb` | `pip install chromadb` |
| Chroma errors after changing articles | `build_store.py --reset` |
| 429 | wait 30 s; vectors are cached in Chroma |
| Retrieval empty | min-score too high |

## Honest limits
10 articles is tiny — Chroma is not needed at this size, it is shown because it is what you use when the KB grows. Six questions → one question = 17 points. Embedding search can rank a wrong article confidently; grounding and "not found" still matter.
