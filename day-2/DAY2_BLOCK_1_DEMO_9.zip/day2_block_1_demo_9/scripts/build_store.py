"""Demo 9, step 1: put the 10 Day 1 articles into a local Chroma database.

  python scripts/build_store.py
  python scripts/build_store.py --reset      # delete the database and rebuild
"""
import shutil
import sys

import common
import search
import store

if "--reset" in sys.argv:
    shutil.rmtree(store.PATH, ignore_errors=True)
kb = search.load_kb(common.ROOT / "kb")
try:
    col = store.build_store(kb)
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)
one = col.get(ids=["KB-001"], include=["embeddings", "documents"])
print(f"\nChroma collection '{store.NAME}' stored in {store.PATH.relative_to(common.ROOT)}")
print(f"articles stored : {col.count()}")
print(f"numbers per article (vector length): {len(one['embeddings'][0])}")
print(f"first 5 numbers of KB-001: {[round(float(x), 4) for x in one['embeddings'][0][:5]]}")
print(f"text kept next to it: {one['documents'][0][:70]}...")
