"""Demo 9, step 3: recall@k, keyword vs Chroma. Same questions, same answer key, same metric as Demo 8.
No chat model is used.

  python scripts/metrics_chroma.py
"""
import json

import common
import embed
import search
import store

kb = search.load_kb(common.ROOT / "kb")
qdata = json.loads(common.read("data/questions.json"))
questions = qdata["questions"]
vpn7 = next(p for p in qdata["probes"] if p["id"] == "p_vpn7")
try:
    col = store.build_store(kb)
    vecs = embed.embed_texts([q["text"] for q in questions] + [vpn7["text"]])
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)
qvecs, pvec = vecs[:-1], vecs[-1]

rank_kw, rank_ch, best = {}, {}, {}
for q, qv in zip(questions, qvecs):
    rank_kw[q["id"]] = [r[0] for r in search.score_all(q["text"], kb)]
    res = store.query(col, qv, k=len(kb))
    rank_ch[q["id"]] = [r[0] for r in res]
    best[q["id"]] = res[0][1]


def recall(ranks, k):
    return sum(1 for q in questions if q["key"] in ranks[q["id"]][:k])


print(f"\n{'':<12}{'recall@1':<12}{'recall@2':<12}{'recall@3':<12}")
for name, ranks in (("keyword", rank_kw), ("chroma", rank_ch)):
    print(f"{name:<12}" + "".join(f"{recall(ranks, k)}/{len(questions)} = {recall(ranks, k) / len(questions):.2f}   " for k in (1, 2, 3)))
print(f"\n{'q':<5}{'key':<9}{'keyword rank':<15}{'chroma rank':<14}{'best cosine'}")
for q in questions:
    print(f"{q['id']:<5}{q['key']:<9}{rank_kw[q['id']].index(q['key']) + 1!s:<15}{rank_ch[q['id']].index(q['key']) + 1!s:<14}{best[q['id']]:.3f}")
p = store.query(col, pvec, k=1)[0]
lo = min(best.values())
print(f"\nTHRESHOLD EVIDENCE\n  lowest best-score among the answerable questions: {lo:.3f}\n  best-score for VPN-7 (no article exists)        : {p[1]:.3f} ({p[0]})")
print("  A minimum score between those two numbers would help." if lo > p[1] else "  No clean gap: the strict prompt rule must carry VPN-7.")
print(f"Caution: {len(questions)} questions; one question = about {round(100 / len(questions))} points.")
