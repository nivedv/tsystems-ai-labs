"""Demo 9, step 2: keyword search (Day 1) and Chroma search side by side.

  python scripts/compare_search.py                                  # 4 prepared questions
  python scripts/compare_search.py "I cannot sign in to my account" # your own question
"""
import json
import sys

import common
import embed
import search
import store

kb = search.load_kb(common.ROOT / "kb")
qdata = json.loads(common.read("data/questions.json"))
byid = {q["id"]: q for q in qdata["questions"]}
if len(sys.argv) > 1:
    items = [(" ".join(sys.argv[1:]), None)]
else:
    items = [(byid["q2"]["text"], byid["q2"]["key"]), (byid["q4"]["text"], byid["q4"]["key"]),
             ("I cannot sign in to my account.", "KB-004"), ("What is our VPN-7 remote access policy?", None)]
try:
    col = store.build_store(kb)
    qvecs = embed.embed_texts([t for t, _ in items])
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)

for (text, key), qv in zip(items, qvecs):
    kw = search.score_all(text, kb)[:3]
    em = store.query(col, qv, k=3)
    print("=" * 74)
    print(f"Q: {text}" + (f"      (right article: {key})" if key else "      (no right article)"))
    print(f"{'KEYWORD (Day 1)':<30}{'CHROMA (today)':<30}")
    for a, b in zip(kw, em):
        print(f"{a[0]:<8}{str(a[1]) + ' words':<22}{b[0]:<8}{b[1]:.3f}")
    if key:
        print(f"-> keyword first: {kw[0][0]} {'OK' if kw[0][0] == key else 'MISS'}    chroma first: {em[0][0]} {'OK' if em[0][0] == key else 'MISS'}")
    else:
        print(f"-> nothing is right here. Best Chroma score: {em[0][1]:.3f}. Is it lower than for a real match?")
