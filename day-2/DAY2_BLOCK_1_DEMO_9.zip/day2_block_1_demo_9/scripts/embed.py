"""Step 1: text -> numbers. One API call embeds a whole list of texts with the deployed text-embedding-3-small."""
import common


def embed_texts(texts):
    client, deployment = common.get_embed_client()
    resp = client.embeddings.create(model=deployment, input=list(texts))
    return [d.embedding for d in sorted(resp.data, key=lambda d: d.index)]
