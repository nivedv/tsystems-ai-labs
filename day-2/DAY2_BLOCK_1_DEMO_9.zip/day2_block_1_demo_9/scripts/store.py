"""Step 2 and 3: the vector store. Chroma runs locally, inside this folder (outputs/chroma). No server, no cloud.

build_store : embeds the articles (only new or changed ones) and puts them into the Chroma collection "it_kb"
query       : the same job as search.search() on Day 1, but Chroma finds the nearest articles by MEANING
Chroma returns a distance; for cosine, similarity = 1 - distance.
"""
import hashlib

import chromadb

import common
import embed

PATH = common.ROOT / "outputs" / "chroma"
NAME = "it_kb"


def _h(text):
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def get_collection():
    client = chromadb.PersistentClient(path=str(PATH))
    return client.get_or_create_collection(NAME, metadata={"hnsw:space": "cosine"})


def build_store(kb):
    """kb: dict id -> text. Keeps the collection equal to kb. Returns the collection."""
    col = get_collection()
    have = col.get(include=["metadatas"])
    known = {i: m.get("hash") for i, m in zip(have["ids"], have["metadatas"])}
    gone = [i for i in known if i not in kb]
    if gone:
        col.delete(ids=gone)
    todo = [i for i, t in kb.items() if known.get(i) != _h(t)]
    if todo:
        vecs = embed.embed_texts([kb[i] for i in todo])
        col.upsert(ids=todo, documents=[kb[i] for i in todo], embeddings=vecs, metadatas=[{"hash": _h(kb[i])} for i in todo])
        print(f"(embedded {len(todo)} article(s) with 1 API call and stored them in Chroma)")
    else:
        print("(articles already in Chroma, no API call)")
    return col


def query(col, qvec, k=3):
    """Return [(article_id, cosine_similarity)] best first."""
    res = col.query(query_embeddings=[qvec], n_results=min(k, col.count()))
    return [(i, 1.0 - d) for i, d in zip(res["ids"][0], res["distances"][0])]
