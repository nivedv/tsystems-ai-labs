"""Demo 9, step 6: the full RAG answer, with CHROMA search. Only the search step is new; the prompt and the
citation check are exactly the ones from Day 1 (rag.py).

  python scripts/run_rag_chroma.py --retrieval-only                 # no chat calls
  python scripts/run_rag_chroma.py --questions q2,q4 --k 2
  python scripts/run_rag_chroma.py --probe --min-score 0.30         # the VPN-7 question with a minimum score
  python scripts/run_rag_chroma.py --dry-run                        # print the prompt for the first question
"""
import argparse
import json
import time

import common
import embed
import store
import rag
import search

ap = argparse.ArgumentParser()
ap.add_argument("--k", type=int, default=2)
ap.add_argument("--min-score", type=float, default=0.0, help="cosine, for example 0.30")
ap.add_argument("--questions", default="", help="e.g. q2,q4 (default: all six)")
ap.add_argument("--probe", action="store_true", help="run the VPN-7 question instead")
ap.add_argument("--retrieval-only", action="store_true")
ap.add_argument("--dry-run", action="store_true")
ap.add_argument("--pause", type=float, default=0.3)
ap.add_argument("--label", default="chroma_run")
ap.add_argument("--save", action="store_true")
args = ap.parse_args()

kb = search.load_kb(common.ROOT / "kb")
qdata = json.loads(common.read("data/questions.json"))
if args.probe:
    questions = [p for p in qdata["probes"] if p["id"] == "p_vpn7"]
else:
    questions = qdata["questions"]
    if args.questions:
        want = set(args.questions.split(","))
        questions = [q for q in questions if q["id"] in want]

try:
    col = store.build_store(kb)
    qvecs = embed.embed_texts([q["text"] for q in questions])
except Exception as e:
    common.explain_error(e)
    raise SystemExit(1)

client = deployment = None
if not (args.retrieval_only or args.dry_run):
    client, deployment = common.get_client()

rows = []
for q, qv in zip(questions, qvecs):
    full = store.query(col, qv, k=len(kb))
    hits = [(i, s, []) for i, s in full if s >= args.min_score][: args.k]
    ids = [h[0] for h in hits]
    key = q["key"] if isinstance(q["key"], str) else None
    rank = [i for i, _ in full].index(key) + 1 if key else None
    row = {"id": q["id"], "question": q["text"], "key": key, "retrieved": ids,
           "scores": [round(h[1], 3) for h in hits], "key_rank": rank, "answer": None, "check": None, "right": None}
    if args.dry_run:
        for m in rag.build_messages(q["text"], hits, kb):
            print(f"[{m['role']}]\n{m['content']}\n")
        print("Dry run only (first question shown). No chat call was made.")
        raise SystemExit(0)
    if not args.retrieval_only:
        if not hits:
            row.update(answer="not found", check="pass_not_found", right=key is None)
            print(f"{q['id']}: no article reached the minimum score {args.min_score} -> 'not found' without a model call")
        else:
            try:
                ans, _tok, _fin = rag.ask(client, deployment, q["text"], hits, kb)
            except Exception as e:
                common.explain_error(e)
                raise SystemExit(1)
            row.update(answer=ans, check=rag.check(ans, ids), right=(key in rag.cited(ans)) if key else "not found" in ans.lower())
            time.sleep(args.pause)
    rows.append(row)

print(f"\nk={args.k}  min_score={args.min_score}\n")
hdr = f"{'q':<8}{'retrieved':<20}{'cosine':<16}{'key rank':<10}"
if not args.retrieval_only:
    hdr += f"{'check':<20}{'right?':<8}"
print(hdr)
for r in rows:
    line = f"{r['id']:<8}{','.join(r['retrieved']) or '(none)':<20}{','.join(map(str, r['scores'])) or '-':<16}{str(r['key_rank']):<10}"
    if not args.retrieval_only:
        line += f"{r['check']:<20}{'yes' if r['right'] else 'no':<8}"
    print(line)
if not args.retrieval_only:
    for r in rows:
        print(f"\n{r['id']} answer: {r['answer']}")
if args.save:
    common.save_output(f"{args.label}.json", json.dumps({"k": args.k, "min_score": args.min_score, "rows": rows}, indent=2))
