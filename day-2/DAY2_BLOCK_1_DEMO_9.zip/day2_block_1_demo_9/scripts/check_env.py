"""Run this FIRST (also at T-30 min before class). Shows which settings exist. Never prints the key.
Day 2: also makes one tiny EMBEDDING call, so you know the embedding deployment works."""
import os
from common import REQUIRED, load_env

load_env()
ok = True
for k in REQUIRED + ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"]:
    v = os.environ.get(k)
    if not v and k == "AZURE_OPENAI_EMBEDDING_DEPLOYMENT":
        print(f"[ note  ] {k} not set -> using the default 'text-embedding-3-small'")
    elif not v:
        print(f"[MISSING] {k}")
        ok = False
    elif k == "AZURE_OPENAI_API_KEY":
        print(f"[ set   ] {k}  (value hidden)")
    else:
        print(f"[ set   ] {k} = {v}")
try:
    import openai  # noqa: F401
    print(f"[ ok    ] openai package {openai.__version__}")
except ImportError:
    print("[MISSING] openai package -> pip install -r requirements.txt")
    ok = False
if ok:
    try:
        import embed
        v = embed.embed_texts(["test"])[0]
        print(f"[ ok    ] embedding call worked. vector length = {len(v)}  (text-embedding-3-small gives 1536)")
    except SystemExit:
        ok = False
    except Exception as e:
        import common
        common.explain_error(e)
        ok = False
print("\nREADY for the embedding demo." if ok else "\nFix the items above, then run again.")
